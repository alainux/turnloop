#!/usr/bin/env bash
# Start the Turn UI server.
#
# Defaults run fully offline: local-file store, heuristic planner, echo leaves.
# Override with env vars (see .env.example). Example:
#   TURN_PLANNER=codex ./scripts/run.sh        # Codex-backed planning + workers
set -euo pipefail
cd "$(dirname "$0")/.."

export TURN_DATA_DIR="${TURN_DATA_DIR:-$(pwd)/turn}"
export TURN_PLANNER="${TURN_PLANNER:-heuristic}"
export TURN_DEFAULT_EXECUTOR="${TURN_DEFAULT_EXECUTOR:-echo}"
export TURN_EXECUTION_BACKEND="${TURN_EXECUTION_BACKEND:-direct}"
export PYTHONPATH="${PYTHONPATH:-.}:$(pwd)"

PORT="${TURN_PORT:-8000}"
echo "Turn → http://127.0.0.1:${PORT}"
echo "  store:   ${TURN_DATA_DIR}"
echo "  planner: ${TURN_PLANNER}"
echo "  executor:${TURN_DEFAULT_EXECUTOR}"
echo "  backend: ${TURN_EXECUTION_BACKEND}"

exec uvicorn turn.server.app:app --host 127.0.0.1 --port "$PORT" --reload
