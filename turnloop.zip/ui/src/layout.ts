import type { Edge, GraphNode } from "./domain";

export interface Position {
  x: number;
  y: number;
  depth: number;
}
export interface Layout {
  positions: Map<string, Position>;
  width: number;
  height: number;
}
export const NODE_WIDTH = 224,
  NODE_HEIGHT = 64,
  GRAPH_PADDING = 48;

/**
 * Lay the graph out as a left-to-right work pipeline.
 *
 * Containment still controls the vertical dendrogram, while both containment
 * and explicit workflow edges advance a node to a later stage. This means a
 * dependency is never rendered as a same-column vertical relationship: it is
 * a normal grey edge from one workflow stage to the next.
 */
export function layoutDendrogram(nodes: GraphNode[], edges: Edge[] = []): Layout {
  const byId = new Map(nodes.map((node) => [node.id, node]));
  const children = new Map<string, string[]>();
  for (const node of nodes) {
    if (node.parent_id && byId.has(node.parent_id)) {
      children.set(node.parent_id, [
        ...(children.get(node.parent_id) ?? []),
        node.id,
      ]);
    }
  }
  const alphabetical = (a: string, b: string) =>
    (byId.get(a)?.objective ?? "").localeCompare(byId.get(b)?.objective ?? "");
  const orderSiblings = (ids: string[]) => {
    const members = new Set(ids);
    const outgoing = new Map<string, string[]>();
    const indegree = new Map(ids.map((id) => [id, 0]));
    for (const edge of edges) {
      if (
        edge.type !== "DEPENDS_ON" ||
        !members.has(edge.src) ||
        !members.has(edge.dst)
      ) {
        continue;
      }
      outgoing.set(edge.src, [...(outgoing.get(edge.src) ?? []), edge.dst]);
      indegree.set(edge.dst, (indegree.get(edge.dst) ?? 0) + 1);
    }
    const ready = ids.filter((id) => indegree.get(id) === 0).sort(alphabetical);
    const ordered: string[] = [];
    while (ready.length) {
      const id = ready.shift()!;
      ordered.push(id);
      for (const dependent of outgoing.get(id) ?? []) {
        const next = (indegree.get(dependent) ?? 0) - 1;
        indegree.set(dependent, next);
        if (next === 0) ready.push(dependent);
      }
      ready.sort(alphabetical);
    }
    return ordered.length === ids.length
      ? ordered
      : [
          ...ordered,
          ...ids.filter((id) => !ordered.includes(id)).sort(alphabetical),
        ];
  };
  children.forEach((ids, parent) => children.set(parent, orderSiblings(ids)));
  const roots = orderSiblings(
    nodes
      .filter((node) => !node.parent_id || !byId.has(node.parent_id))
      .map((node) => node.id),
  );

  // Compute the longest left-to-right stage across the complete graph. The
  // API validates cycles, but retaining a deterministic fallback keeps the UI
  // usable while a malformed or partially loaded graph is being inspected.
  const outgoing = new Map<string, string[]>();
  const indegree = new Map(nodes.map((node) => [node.id, 0]));
  const stageEdges = edges
    .filter((edge) => byId.has(edge.src) && byId.has(edge.dst))
    .map((edge) => ({ src: edge.src, dst: edge.dst }));
  const stagePairs = new Set(stageEdges.map((edge) => `${edge.src}:${edge.dst}`));
  // Parent metadata is also authoritative during partial loads where the
  // corresponding CONTAINS edge has not arrived yet.
  for (const node of nodes) {
    if (node.parent_id && byId.has(node.parent_id)) {
      const pair = `${node.parent_id}:${node.id}`;
      if (!stagePairs.has(pair)) {
        stagePairs.add(pair);
        stageEdges.push({ src: node.parent_id, dst: node.id });
      }
    }
  }
  for (const edge of stageEdges) {
    outgoing.set(edge.src, [...(outgoing.get(edge.src) ?? []), edge.dst]);
    indegree.set(edge.dst, (indegree.get(edge.dst) ?? 0) + 1);
  }
  const stage = new Map<string, number>(nodes.map((node) => [node.id, 0]));
  const ready = nodes
    .filter((node) => indegree.get(node.id) === 0)
    .map((node) => node.id)
    .sort(alphabetical);
  const visited = new Set<string>();
  while (ready.length) {
    const id = ready.shift()!;
    visited.add(id);
    for (const dst of outgoing.get(id) ?? []) {
      stage.set(dst, Math.max(stage.get(dst) ?? 0, (stage.get(id) ?? 0) + 1));
      const next = (indegree.get(dst) ?? 0) - 1;
      indegree.set(dst, next);
      if (next === 0) ready.push(dst);
    }
    ready.sort(alphabetical);
  }
  // A cycle should not happen, but put any unvisited nodes after their
  // predecessors instead of collapsing them into a vertical relation.
  for (const node of nodes) {
    if (!visited.has(node.id)) {
      const predecessorStages = stageEdges
        .filter((edge) => edge.dst === node.id)
        .map((edge) => stage.get(edge.src) ?? 0);
      stage.set(node.id, Math.max(stage.get(node.id) ?? 0, ...predecessorStages, 0) + 1);
    }
  }

  const positions = new Map<string, Position>();
  let leaf = 0;
  const place = (id: string): number => {
    const ys = (children.get(id) ?? []).map((child) => place(child));
    const y = ys.length
      ? (ys[0] + ys[ys.length - 1]) / 2
      : leaf++ * (NODE_HEIGHT + 18);
    const depth = stage.get(id) ?? 0;
    positions.set(id, {
      x: depth * (NODE_WIDTH + 54),
      y,
      depth,
    });
    return y;
  };
  roots.forEach((id, index) => {
    if (index) leaf += 1;
    place(id);
  });
  // Include disconnected nodes that are not discoverable from a parent root.
  nodes.forEach((node) => {
    if (!positions.has(node.id)) place(node.id);
  });
  let width = NODE_WIDTH,
    height = NODE_HEIGHT;
  positions.forEach((p) => {
    width = Math.max(width, p.x + NODE_WIDTH);
    height = Math.max(height, p.y + NODE_HEIGHT);
  });
  return { positions, width, height };
}

export function pathBetween(
  a: Position,
  b: Position,
  _type: "CONTAINS" | "DEPENDS_ON" = "CONTAINS",
): string {
  const ax = a.x + GRAPH_PADDING,
    ay = a.y + GRAPH_PADDING,
    bx = b.x + GRAPH_PADDING,
    by = b.y + GRAPH_PADDING;
  const x1 = ax + NODE_WIDTH,
    y1 = ay + NODE_HEIGHT / 2,
    x2 = bx,
    y2 = by + NODE_HEIGHT / 2,
    elbow = x1 + (x2 - x1) / 2;
  return `M${x1} ${y1}H${elbow}V${y2}H${x2}`;
}
