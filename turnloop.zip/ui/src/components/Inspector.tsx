import { lazy, Suspense, useEffect, useMemo, useRef, useState } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import type {
  AgentConfig,
  GraphNode,
  HarnessCapability,
  NodeDetail as Detail,
  Permission,
  Reasoning,
} from "../domain";
import { api, json } from "../api";
import { Icon } from "./Icon";
import { ModelControl } from "./ModelControl";
const TerminalView = lazy(() =>
  import("./TerminalView").then((module) => ({ default: module.TerminalView })),
);

type Tab = "overview" | "terminal";
interface Props {
  nodeId: string;
  refreshKey: string;
  capabilities: HarnessCapability[];
  onClose: () => void;
  onChanged: () => Promise<void>;
  notify: (text: string) => void;
}
export function Inspector({
  nodeId,
  refreshKey,
  capabilities,
  onClose,
  onChanged,
  notify,
}: Props) {
  const [detail, setDetail] = useState<Detail | null>(null);
  const [tab, setTab] = useState<Tab>("overview");
  const [error, setError] = useState("");
  const dirty = useRef(false);
  const loadVersion = useRef(0);
  const load = async () => {
    const version = ++loadVersion.current;
    try {
      const result = await api<Detail>(`/api/nodes/${nodeId}`);
      if (version !== loadVersion.current) return;
      setDetail(result);
      setError("");
    } catch (cause) {
      if (version !== loadVersion.current) return;
      setError(cause instanceof Error ? cause.message : String(cause));
    }
  };
  useEffect(() => {
    dirty.current = false;
    setDetail(null);
    void load();
  }, [nodeId]);
  useEffect(() => {
    if (!dirty.current) void load();
  }, [refreshKey]);
  const mutate = async (path: string, init?: RequestInit, message?: string) => {
    try {
      await api(path, init);
      if (message) notify(message);
      await onChanged();
      await load();
    } catch (cause) {
      notify(cause instanceof Error ? cause.message : String(cause));
    }
  };
  return (
    <aside className="inspector" id="inspector">
      <div className="panel-heading">
        <span>Inspector</span>
        <button
          className="quiet-icon"
          onClick={onClose}
          aria-label="Close inspector"
        >
          <Icon name="panel-right-close" />
        </button>
      </div>
      <div className="inspector-tabs" role="tablist">
        {(["overview", "terminal"] as Tab[]).map((item) => (
          <button
            key={item}
            role="tab"
            aria-selected={tab === item}
            className={tab === item ? "active" : ""}
            onClick={() => setTab(item)}
          >
            {item[0].toUpperCase() + item.slice(1)}
          </button>
        ))}
      </div>
      <div className="detail">
        {error ? (
          <p className="detail-error">{error}</p>
        ) : !detail ? (
          <p className="detail-loading">Loading node…</p>
        ) : tab === "terminal" ? (
          <Suspense
            fallback={<p className="detail-loading">Loading terminal…</p>}
          >
            <TerminalView
              node={detail.node}
              runs={detail.runs}
            />
          </Suspense>
        ) : (
          <Overview
            detail={detail}
            capabilities={capabilities}
            mutate={mutate}
            onDirtyChange={(value) => {
              dirty.current = value;
            }}
          />
        )}
      </div>
    </aside>
  );
}

function Overview({
  detail,
  capabilities,
  mutate,
  onDirtyChange,
}: {
  detail: Detail;
  capabilities: HarnessCapability[];
  mutate: (path: string, init?: RequestInit, message?: string) => Promise<void>;
  onDirtyChange: (value: boolean) => void;
}) {
  const node = detail.node;
  const [editingPrompt, setEditingPrompt] = useState(false);
  const [prompt, setPrompt] = useState(node.generated_prompt ?? "");
  const [objective, setObjective] = useState(node.objective);
  const [agent, setAgent] = useState<AgentConfig | null>(node.agent ?? null);
  const [cascade, setCascade] = useState(false);
  const [feedback, setFeedback] = useState("");
  const [inputs, setInputs] = useState<Record<string, string>>({});
  useEffect(() => {
    setPrompt(node.generated_prompt ?? "");
    setObjective(node.objective);
    setAgent(node.agent ?? null);
    setEditingPrompt(false);
  }, [node.id]);
  const scopeDirty =
    objective !== node.objective || prompt !== (node.generated_prompt ?? "");
  const agentDirty = JSON.stringify(agent) !== JSON.stringify(node.agent);
  useEffect(() => {
    onDirtyChange(
      editingPrompt ||
        scopeDirty ||
        agentDirty ||
        Boolean(feedback.trim()) ||
        Object.values(inputs).some(Boolean),
    );
    return () => onDirtyChange(false);
  }, [
    editingPrompt,
    scopeDirty,
    agentDirty,
    feedback,
    inputs,
    onDirtyChange,
  ]);
  return (
    <>
      <h2 className="detail-title">{node.objective}</h2>
      <div className="detail-meta">
        <span className={`badge ${node.ui_state}`}>
          {node.generation_active
            ? "generating"
            : node.ui_state.replaceAll("_", " ")}
        </span>
      </div>
      <section className="section instructions-section">
        <div className="section-heading">
          <span>Agent instructions</span>
          <button
            className="quiet-icon"
            onClick={() => setEditingPrompt((value) => !value)}
            aria-label="Edit agent instructions"
          >
            <Icon name="pencil" />
          </button>
        </div>
        {editingPrompt ? (
          <>
            <label className="field">
              <span>Objective</span>
              <input
                value={objective}
                maxLength={160}
                onChange={(event) => setObjective(event.target.value)}
              />
            </label>
            <textarea
              className="instruction-editor"
              value={prompt}
              onChange={(event) => setPrompt(event.target.value)}
            />
            <button
              className="button accent"
              disabled={!scopeDirty}
              onClick={() =>
                mutate(
                  `/api/nodes/${node.id}/edit`,
                  json("POST", {
                    objective: objective.trim(),
                    generated_prompt: prompt.trim() || null,
                  }),
                  "Instructions updated",
                )
              }
            >
              Save instructions
            </button>
          </>
        ) : (
          <div className="markdown-body">
            <ReactMarkdown remarkPlugins={[remarkGfm]}>
              {prompt || "_No additional instructions._"}
            </ReactMarkdown>
          </div>
        )}
      </section>
      {agent && (
        <section className="section">
          <div className="section-heading">
            <span>Agent configuration</span>
          </div>
          <div className="form-grid agent-config-grid">
            <ModelControl
              harness={agent.harness}
              model={agent.model ?? ""}
              reasoning={agent.reasoning}
              capabilities={capabilities}
              onHarness={(harness) => {
                const model = capabilities.find((item) => item.id === harness)
                  ?.models[0];
                setAgent({
                  ...agent,
                  harness,
                  model: model?.id ?? null,
                  reasoning: model?.reasoning?.[0] ?? "default",
                  session_id:
                    harness === agent.harness ? agent.session_id : null,
                });
              }}
              onModel={(model) => setAgent({ ...agent, model: model || null })}
              onReasoning={(reasoning: Reasoning) =>
                setAgent({ ...agent, reasoning })
              }
            />
            <label className="field">
              <span>Permissions</span>
              <select
                value={agent.permission}
                onChange={(event) =>
                  setAgent({
                    ...agent,
                    permission: event.target.value as Permission,
                  })
                }
              >
                <option value="ask">Ask</option>
                <option value="workspace">Workspace</option>
                <option value="full">Full access</option>
              </select>
            </label>
          </div>
          <div className="agent-resources">
            <span>{agent.skills.length} skills</span>
            <span>{agent.tools.length} tools</span>
            <span>{agent.mcp_servers.length} MCP</span>
          </div>
          <label className="check cascade-option">
            <input
              type="checkbox"
              checked={cascade}
              onChange={(event) => setCascade(event.target.checked)}
            />
            Cascade options
          </label>
          <button
            className="button accent"
            disabled={!agentDirty}
            onClick={() =>
              mutate(
                `/api/nodes/${node.id}/edit`,
                json("POST", { agent, cascade_agent: cascade }),
                "Agent configuration updated",
              )
            }
          >
            Save agent
          </button>
        </section>
      )}
      {node.required_inputs.some((input) => !input.satisfied_by) && (
        <section className="section">
          <div className="section-heading">
            <span>Human input</span>
          </div>
          {node.required_inputs
            .filter((input) => !input.satisfied_by)
            .map((input) => (
              <div className="input-card" key={input.id}>
                <h3>{input.label}</h3>
                <p>
                  {input.description ||
                    "This node needs a human decision before it can continue."}
                </p>
                <textarea
                  aria-label={input.label}
                  value={inputs[input.id] ?? ""}
                  onChange={(event) =>
                    setInputs({ ...inputs, [input.id]: event.target.value })
                  }
                />
                <button
                  className="button accent"
                  disabled={!inputs[input.id]?.trim()}
                  onClick={() =>
                    mutate(
                      `/api/nodes/${node.id}/provide-input`,
                      json("POST", {
                        input_id: input.id,
                        value: inputs[input.id].trim(),
                      }),
                      "Input supplied",
                    )
                  }
                >
                  Provide input
                </button>
              </div>
            ))}
        </section>
      )}
      {node.needs_review && (
        <Review
          node={node}
          feedback={feedback}
          setFeedback={setFeedback}
          mutate={mutate}
        />
      )}
      <section className="section">
        <div className="section-heading">
          <span>Artifacts</span>
        </div>
        <div className="artifact-list">
          {detail.artifacts
            .filter(
              (item) => item.name !== "transcript" && item.kind !== "code_diff",
            )
            .map((item) => {
              const hasContent =
                item.content !== null &&
                item.content !== undefined &&
                item.content !== "";
              const summary = (
                <div className="artifact-summary">
                  <Icon name={item.kind === "file" ? "file" : "braces"} />
                  <span>{item.name}</span>
                </div>
              );
              return hasContent ? (
                <details key={item.id} className="artifact-row">
                  <summary>{summary}</summary>
                  <pre>
                    {typeof item.content === "string"
                      ? item.content
                      : JSON.stringify(item.content, null, 2)}
                  </pre>
                </details>
              ) : (
                <div key={item.id} className="artifact-row artifact-row-static">
                  {summary}
                </div>
              );
            })}
        </div>
      </section>
      <section className="section">
        <div className="section-heading">
          <span>Actions</span>
        </div>
        <div className="action-groups">
          <div className="action-group">
            <span>Node</span>
            <div className="action-row">
              {node.allowed_actions
                .filter((action) =>
                  ["run", "pause", "resume", "retry", "cancel"].includes(
                    action,
                  ),
                )
                .map((action) => (
                  <button
                    key={action}
                    className={`button compact ${action === "run" ? "accent" : action === "cancel" ? "danger" : ""}`}
                    onClick={() =>
                      mutate(
                        `/api/nodes/${node.id}/${action}`,
                        { method: "POST" },
                        `${action} requested`,
                      )
                    }
                  >
                    {action[0].toUpperCase() + action.slice(1)}
                  </button>
                ))}
              {!node.allowed_actions.some((action) =>
                ["run", "pause", "resume", "retry", "cancel"].includes(action),
              ) && <span className="empty-action">No direct action</span>}
            </div>
          </div>
          {node.allowed_actions.includes("regenerate") && (
            <div className="action-group">
              <span>Planner</span>
              <div className="action-row">
                <button
                  className="button compact"
                  onClick={async () => {
                    if (
                      confirm(
                        "Regenerate this planner and replace its entire descendant tree? This cannot be undone.",
                      )
                    )
                      await mutate(
                        `/api/nodes/${node.id}/regenerate`,
                        { method: "POST" },
                        "Tree regenerated",
                      );
                  }}
                >
                  Regenerate tree
                </button>
              </div>
            </div>
          )}
        </div>
      </section>
    </>
  );
}

function Review({
  node,
  feedback,
  setFeedback,
  mutate,
}: {
  node: GraphNode;
  feedback: string;
  setFeedback: (v: string) => void;
  mutate: (path: string, init?: RequestInit, message?: string) => Promise<void>;
}) {
  return (
    <section className="section">
      <div className="section-heading">
        <span>Review</span>
      </div>
      <div className="review-card">
        <h3>Review result</h3>
        <p>Accept the result or return feedback to the same agent session.</p>
        {node.allowed_actions.includes("accept") && (
          <div className="review-feedback">
            <textarea
              value={feedback}
              onChange={(event) => setFeedback(event.target.value)}
              placeholder="Feedback if changes are required…"
            />
            <div className="action-row">
              <button
                className="button accent"
                onClick={() =>
                  mutate(
                    `/api/nodes/${node.id}/accept`,
                    { method: "POST" },
                    "Result accepted",
                  )
                }
              >
                Accept result
              </button>
              <button
                className="button"
                disabled={!feedback.trim()}
                onClick={() =>
                  mutate(
                    `/api/nodes/${node.id}/reject`,
                    json("POST", { feedback }),
                    "Feedback returned to the same session",
                  )
                }
              >
                Request changes
              </button>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
