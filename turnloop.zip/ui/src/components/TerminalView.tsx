import { useEffect, useRef, useState } from "react";
import { Terminal } from "@xterm/xterm";
import { FitAddon } from "@xterm/addon-fit";
import xtermCss from "@xterm/xterm/css/xterm.css?inline";
import type { GraphNode, Run } from "../domain";
import { Icon } from "./Icon";
import { api } from "../api";

interface Props {
  node: GraphNode;
  runs: Run[];
}

export function TerminalView({ node, runs }: Props) {
  const host = useRef<HTMLDivElement>(null);
  const [active, setActive] = useState(false);
  const [idle, setIdle] = useState(false);
  const [showReplay, setShowReplay] = useState(false);
  const [reconnectKey, setReconnectKey] = useState(0);
  const [reconnectNodeId, setReconnectNodeId] = useState<string | null>(null);
  const [shellNodeId, setShellNodeId] = useState<string | null>(null);
  const [reconnecting, setReconnecting] = useState(false);
  const sessionId = node.agent?.session_id ?? runs.at(-1)?.session_id;
  const harnessRequested = Boolean(node.generation_active) || reconnectNodeId === node.id;
  const shellRequested = shellNodeId === node.id && !harnessRequested;
  const endpoint = harnessRequested ? "terminal" : shellRequested ? "shell" : null;

  useEffect(() => {
    if (!host.current) return;
    const mountHost = host.current;
    // Keep xterm in the normal DOM. The PTY stream is already native and raw;
    // a regular host lets the browser paint the terminal canvas consistently
    // across embedded browser surfaces and makes its sizing observable.
    mountHost.replaceChildren();
    const style = document.createElement("style");
    style.textContent = `${xtermCss}
:host{display:block;height:100%;background:#090b0e}
.mount{width:100%;height:100%;padding:8px 12px 8px 8px;box-sizing:border-box}
.xterm{width:100%;height:100%;font-family:ui-monospace,SFMono-Regular,Menlo,monospace!important;font-size:11px!important;line-height:1.35!important}`;
    const mount = document.createElement("div");
    mount.className = "mount";
    mountHost.append(style, mount);
    const terminal = new Terminal({
      convertEol: true,
      // Keep xterm's input plumbing installed even while the panel is a
      // transcript. We gate writes in onData below; toggling disableStdin at
      // runtime is unreliable in embedded browsers and can leave the helper
      // textarea alive without a renderer/input connection.
      disableStdin: false,
      cursorBlink: false,
      fontFamily: "ui-monospace,SFMono-Regular,Menlo,monospace",
      fontSize: 11,
      lineHeight: 1.35,
      scrollback: 5000,
      theme: {
        background: "#090b0e",
        black: "#090b0e",
        foreground: "#c5ccd6",
        cursor: "#78a9ff",
        red: "#ef7373",
        green: "#65c98a",
        yellow: "#dfb15b",
        blue: "#78a9ff",
        magenta: "#b28cff",
        cyan: "#65c9c4",
        white: "#e6ebf2",
        brightBlack: "#5d6878",
        brightRed: "#ff8b8b",
        brightGreen: "#8ee6aa",
        brightYellow: "#f4d27d",
        brightBlue: "#9abaff",
        brightMagenta: "#c9adff",
        brightCyan: "#91e5df",
        brightWhite: "#ffffff",
      },
    });
    const fit = new FitAddon();
    terminal.loadAddon(fit);
    terminal.open(mount);
    try {
      fit.fit();
    } catch {
      /* hidden panel */
    }

    let disposed = false;
    let sessionActive = false;
    let replaying = false;
    let socket: WebSocket | null = null;
    let terminalWriteQueue = Promise.resolve();
    const queueTerminalWrite = (data: string) => {
      // Do not wait for xterm's optional completion callback here. A native
      // full-screen program can leave a parser sequence pending while it is
      // repainting; waiting on that callback would block every later chunk
      // and make a perfectly live PTY appear blank. xterm.write itself keeps
      // the bytes in order, so the queue only needs to serialize calls.
      const write = terminalWriteQueue.then(() => {
        terminal.write(data);
        terminal.refresh(0, Math.max(0, terminal.rows - 1));
      });
      terminalWriteQueue = write.catch(() => undefined);
      return write;
    };
    const syncSize = () => {
      try {
        fit.fit();
      } catch {
        /* hidden panel */
      }
      if (socket?.readyState === WebSocket.OPEN) {
        socket.send(
          JSON.stringify({ type: "resize", cols: terminal.cols, rows: terminal.rows }),
        );
      }
    };
    const refitAfterLayout = () => {
      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          if (!disposed) syncSize();
        });
      });
    };
    void document.fonts?.ready.then(() => {
      if (!disposed) refitAfterLayout();
    });
    const activate = (value: boolean, idleValue = false) => {
      sessionActive = value;
      setActive(value);
      setIdle(value && idleValue);
      if (value) setShowReplay(true);
      terminal.options.cursorBlink = value;
      const helper = mountHost.querySelector<HTMLTextAreaElement>(
        ".xterm-helper-textarea",
      );
      if (helper) {
        helper.disabled = !value;
        helper.readOnly = !value;
        helper.tabIndex = value ? 0 : -1;
        helper.setAttribute(
          "aria-label",
          value ? "Terminal input" : "Terminal transcript",
        );
      }
      if (value) terminal.focus();
    };

    if (endpoint) {
      const protocol = location.protocol === "https:" ? "wss" : "ws";
      socket = new WebSocket(
        `${protocol}://${location.host}/api/nodes/${node.id}/${endpoint}`,
      );
      socket.onopen = syncSize;
      socket.onmessage = async (event) => {
        let message: Record<string, unknown>;
        try {
          message = JSON.parse(String(event.data)) as Record<string, unknown>;
        } catch {
          return;
        }
        if (message.type === "snapshot") {
          activate(Boolean(message.active), Boolean(message.idle));
          terminal.reset();
          if (message.output) {
            const fitted = { cols: terminal.cols, rows: terminal.rows };
            replaying = true;
            const snapshotCols = Number(message.cols) || fitted.cols;
            const snapshotRows = Number(message.rows) || fitted.rows;
            if (snapshotCols !== fitted.cols || snapshotRows !== fitted.rows) {
              terminal.resize(snapshotCols, snapshotRows);
            }
            await queueTerminalWrite(String(message.output));
            if (snapshotCols !== fitted.cols || snapshotRows !== fitted.rows) {
              terminal.resize(fitted.cols, fitted.rows);
            }
            replaying = false;
          }
        } else if (message.type === "output") {
          if (!sessionActive) activate(true);
          setIdle(false);
          await queueTerminalWrite(String(message.data ?? ""));
        } else if (message.type === "status") {
          const statusActive = Boolean(message.active);
          activate(statusActive, Boolean(message.idle));
          if (endpoint === "shell" && !statusActive) {
            setShellNodeId(null);
            setShowReplay(false);
          }
        }
      };
      socket.onclose = () => {
        activate(false);
        if (endpoint === "terminal" && node.status !== "RUNNING") {
          setReconnectNodeId(null);
        }
        if (endpoint === "shell") {
          setShellNodeId(null);
          setShowReplay(false);
        }
      };
    } else {
      activate(false);
    }

    terminal.onData((value) => {
      if (sessionActive && socket?.readyState === WebSocket.OPEN) {
        socket.send(JSON.stringify({ type: "input", data: value }));
      }
    });
    terminal.onResize(({ cols, rows }) => {
      if (!replaying && socket?.readyState === WebSocket.OPEN) {
        socket.send(JSON.stringify({ type: "resize", cols, rows }));
      }
    });
    const observer = new ResizeObserver(() => refitAfterLayout());
    observer.observe(host.current);
    refitAfterLayout();
    // Inspector and graph panes can finish their CSS grid transition after
    // xterm has opened. FitAddon only measures the current box, so retry a
    // few times while the layout settles; otherwise a terminal can remain a
    // tiny 13-column viewport inside a correctly sized panel.
    const refitTimers = [50, 200, 500, 1000].map((delay) =>
      window.setTimeout(refitAfterLayout, delay),
    );
    return () => {
      disposed = true;
      refitTimers.forEach((timer) => window.clearTimeout(timer));
      observer.disconnect();
      socket?.close();
      terminal.dispose();
    };
  }, [endpoint, node.id, reconnectKey]);

  const openShell = () => {
    setShowReplay(true);
    setShellNodeId(node.id);
  };
  const closeShell = async () => {
    try {
      await api<{ ok: boolean }>(`/api/nodes/${node.id}/shell/close`, {
        method: "POST",
      });
    } catch (error) {
      console.error("Unable to close shell", error);
    } finally {
      setShellNodeId(null);
      setShowReplay(false);
    }
  };
  const openTerminal = async () => {
    if (sessionId) {
      setReconnecting(true);
      try {
        const result = await api<{ ok: boolean }>(
          `/api/nodes/${node.id}/reconnect`,
          { method: "POST" },
        );
        if (!result.ok) throw new Error("No resumable session is available");
        setReconnectNodeId(node.id);
        setReconnectKey((value) => value + 1);
        setShowReplay(true);
      } catch (error) {
        console.error("Unable to open harness terminal", error);
      } finally {
        setReconnecting(false);
      }
      return;
    }
    openShell();
  };
  const closeProviderTerminal = async () => {
    try {
      await api<{ ok: boolean }>(`/api/nodes/${node.id}/terminal/close`, {
        method: "POST",
      });
    } catch (error) {
      console.error("Unable to close harness terminal", error);
    } finally {
      setReconnectNodeId(null);
      setShowReplay(false);
    }
  };

  return (
    <div
      className={`terminal-shell ${!active && !showReplay ? "terminal-shell-collapsed" : ""}`}
    >
      <div className="terminal-head">
        <Icon name="terminal" />
        <span className="terminal-title">
          {endpoint === "shell" ? "shell" : node.agent?.harness ?? node.executor} · {node.id.slice(0, 8)}
        </span>
        <span className="terminal-mode">
          {active ? (idle ? "LIVE · waiting" : "LIVE") : endpoint === "shell" ? "OPEN" : "DISCONNECTED"}
        </span>
      </div>
      {endpoint === "shell" && active && (
        <div className="terminal-session-actions">
          <button type="button" className="button compact" onClick={closeShell}>
            Close terminal
          </button>
        </div>
      )}
      {endpoint === "terminal" && active && node.status !== "RUNNING" && (
        <div className="terminal-session-actions">
          <button
            type="button"
            className="button compact"
            onClick={closeProviderTerminal}
          >
            Close terminal
          </button>
        </div>
      )}
      {!active && (
        <div className="terminal-disconnected">
          <span>
            {endpoint === "shell"
              ? "Opening a shell in the assigned project directory…"
              : sessionId
                ? "Harness session is disconnected."
                : "No terminal is open. Open a shell to inspect the project directory."}
          </span>
          <div className="terminal-disconnected-actions">
            {endpoint !== "shell" && (
              <button
                type="button"
                className="button compact"
                onClick={() => setShowReplay((value) => !value)}
              >
                {showReplay ? "Hide output" : "Show output"}
              </button>
            )}
            {endpoint !== "shell" && (
              <button
                type="button"
                className="button compact terminal-reconnect"
                disabled={reconnecting}
                onClick={openTerminal}
                title={
                  sessionId
                    ? "Open the last harness session"
                    : "Open an ordinary terminal in the project directory"
                }
              >
                {reconnecting ? "Connecting…" : "Open terminal"}
              </button>
            )}
          </div>
        </div>
      )}
      <div
        ref={host}
        className={`terminal-shadow-host ${!active && !showReplay ? "is-collapsed" : ""}`}
        aria-label="Agent terminal"
      />
    </div>
  );
}
