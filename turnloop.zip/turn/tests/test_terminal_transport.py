from __future__ import annotations

import asyncio
import sys
import uuid

from turn.workers.terminal import LocalPtyTransport, TmuxPtyTransport


async def test_local_pty_forwards_machine_bytes_without_transform(tmp_path):
    transport = LocalPtyTransport()
    node_id = uuid.uuid4()
    raw = '{"type":"message","text":"leave this exactly as emitted"}'
    result = await transport.run(
        node_id,
        [sys.executable, "-c", f"print({raw!r}, flush=True)"],
        cwd=str(tmp_path),
        timeout=5,
    )
    assert raw.encode() in result.output
    assert result.display_output == result.output
    assert raw in transport.snapshot(node_id)["output"]


async def test_local_pty_preserves_ansi_accepts_input_and_resizes(tmp_path):
    transport = LocalPtyTransport()
    node_id = uuid.uuid4()
    command = [
        sys.executable,
        "-c",
        "import sys; print('\\x1b[31mRED\\x1b[0m', flush=True); value=input(); print('GOT:'+value, flush=True)",
    ]
    task = asyncio.create_task(transport.run(node_id, command, cwd=str(tmp_path), timeout=5, stall_timeout=2))
    for _ in range(100):
        if transport.snapshot(node_id).get("active") and "RED" in transport.snapshot(node_id).get("output", ""):
            break
        await asyncio.sleep(0.01)
    assert await transport.resize(node_id, 90, 28)
    assert await transport.write(node_id, "hello\n")
    result = await task
    assert result.returncode == 0 and not result.stalled
    assert b"\x1b[31mRED\x1b[0m" in result.output
    assert b"GOT:hello" in result.output
    assert transport.snapshot(node_id)["active"] is False


async def test_local_pty_keeps_provider_stream_raw_and_releases_completed_session(tmp_path):
    transport = LocalPtyTransport()
    node_id = uuid.uuid4()
    result = await transport.run(
        node_id,
        [
            sys.executable,
            "-c",
            "import json; print(json.dumps({'type':'text','part':{'text':'hello from provider'}}), flush=True)",
        ],
        cwd=str(tmp_path),
        timeout=5,
    )
    snapshot = transport.snapshot(node_id)
    assert '"type": "text"' in result.display_output.decode()
    assert "hello from provider" in snapshot["output"]
    assert '"type": "text"' in snapshot["output"]
    assert transport.release(node_id)
    assert transport.snapshot(node_id) == {"active": False, "output": ""}


async def test_local_pty_normalizes_noninteractive_terminal_defaults(tmp_path, monkeypatch):
    monkeypatch.setenv("TERM", "dumb")
    monkeypatch.delenv("COLORTERM", raising=False)
    monkeypatch.setenv("NO_COLOR", "1")
    transport = LocalPtyTransport()
    result = await transport.run(
        uuid.uuid4(),
        [
            sys.executable,
            "-c",
            "import os; print(os.getenv('TERM')+' '+os.getenv('COLORTERM')+' '+str(os.getenv('NO_COLOR')))"
        ],
        cwd=str(tmp_path),
        timeout=5,
    )
    assert b"xterm-256color truecolor None" in result.output


async def test_local_pty_detects_silent_live_process(tmp_path):
    transport = LocalPtyTransport()
    node_id = uuid.uuid4()
    result = await transport.run(
        node_id,
        [sys.executable, "-c", "import time; print('started', flush=True); time.sleep(3)"],
        cwd=str(tmp_path),
        timeout=5,
        stall_timeout=0.2,
    )
    assert result.stalled
    assert b"started" in result.output


async def test_local_pty_stop_ends_an_interactive_session(tmp_path):
    transport = LocalPtyTransport()
    node_id = uuid.uuid4()
    task = asyncio.create_task(
        transport.run(
            node_id,
            [sys.executable, "-c", "import time; time.sleep(10)"],
            cwd=str(tmp_path),
            timeout=5,
        )
    )
    for _ in range(100):
        if transport.snapshot(node_id).get("active"):
            break
        await asyncio.sleep(0.01)
    assert await transport.stop(node_id)
    result = await task
    assert result.returncode != 0


async def test_detached_quiet_terminal_is_reaped_after_grace_period(tmp_path):
    transport = LocalPtyTransport()
    result = await transport.run(
        uuid.uuid4(),
        [sys.executable, "-c", "import time; print('started', flush=True); time.sleep(3)"],
        cwd=str(tmp_path),
        timeout=None,
        stall_timeout=None,
        idle_warning=0.05,
        idle_reap=0.2,
    )
    assert result.idle_reaped
    assert result.returncode != 0


async def test_attached_terminal_is_not_reaped_while_quiet(tmp_path):
    transport = LocalPtyTransport()
    node_id = uuid.uuid4()
    task = asyncio.create_task(
        transport.run(
            node_id,
            [sys.executable, "-c", "import time; print('started', flush=True); time.sleep(.35)"],
            cwd=str(tmp_path),
            timeout=2,
            stall_timeout=None,
            idle_warning=0.05,
            idle_reap=0.1,
        )
    )
    for _ in range(100):
        if transport.snapshot(node_id).get("active"):
            break
        await asyncio.sleep(0.01)
    queue = transport.subscribe(node_id)
    result = await task
    transport.unsubscribe(node_id, queue)
    assert result.returncode == 0
    assert not result.idle_reaped


async def test_local_pty_bounds_completed_reconnect_snapshots(tmp_path):
    transport = LocalPtyTransport(backlog_limit=256, completed_session_limit=2)
    ids = [uuid.uuid4() for _ in range(4)]
    for index, node_id in enumerate(ids):
        await transport.run(
            node_id,
            [sys.executable, "-c", f"print('session-{index}')"],
            cwd=str(tmp_path),
            timeout=5,
        )
    assert set(transport.sessions) == set(ids[-2:])
    assert transport.snapshot(ids[0]) == {"active": False, "output": ""}
    assert "session-3" in transport.snapshot(ids[-1])["output"]


async def test_tmux_transport_attaches_to_the_existing_harness_session():
    node_id = uuid.uuid4()
    data_dir = f"/private/tmp/turn-agent-test-{node_id.hex[:8]}"
    first = TmuxPtyTransport(data_dir)
    second = TmuxPtyTransport(data_dir)
    command = [
        sys.executable,
        "-c",
        "import time; print('\\033[32mTMUX_OK\\033[0m', flush=True); time.sleep(3)",
    ]
    first_task = asyncio.create_task(
        first.run(node_id, command, cwd="/private/tmp", timeout=None)
    )
    for _ in range(100):
        if "TMUX_OK" in first.snapshot(node_id).get("output", ""):
            break
        await asyncio.sleep(0.02)
    assert await first.has_persistent_session(node_id)

    second_task = asyncio.create_task(
        second.run(node_id, ["this-command-is-not-used"], cwd="/private/tmp", timeout=None)
    )
    for _ in range(100):
        if "TMUX_OK" in second.snapshot(node_id).get("output", ""):
            break
        await asyncio.sleep(0.02)
    assert "TMUX_OK" in second.snapshot(node_id).get("output", "")

    assert await second.close_persistent_session(node_id)
    await asyncio.gather(first_task, second_task, return_exceptions=True)
