"""Planners.

The initial planner and any later decomposition use the *same* operation:
produce the smallest useful workgraph that can begin executing now.

`CodexPlanner` asks Codex to emit a `turn-plan` JSON block. If Codex is
unavailable or returns nothing usable, it falls back to `HeuristicPlanner` so
the graph always appears and execution can start.
"""
from __future__ import annotations

import asyncio
import json
import os
import re
import shutil
import subprocess
import tempfile
import uuid
from pathlib import Path

from turn.config import settings
from turn.workers import codex_schemas, parsing
from turn.domain.schemas import (
    AgentConfig,
    EdgeSpec,
    EdgeType,
    HarnessKind,
    InputKind,
    InputSpec,
    NodeSpec,
    PlanResult,
    PermissionMode,
    Resource,
    Usage,
)
from turn.workers.base import NodeExecutionContext, Planner, render_context_block
from turn.workers.harnesses import recover_session_id
from turn.workers.interactive import (
    agent_environment,
    opencode_session_ids,
    prepare_result_file,
    read_result_file,
    result_handoff,
    run_until_result,
)
from turn.workers.terminal import GenerationStalled, LocalPtyTransport

_FENCE_RE = re.compile(r"```(\w+)\n(.*?)```", re.DOTALL)


class HeuristicPlanner(Planner):
    """Generic fallback decomposition — domain-agnostic scaffolding.

    Produces a few independent domain lanes and an ordinary executor that
    recomposes their outputs. This keeps the offline fallback representative
    of Turn's architectural model instead of manufacturing a checklist.
    """

    name = "heuristic"

    def __init__(self, default_executor: str = "codex"):
        self.default_executor = default_executor

    async def plan(self, ctx: NodeExecutionContext) -> PlanResult:
        # A root may have a concise project name while its complete intent is
        # stored in generated_prompt. Keep graph-card objectives compact and
        # put the authoritative detail in the execution prompt.
        objective = ctx.node.generated_prompt or ctx.node.objective
        exe = self.default_executor
        nodes = [
            NodeSpec(
                key="core",
                objective="Define core structure",
                generated_prompt=(
                    f"Own the core concepts, constraints, and invariants for: {objective}. "
                    "Work independently in a domain-appropriate scope directory or output namespace. "
                    "Write the resulting contract and concrete deliverables to files for a later integrator."
                ),
                executor=exe,
            ),
            NodeSpec(
                key="inputs",
                objective="Handle inputs and storage",
                generated_prompt=(
                    f"Own the input, persistence, or source-material boundary for: {objective}. "
                    "Choose a domain-appropriate scope directory or output namespace, document its contract, "
                    "and write the deliverables there so another worker can consume them."
                ),
                executor=exe,
            ),
            NodeSpec(
                key="outputs",
                objective="Create output surface",
                generated_prompt=(
                    f"Own the user-facing, presentation, publishing, or delivery surface for: {objective}. "
                    "Work in a domain-appropriate scope directory or output namespace, state the assumptions "
                    "and invariants you honor, and write concrete deliverables for a later integrator."
                ),
                executor=exe,
            ),
            NodeSpec(
                key="integrate",
                objective="Integrate the deliverable",
                generated_prompt=(
                    f"Read the outputs produced by the core, inputs, and outputs lanes and integrate them into "
                    f"one coherent result for: {objective}. Preserve each lane's contracts, resolve conflicts "
                    "explicitly, run an appropriate end-to-end check, and write the integrated result to the "
                    "assigned project directory or final output namespace. This is ordinary executor work, "
                    "not a planning task."
                ),
                executor=exe,
                depends_on=["core", "inputs", "outputs"],
            ),
        ]
        edges = [
            EdgeSpec(type=EdgeType.DEPENDS_ON, src="core", dst="integrate"),
            EdgeSpec(type=EdgeType.DEPENDS_ON, src="inputs", dst="integrate"),
            EdgeSpec(type=EdgeType.DEPENDS_ON, src="outputs", dst="integrate"),
        ]
        return PlanResult(
            nodes=nodes,
            edges=edges,
            notes="Heuristic architectural decomposition (no LLM planner available).",
        )


class CodexPlanner(Planner):
    """Asks Codex to produce a workgraph as a `turn-plan` JSON block."""

    name = "codex-planner"

    def __init__(self, fallback: Planner | None = None, settings=settings):
        self.s = settings
        self.fallback = fallback

    async def plan(self, ctx: NodeExecutionContext) -> PlanResult:
        prompt = self._build_prompt(ctx)
        cwd = ctx.repo_path or os.getcwd()
        text, usage, session_id = await self._call_codex(
            prompt, cwd, agent=ctx.node.agent,
            stream=getattr(ctx, "stream", None), node_id=ctx.node.id,
            project_id=ctx.node.project_id,
            terminal=ctx.terminal, timeout=ctx.timeout_seconds,
            stall_timeout=ctx.stall_timeout_seconds,
            session_callback=ctx.session_callback,
        )
        plan = AgentPlanner._parse_plan(text, ctx.node.objective)
        if plan is not None and plan.nodes:
            plan.usage = usage
            plan.session_id = session_id
            return plan
        if self.fallback is not None:
            return await self.fallback.plan(ctx)
        return PlanResult(nodes=[], notes="planner produced no nodes")

    def _build_prompt(self, ctx: NodeExecutionContext) -> str:
        return f"""{render_context_block(ctx)}
THIS NODE'S OBJECTIVE:
{ctx.node.objective}

PLANNING INSTRUCTIONS FOR THIS NODE:
{ctx.node.generated_prompt or "No additional planning instructions."}

You are the architect decomposing THIS node into its direct children. Produce
the smallest useful workgraph that exposes the real domains of work and lets
independent work begin in parallel. This is decomposition of a system,
workflow, or body of work — not a chronological checklist.

DECOMPOSITION POLICY — match the structure to the objective:
- ATOMIC step: if the objective is a SINGLE concrete step (it says "one", "a
single", "just one", "the next step", "first step", or names exactly one
action), produce EXACTLY ONE child that performs it. Do NOT pad with
investigate / plan / verify scaffolding.
- BROAD container: if the objective is a wide effort (e.g. "build X",
"create a game", "implement the system", "plan the project"), identify the
genuinely distinct domains, modules, capabilities, or output sections that
make up the result. Prefer 2–5 orthogonal direct children that can proceed in
parallel. Name them in the vocabulary of the domain; do not turn milestones,
tests, or generic review steps into fake domains.
- Prefer one well-specified child over generic multi-step scaffolding. A child
that merely restates this objective is never useful — drop it. Never list the
same sub-task twice, and do NOT create parallel sub-planners that cover the
same scope under different names (e.g. do not make both a "Kanto cities"
planner and a "Kanto guide" planner). Each distinct scope appears exactly once
in the plan. BEFORE you finalize the plan, use the GRAPH EXPLORATION TOOL in
  the context block (python -m turn.tools.graph_explorer --tree) to confirm no
  existing or already-planned node elsewhere in the graph already covers a scope
  you were about to add; if it does, reference or extend that node instead of
  recreating it.

- CARD TITLE (HARD RULE): each child's "objective" MUST be a short
  TITLE-LIKE phrase — at most ~6 words and ~50 characters. It is rendered as
  the graph-card title, so it must be scannable at a glance. Do NOT put a
  sentence, paragraph, or long description in "objective"; put all task detail,
  rationale, file names, and instructions in "generated_prompt".
  GOOD:  "Write chapter 1", "Build the parser", "Style the theme",
         "Assemble the package", "Add the code renderer".
  BAD:   "Design and implement the page-renderer feature area with 2-3
         renderer modules" (too long — move the detail to generated_prompt),
         "Create a comprehensive Markdown->HTML engine and supporting
         renderers for headings, paragraphs, lists and fenced code blocks"
         (paragraph — not a title).
  If you catch yourself writing more than a short title, STOP and move the
  rest into "generated_prompt".

TOPOLOGY — arrange the children to express a left-to-right architectural flow:
- PARALLEL FIRST: independent domain children have NO depends_on. They should
  be able to run at the same time. Parallelism is the normal shape.
- INTEGRATION: when several sibling outputs must be recombined, add an
  ordinary executor child whose objective says integrate, assemble, merge, or
  otherwise recombine. It lists all of those sibling keys in depends_on and
  reads their outputs. Integrators are not a special agent type.
- FINAL INTEGRATION: if there are several branch integrators or major outputs,
  add one final ordinary executor to recombine them into the parent result.
- SEQUENTIAL: use a dependency only when later work truly cannot begin before
  earlier output. Such edges are left-to-right workflow stages and should be
  rare; never use them just to make a checklist or to order unrelated work.
- NESTED PLANNERS: for a sub-domain that is itself broad, set "plan": true
  and "executor": "planner". Do not add a planner at every bifurcation: a
  broad parent may directly create concrete executors and integrators. Nest
  only when the sub-domain genuinely needs another architectural decision.
- LEAF WORK: every node that actually does work (writing code, prose, files)
  gets "executor": "codex" and a concrete "generated_prompt". The generated_prompt
  MUST tell the worker to WRITE its deliverable to a domain-appropriate file,
  directory, section, or other durable output in the assigned working area —
  not merely return text — because downstream integrators read those outputs.
  When separate directories, namespaces, chapters, or collections reduce
  collisions, assign one to each domain child and name it in the prompt. Keep
  this guidance agnostic: a directory may mean a real folder, an output
  namespace, a chapter, or another natural unit for the domain.
  Never use "executor": "echo" for real work; only use "shell" for a single shell
  command (put that command alone in generated_prompt).
- CONTRACTS & INVARIANTS: every child prompt must state the boundary it owns,
  expected inputs and outputs, contracts or invariants, and where its durable
  result lives. An integrator must preserve or reconcile those contracts. Do
  not assume every objective is software; use equivalent concepts for books,
  research, operations, design, or other kinds of generation.
- INTEGRATORS: if a node's job is to combine or integrate its
  prerequisites (objective names 'assemble', 'merge', 'integrate', 'combine',
  'stitch'), its generated_prompt MUST tell it to READ the files those
  prerequisites already produced in the working directory and merge/stitch them.
  A "depends_on" edge means each prerequisite has already run in this same
  assigned project area, so the node should load and integrate those existing
  outputs — never regenerate their content from the prompt text.

ORDER & SAFETY:
- List children in architectural order from left to right: domain branches,
  then their integrators, then any final integration. Prerequisites should
  appear before dependent nodes, but unrelated parallel branches need not be
  artificially serialized.
- Never create a cycle (a step must never depend, directly or transitively, on
  itself).
- Only add "required_inputs" for a genuinely EXTERNAL, human-supplied item — a
  decision, credential, account, approval, or a file the user must provide.
  NEVER use required_inputs to hand data from one step to another: a
  "depends_on" edge already guarantees the prerequisite ran first, and its
  outputs are available to the dependent step as context. If a step needs the
  result of a prior step, DEPEND ON that step; do not block on an input for it.
  Leave required_inputs empty unless a real human gate exists.
- Do NOT create a "coordinator" / "oversee" / "manage" wrapper node — this node
  is already the coordinator.
- Every child is a DIRECT child of this node (parent_key must be null). A
  later planning turn can give a nested planner its own direct children.

Return ONLY a fenced code block labeled `turn-plan` containing JSON:
{{
  "nodes": [
    {{"key":"unique","objective":"...","executor":"codex"|"planner","plan":false|true,"generated_prompt":"...","required_inputs":[{{"id":"x","label":"...","kind":"text|decision|credential|account|approval|file"}}],"resource_refs":[],"parent_key":null,"depends_on":["otherkey"]}}
  ],
  "edges": []
}}
"""

    async def _call_codex(
        self, prompt: str, cwd: str, *, agent: AgentConfig | None = None,
        stream=None, node_id=None, terminal=None, timeout=None, stall_timeout=None,
        session_callback=None, project_id=None,
    ) -> tuple[str, Usage, str | None]:
        if shutil.which(self.s.codex_binary) is None:
            return "", Usage(), None
        transport = terminal or LocalPtyTransport()
        native = isinstance(transport, LocalPtyTransport)
        schema_path: str | None = None
        environment: dict[str, str] | None = None
        if native:
            result_path = prepare_result_file(cwd, node_id, "plan")
            environment = agent_environment(cwd, node_id, "plan", result_path, agent)
            if project_id is not None:
                environment["TURN_PROJECT_ID"] = str(project_id)
            prompt = f"{prompt}\n\n{result_handoff(result_path, plan=True, await_confirmation=False)}"
        else:
            schema_path = codex_schemas.write_schema(codex_schemas.PLAN_SCHEMA)
            result_file = tempfile.NamedTemporaryFile(prefix="turn-plan-", suffix=".json", delete=False)
            result_path = Path(result_file.name)
            result_file.close()
        bypass = any("bypass" in a for a in self.s.codex_args)
        permission = agent.permission if agent else PermissionMode.WORKSPACE
        if bypass or permission == PermissionMode.FULL:
            sandbox_flags = ["--dangerously-bypass-approvals-and-sandbox"]
        elif permission == PermissionMode.ASK:
            sandbox_flags = ["-s", "workspace-write"]
        else:
            sandbox_flags = ["--approve-for-me"]
        model = agent.model if agent and agent.model else self.s.codex_model
        model_flags = ["-m", model] if model else []
        reasoning = agent.reasoning.value if agent else "default"
        reasoning_flags = [] if reasoning == "default" else [
            "-c", f'model_reasoning_effort="{reasoning}"'
        ]
        session_id = agent.session_id if agent else None
        observed_session = session_id

        async def remember_session(session: str) -> None:
            nonlocal observed_session
            observed_session = session
            if session_callback is not None:
                await session_callback(session)
        if native:
            native_args = [
                a for a in self.s.codex_args
                if a not in {
                    "--json", "--skip-git-repo-check", "--output-schema",
                    "--output-last-message", "exec", "resume",
                } and "bypass" not in a
            ]
            if session_id:
                cmd = [
                    self.s.codex_binary, "resume", *model_flags, *reasoning_flags,
                    *sandbox_flags, "--no-alt-screen", "-C", cwd,
                    *native_args, session_id,
                ]
            else:
                cmd = [
                    self.s.codex_binary, *model_flags, *reasoning_flags,
                    *sandbox_flags, "--no-alt-screen", "-C", cwd,
                    *native_args,
                ]
        elif session_id:
            resume_permissions = ["--dangerously-bypass-approvals-and-sandbox"] if bypass else []
            cmd = [
                self.s.codex_binary, "exec", "resume", *model_flags,
                *reasoning_flags, *resume_permissions, "--output-schema",
                schema_path, "--output-last-message", result_path, "--json", session_id, prompt,
            ]
        else:
            cmd = [
                self.s.codex_binary, "exec", *model_flags, *reasoning_flags,
                *sandbox_flags, "--output-schema", schema_path,
                "--output-last-message", result_path, "--json",
                "-C", cwd, *[a for a in self.s.codex_args if "bypass" not in a],
                prompt,
            ]
        structured = ""
        try:
            if native:
                result = await run_until_result(
                    transport,
                    node_id,
                    cmd,
                    cwd=cwd,
                    result_path=result_path,
                    stream=stream,
                    timeout=timeout or self.s.default_run_timeout_seconds,
                    idle_warning=self.s.terminal_idle_warning_seconds,
                    idle_reap=self.s.terminal_idle_reap_seconds,
                    session_callback=remember_session,
                    initial_input=prompt,
                    environment=environment,
                )
            else:
                result = await transport.run(
                    node_id,
                    cmd,
                    cwd=cwd,
                    stream=stream,
                    timeout=timeout or self.s.default_run_timeout_seconds,
                    stall_timeout=stall_timeout,
                    idle_warning=self.s.terminal_idle_warning_seconds,
                    idle_reap=self.s.terminal_idle_reap_seconds,
                )
            if result.stalled:
                raise GenerationStalled(f"planner produced no output for {stall_timeout:g} seconds")
            if native:
                submitted = read_result_file(result_path)
                if submitted is not None:
                    structured = json.dumps(submitted)
            else:
                try:
                    structured = result_path.read_text().strip()
                except OSError:
                    pass
        except asyncio.TimeoutError as error:
            raise GenerationStalled("planner exceeded the run timeout") from error
        except (FileNotFoundError, OSError):
            return "", Usage(), None
        finally:
            for temporary_path in (schema_path, result_path):
                if temporary_path is None:
                    continue
                try:
                    os.unlink(str(temporary_path))
                except OSError:
                    pass
        # Native sessions communicate their plan through the atomic Turn
        # handoff file. Their PTY bytes are deliberately never scanned for
        # JSON; the browser terminal is the only consumer of that stream.
        if native:
            return structured, Usage(), observed_session or session_id

        raw = result.output.decode(errors="replace")
        messages: list[str] = []
        usage = Usage()
        discovered_session = None
        parsed = False
        for line in raw.splitlines():
            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                continue
            if not isinstance(event, dict):
                continue
            parsed = True
            if event.get("type") == "thread.started":
                discovered_session = event.get("thread_id") or event.get("threadId")
            item = event.get("item")
            if isinstance(item, dict) and item.get("type") in ("agent_message", "message"):
                body = item.get("text") or item.get("content")
                if isinstance(body, str):
                    messages.append(body)
            raw_usage = event.get("usage")
            if isinstance(raw_usage, dict):
                usage = Usage(
                    input_tokens=int(raw_usage.get("input_tokens") or 0),
                    cached_input_tokens=int(raw_usage.get("cached_input_tokens") or 0),
                    output_tokens=int(raw_usage.get("output_tokens") or 0),
                    cost_usd=raw_usage.get("cost_usd"),
                )
        return (structured or ("\n".join(messages) if parsed and messages else raw)), usage, discovered_session or observed_session or session_id


class AgentPlanner(Planner):
    """Plan with the harness configured on the planner node.

    The graph keeps one planner operation while this adapter owns provider CLI
    differences. Codex retains schema-constrained output; other installed
    harnesses receive the identical decomposition contract and are parsed by
    the same strict ``PlanResult`` boundary.
    """

    name = "agent-planner"

    def __init__(self, fallback: Planner | None = None, settings=settings):
        self.s = settings
        self.fallback = fallback
        self.codex = CodexPlanner(fallback=fallback, settings=settings)

    async def plan(self, ctx: NodeExecutionContext) -> PlanResult:
        agent = ctx.node.agent or AgentConfig(harness=HarnessKind.CODEX, type_id="planner")
        if agent.harness == HarnessKind.CODEX:
            return await self.codex.plan(ctx)
        if agent.harness not in {HarnessKind.OPENCODE, HarnessKind.PI, HarnessKind.CLAUDE}:
            return await self._fallback(ctx)
        prompt = self.codex._build_prompt(ctx)
        text = await self._call_harness(agent, prompt, ctx)
        plan = AgentPlanner._parse_plan(text, ctx.node.objective)
        if plan is not None and plan.nodes:
            plan.session_id = agent.session_id
            return plan
        return await self._fallback(ctx)

    async def _fallback(self, ctx: NodeExecutionContext) -> PlanResult:
        if self.fallback is not None:
            return await self.fallback.plan(ctx)
        return PlanResult(nodes=[], notes="planner produced no nodes")

    def _command(
        self,
        agent: AgentConfig,
        prompt: str,
        *,
        cwd: str | None = None,
        native: bool = False,
        resume: bool = False,
    ) -> list[str]:
        model = agent.model
        reasoning = agent.reasoning.value
        if agent.harness == HarnessKind.OPENCODE:
            if native:
                cmd = ["opencode", cwd or os.getcwd()]
                if agent.session_id:
                    cmd += ["--session", agent.session_id]
                if model:
                    cmd += ["--model", model]
                cmd += ["--auto"]
                return cmd
            cmd = ["opencode", "run", "--format", "json", "--auto"]
            if agent.session_id:
                cmd += ["--session", agent.session_id]
            if model:
                cmd += ["--model", model]
            if reasoning != "default":
                cmd += ["--variant", reasoning]
            return [*cmd, prompt]
        if agent.harness == HarnessKind.PI:
            if native:
                cmd = ["pi"]
                if agent.session_id:
                    cmd += ["--session" if resume else "--session-id", agent.session_id]
                if model:
                    cmd += ["--model", model]
                if reasoning != "default":
                    cmd += ["--thinking", reasoning]
                cmd += ["--approve"]
                return cmd
            cmd = ["pi", "--print", "--mode", "text", "--approve"]
            if agent.session_id:
                cmd += ["--session-id", agent.session_id]
            if model:
                cmd += ["--model", model]
            if reasoning != "default":
                cmd += ["--thinking", reasoning]
            return [*cmd, prompt]
        if native:
            cmd = ["claude"]
            if agent.session_id:
                cmd += ["--resume", agent.session_id] if resume else ["--session-id", agent.session_id]
            if model:
                cmd += ["--model", model]
            if reasoning != "default":
                cmd += ["--effort", reasoning]
            cmd += ["--permission-mode", "acceptEdits"]
            return cmd
        cmd = ["claude", "--print", "--output-format", "text", "--permission-mode", "acceptEdits"]
        if model:
            cmd += ["--model", model]
        if reasoning != "default":
            cmd += ["--effort", reasoning]
        return [*cmd, prompt]

    async def _call_harness(
        self, agent: AgentConfig, prompt: str, ctx: NodeExecutionContext
    ) -> str:
        binary = {HarnessKind.OPENCODE: "opencode", HarnessKind.PI: "pi", HarnessKind.CLAUDE: "claude"}[agent.harness]
        if shutil.which(binary) is None:
            return ""
        resume = agent.session_id is not None
        if agent.session_id is None:
            # Pi supports an exact project session id. Generate it only for a
            # new planner conversation; a Re-Run clears this field first and
            # therefore receives a genuinely fresh session.
            if agent.harness == HarnessKind.PI:
                agent.session_id = str(uuid.uuid4())
                ctx.node.agent = agent
        try:
            transport = ctx.terminal or LocalPtyTransport()
            native = isinstance(transport, LocalPtyTransport)
            cwd = ctx.repo_path or os.getcwd()
            known_opencode_sessions = (
                set(opencode_session_ids())
                if native and agent.harness == HarnessKind.OPENCODE
                else set()
            )

            async def remember_session(session: str) -> None:
                agent.session_id = session
                ctx.node.agent = agent

            async def probe_session() -> str | None:
                if agent.harness != HarnessKind.OPENCODE:
                    return None
                current = await asyncio.to_thread(opencode_session_ids)
                return next(
                    (item for item in current if item not in known_opencode_sessions),
                    None,
                )

            result_path = (
                prepare_result_file(cwd, ctx.node.id, "plan") if native else None
            )
            environment = (
                agent_environment(cwd, ctx.node.id, "plan", result_path, agent)
                if result_path
                else None
            )
            if environment is not None:
                environment["TURN_PROJECT_ID"] = str(ctx.node.project_id)
            native_prompt = (
                f"{prompt}\n\n{result_handoff(result_path, plan=True, await_confirmation=False)}"
                if result_path
                else prompt
            )
            if native:
                result = await run_until_result(
                    transport,
                    ctx.node.id,
                    self._command(
                        agent,
                        native_prompt,
                        cwd=cwd,
                        native=True,
                        resume=resume,
                    ),
                    cwd=cwd,
                    result_path=result_path,
                    stream=ctx.stream,
                    timeout=ctx.timeout_seconds or self.s.default_run_timeout_seconds,
                    idle_warning=self.s.terminal_idle_warning_seconds,
                    idle_reap=self.s.terminal_idle_reap_seconds,
                    session_callback=remember_session,
                    session_probe=probe_session if agent.harness == HarnessKind.OPENCODE else None,
                    initial_input=native_prompt,
                    environment=environment,
                )
            else:
                result = await transport.run(
                    ctx.node.id,
                    self._command(agent, prompt),
                    cwd=cwd,
                    stream=ctx.stream,
                    timeout=ctx.timeout_seconds or self.s.default_run_timeout_seconds,
                    stall_timeout=ctx.stall_timeout_seconds,
                    idle_warning=self.s.terminal_idle_warning_seconds,
                    idle_reap=self.s.terminal_idle_reap_seconds,
                )
            if result.stalled:
                raise GenerationStalled(f"planner produced no output for {ctx.stall_timeout_seconds:g} seconds")
            text = result.output.decode(errors="replace")
            if native and result_path is not None:
                submitted = read_result_file(result_path)
                text = (
                    f"```turn-plan\n{json.dumps(submitted)}\n```"
                    if submitted is not None
                    else ""
                )
            if agent.harness == HarnessKind.OPENCODE and not agent.session_id:
                agent.session_id = recover_session_id(text)
                if agent.session_id:
                    ctx.node.agent = agent
            return text
        except asyncio.TimeoutError as error:
            raise GenerationStalled("planner exceeded the run timeout") from error
        except (FileNotFoundError, OSError):
            return ""

    COORDINATOR_KEYS = {"coordinator", "oversee", "manage", "coordinate", "co-ordinate"}

    @staticmethod
    def _norm(s: str) -> str:
        return " ".join((s or "").lower().split())

    @staticmethod
    def _parse_plan(text: str, parent_objective: str | None = None) -> PlanResult | None:
        data = parsing.first_plan_json(text)
        if not isinstance(data, dict) or "nodes" not in data:
            return None

        raw_nodes = [
            NodeSpec(
                key=n["key"],
                objective=n["objective"],
                generated_prompt=n.get("generated_prompt"),
                executor=n.get("executor"),
                required_inputs=[
                    InputSpec(
                        id=i["id"],
                        label=i.get("label", i["id"]),
                        kind=parsing.safe_input_kind(i.get("kind")),
                        description=i.get("description"),
                    )
                    for i in n.get("required_inputs", [])
                ],
                resource_refs=list(n.get("resource_refs", [])),
                parent_key=n.get("parent_key"),
                depends_on=list(n.get("depends_on", [])),
                plan=bool(n.get("plan", False)),
            )
            for n in data.get("nodes", [])
        ]

        # 1) Drop redundant "coordinator"/duplicate nodes; reparent their children.
        # A LONE child whose objective merely echoes the parent is the intended
        # single step (e.g. when the user asked for exactly one) — never drop it,
        # or we'd regress to zero children. Only drop a duplicate-objective node
        # when siblings exist (there it's redundant scaffolding).
        parent_norm = AgentPlanner._norm(parent_objective)
        only_child = len(raw_nodes) == 1
        drop = set()
        for n in raw_nodes:
            kn = n.key.strip().lower()
            on = AgentPlanner._norm(n.objective)
            if on and on == parent_norm and not only_child:
                drop.add(n.key)
            elif kn in AgentPlanner.COORDINATOR_KEYS:
                drop.add(n.key)
        if drop:
            for n in raw_nodes:
                if n.parent_key in drop:
                    n.parent_key = None  # reparent to this node

        nodes = [n for n in raw_nodes if n.key not in drop]
        index = {n.key: i for i, n in enumerate(nodes)}

        # 2) Collect dependencies from both per-node depends_on and explicit
        #    edges (domain convention: src is prerequisite, dst dependent). Then enforce a
        #    DAG by keeping only a dependency whose prerequisite appears EARLIER
        #    in the node list (the prompt asks Codex to list in execution order).
        deps: dict[str, set[str]] = {n.key: set(n.depends_on) for n in nodes}
        for e in data.get("edges", []):
            s, d = e.get("src"), e.get("dst")
            if s in deps and d in deps and s != d:
                deps[d].add(s)
        for n in nodes:
            n.depends_on = [
                d for d in deps[n.key] if d in index and index[d] < index[n.key]
            ]

        return PlanResult(nodes=nodes, edges=[], notes=data.get("notes"))
