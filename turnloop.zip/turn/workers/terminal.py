"""Provider-neutral local terminal transport.

Local coding harnesses run inside a real pseudo-terminal so their native ANSI
output is preserved and a connected client can send input or resize the
terminal.  Cloud/API harnesses can implement the same ``TerminalTransport``
protocol later without changing workers, the graph, or the UI websocket.
"""
from __future__ import annotations

import asyncio
import os
import pty
import signal
import shutil
import struct
import termios
import time
import uuid
from dataclasses import dataclass, field
from typing import Awaitable, Callable, Protocol


StreamCallback = Callable[[uuid.UUID, str], Awaitable[None]]
SessionCallback = Callable[[str], Awaitable[None]]


class GenerationStalled(RuntimeError):
    """A live harness stopped producing terminal output."""


@dataclass
class TerminalResult:
    returncode: int
    # Exact bytes emitted by the child PTY. Turn never interprets these bytes;
    # the browser's terminal emulator is the presentation layer.
    output: bytes
    # Compatibility alias for older workers. It is intentionally the same
    # raw stream, never provider-specific presentation.
    display_output: bytes = b""
    stalled: bool = False
    idle_reaped: bool = False


class TerminalTransport(Protocol):
    async def run(
        self,
        node_id: uuid.UUID,
        command: list[str],
        *,
        cwd: str,
        environment: dict[str, str] | None = None,
        stream: StreamCallback | None = None,
        timeout: float | None = None,
        stall_timeout: float | None = None,
        idle_warning: float | None = None,
        idle_reap: float | None = None,
    ) -> TerminalResult: ...

    async def write(self, node_id: uuid.UUID, data: str) -> bool: ...
    async def resize(self, node_id: uuid.UUID, cols: int, rows: int) -> bool: ...
    async def stop(self, node_id: uuid.UUID) -> bool: ...
    def release(self, node_id: uuid.UUID) -> bool: ...
    def snapshot(self, node_id: uuid.UUID) -> dict: ...


@dataclass
class _Session:
    node_id: uuid.UUID
    master_fd: int
    process: asyncio.subprocess.Process
    output: bytearray = field(default_factory=bytearray)
    subscribers: set[asyncio.Queue[str]] = field(default_factory=set)
    started_at: float = field(default_factory=time.monotonic)
    last_output_at: float = field(default_factory=time.monotonic)
    last_input_at: float = field(default_factory=time.monotonic)
    last_activity_at: float = field(default_factory=time.monotonic)
    idle_warning_seconds: float = 300.0
    cols: int = 80
    rows: int = 24
    ended: bool = False
    stalled: bool = False
    idle_reaped: bool = False


class LocalPtyTransport:
    """Run one harness process per node in a POSIX PTY."""

    def __init__(self, backlog_limit: int = 2_000_000, completed_session_limit: int = 32):
        self.sessions: dict[uuid.UUID, _Session] = {}
        self.backlog_limit = backlog_limit
        self.completed_session_limit = completed_session_limit

    @staticmethod
    def _window(fd: int, cols: int, rows: int) -> None:
        import fcntl

        fcntl.ioctl(fd, termios.TIOCSWINSZ, struct.pack("HHHH", rows, cols, 0, 0))

    async def run(
        self,
        node_id: uuid.UUID,
        command: list[str],
        *,
        cwd: str,
        environment: dict[str, str] | None = None,
        stream: StreamCallback | None = None,
        timeout: float | None = None,
        stall_timeout: float | None = None,
        idle_warning: float | None = None,
        idle_reap: float | None = None,
    ) -> TerminalResult:
        master, slave = pty.openpty()
        # Start with a conventional terminal size. The browser sends the
        # fitted size as the first websocket message before it receives a
        # replay, so full-screen TUIs repaint at the real viewport dimensions.
        self._window(slave, 80, 24)
        env = os.environ.copy()
        if environment:
            env.update(environment)
        # The Turn server itself may run with NO_COLOR=1 because it is not an
        # interactive terminal. Do not leak that server presentation setting
        # into a native harness: the child owns a real PTY and should decide
        # its own ANSI color output from the terminal capabilities below.
        env.pop("NO_COLOR", None)
        # Server processes are often launched with TERM=dumb, but a native
        # harness needs a real terminal description to enable its TUI. Keep a
        # caller-provided terminal type when it is useful, while normalizing
        # the non-interactive defaults commonly inherited by web servers.
        if env.get("TERM") in (None, "", "dumb"):
            env["TERM"] = "xterm-256color"
        if env.get("COLORTERM") in (None, "", "dumb"):
            env["COLORTERM"] = "truecolor"
        try:
            process = await asyncio.create_subprocess_exec(
                *command,
                cwd=cwd,
                env=env,
                stdin=slave,
                stdout=slave,
                stderr=slave,
                start_new_session=True,
            )
        finally:
            os.close(slave)
        session = _Session(
            node_id=node_id,
            master_fd=master,
            process=process,
            idle_warning_seconds=idle_warning or 300.0,
        )
        self.sessions[node_id] = session
        loop = asyncio.get_running_loop()
        queue: asyncio.Queue[bytes | None] = asyncio.Queue()

        def readable() -> None:
            try:
                chunk = os.read(master, 65536)
            except OSError:
                chunk = b""
            if chunk:
                queue.put_nowait(chunk)
            else:
                loop.remove_reader(master)
                queue.put_nowait(None)

        loop.add_reader(master, readable)

        async def consume() -> None:
            while True:
                chunk = await queue.get()
                if chunk is None:
                    return
                now = time.monotonic()
                session.last_output_at = now
                session.last_activity_at = now
                session.output.extend(chunk)
                if len(session.output) > self.backlog_limit:
                    del session.output[: len(session.output) - self.backlog_limit]
                # The PTY is the source of truth. Decode only at the transport
                # boundary; never parse or rewrite a harness stream here.
                raw_text = chunk.decode(errors="replace")
                for subscriber in list(session.subscribers):
                    subscriber.put_nowait(raw_text)
                if stream is not None:
                    await stream(node_id, raw_text)

        consumer = asyncio.create_task(consume())
        started = time.monotonic()
        try:
            while process.returncode is None:
                if timeout and time.monotonic() - started >= timeout:
                    self._terminate(session)
                    await self._wait_or_kill(session)
                    raise asyncio.TimeoutError
                if stall_timeout and time.monotonic() - session.last_output_at >= stall_timeout:
                    session.stalled = True
                    self._terminate(session)
                    await self._wait_or_kill(session)
                    break
                if idle_reap and not session.subscribers:
                    idle_for = time.monotonic() - session.last_activity_at
                    if idle_for >= idle_reap:
                        session.idle_reaped = True
                        self._terminate(session)
                        await self._wait_or_kill(session)
                        break
                await asyncio.sleep(0.1)
            await process.wait()
            await consumer
            return TerminalResult(
                process.returncode or 0,
                bytes(session.output),
                bytes(session.output),
                session.stalled,
                session.idle_reaped,
            )
        except asyncio.CancelledError:
            self._terminate(session)
            await self._wait_or_kill(session)
            raise
        finally:
            session.ended = True
            try:
                loop.remove_reader(master)
            except OSError:
                pass
            try:
                os.close(master)
            except OSError:
                pass
            if not consumer.done():
                consumer.cancel()
                await asyncio.gather(consumer, return_exceptions=True)
            for subscriber in list(session.subscribers):
                subscriber.put_nowait("")
            self._evict_completed()

    def _evict_completed(self) -> None:
        """Bound reconnect snapshots; durable transcripts live in the store."""
        completed = sorted(
            (session for session in self.sessions.values() if session.ended),
            key=lambda session: session.started_at,
        )
        for session in completed[: max(0, len(completed) - self.completed_session_limit)]:
            self.sessions.pop(session.node_id, None)

    @staticmethod
    def _terminate(session: _Session) -> None:
        if session.process.returncode is not None:
            return
        try:
            os.killpg(session.process.pid, signal.SIGTERM)
        except (PermissionError, ProcessLookupError):
            return

    @staticmethod
    async def _wait_or_kill(session: _Session) -> None:
        try:
            await asyncio.wait_for(session.process.wait(), timeout=2)
        except asyncio.TimeoutError:
            try:
                os.killpg(session.process.pid, signal.SIGKILL)
            except (PermissionError, ProcessLookupError):
                pass
            await session.process.wait()

    async def write(self, node_id: uuid.UUID, data: str) -> bool:
        session = self.sessions.get(node_id)
        if session is None or session.ended:
            return False
        try:
            os.write(session.master_fd, data.encode())
            now = time.monotonic()
            session.last_input_at = now
            session.last_activity_at = now
            return True
        except OSError:
            return False

    async def stop(self, node_id: uuid.UUID) -> bool:
        session = self.sessions.get(node_id)
        if session is None or session.ended or session.process.returncode is not None:
            return False
        self._terminate(session)
        # Do not leave the runner coroutine polling a process that has already
        # been asked to exit. Interactive shells and a few harness wrappers
        # can ignore SIGTERM; use the same bounded wait/kill path as timeout
        # cleanup so closing a terminal always releases its task and PTY.
        await self._wait_or_kill(session)
        return True

    async def resize(self, node_id: uuid.UUID, cols: int, rows: int) -> bool:
        session = self.sessions.get(node_id)
        if session is None or session.ended:
            return False
        session.cols = max(20, cols)
        session.rows = max(4, rows)
        self._window(session.master_fd, session.cols, session.rows)
        session.last_activity_at = time.monotonic()
        return True

    def release(self, node_id: uuid.UUID) -> bool:
        """Drop a completed PTY and its in-memory replay buffer.

        Durable transcripts live in project state. Keeping completed PTYs
        around is unnecessary and makes a long-running Turn server grow
        memory with every finished node. Active or waiting sessions are never
        released by this method.
        """
        session = self.sessions.get(node_id)
        if session is None or not session.ended:
            return False
        self.sessions.pop(node_id, None)
        return True

    def snapshot(self, node_id: uuid.UUID) -> dict:
        session = self.sessions.get(node_id)
        if session is None:
            return {"active": False, "output": ""}
        now = time.monotonic()
        return {
            "active": not session.ended,
            "stalled": session.stalled,
            "idle": bool(
                not session.ended
                and now - session.last_activity_at >= session.idle_warning_seconds
            ),
            "idle_seconds": max(0, now - session.last_activity_at),
            "output_idle_seconds": max(0, now - session.last_output_at),
            "input_idle_seconds": max(0, now - session.last_input_at),
            "subscribers": len(session.subscribers),
            "idle_reaped": session.idle_reaped,
            "cols": session.cols,
            "rows": session.rows,
            # Reconnects receive the same raw byte stream as live subscribers.
            "output": bytes(session.output).decode(errors="replace"),
        }

    def subscribe(self, node_id: uuid.UUID) -> asyncio.Queue[str]:
        queue: asyncio.Queue[str] = asyncio.Queue()
        session = self.sessions.get(node_id)
        if session is not None:
            session.subscribers.add(queue)
            session.last_activity_at = time.monotonic()
        return queue

    def unsubscribe(self, node_id: uuid.UUID, queue: asyncio.Queue[str]) -> None:
        session = self.sessions.get(node_id)
        if session is not None:
            session.subscribers.discard(queue)


class TmuxPtyTransport(LocalPtyTransport):
    """Attach a browser PTY to a persistent tmux-owned harness process.

    Turn owns the PTY client; tmux owns the harness process. This keeps the
    real interactive session alive when the server or browser disconnects and
    lets a later server instance attach to the same conversation instead of
    starting a second provider process.
    """

    def __init__(
        self,
        data_dir: str,
        backlog_limit: int = 2_000_000,
        completed_session_limit: int = 32,
    ):
        super().__init__(backlog_limit, completed_session_limit)
        self._tmux = shutil.which("tmux")
        self._tmux_socket = os.path.join(data_dir, "tmux.sock")

    def _tmux_command(self, *args: str) -> list[str]:
        return [self._tmux or "tmux", "-S", self._tmux_socket, *args]

    @staticmethod
    def session_name(node_id: uuid.UUID) -> str:
        return f"turn-agent-{node_id.hex}"

    async def has_persistent_session(self, node_id: uuid.UUID) -> bool:
        if not self._tmux:
            return False
        process = await asyncio.create_subprocess_exec(
            *self._tmux_command("has-session", "-t", self.session_name(node_id)),
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.DEVNULL,
        )
        await process.wait()
        return process.returncode == 0

    async def _create_persistent_session(
        self,
        node_id: uuid.UUID,
        command: list[str],
        cwd: str,
        environment: dict[str, str] | None,
    ) -> None:
        if not self._tmux:
            raise RuntimeError("tmux is required for harness terminals")
        os.makedirs(cwd, exist_ok=True)
        os.makedirs(os.path.dirname(self._tmux_socket), exist_ok=True)
        overrides = {
            key: value
            for key, value in (environment or {}).items()
            if key not in {"NO_COLOR", "TERM", "COLORTERM"}
        }
        launch = [
            "env",
            "-u",
            "NO_COLOR",
            "TERM=xterm-256color",
            "COLORTERM=truecolor",
            *(f"{key}={value}" for key, value in overrides.items()),
            *command,
        ]
        process = await asyncio.create_subprocess_exec(
            *self._tmux_command(
                "new-session",
                "-d",
                "-s",
                self.session_name(node_id),
                "-c",
                cwd,
                "--",
                *launch,
            ),
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.PIPE,
        )
        await process.wait()
        if process.returncode != 0:
            error = await process.stderr.read() if process.stderr else b""
            raise RuntimeError(
                "unable to create persistent harness terminal: "
                + error.decode(errors="replace").strip()
            )
        configure = await asyncio.create_subprocess_exec(
            *self._tmux_command(
                "set-option",
                "-t",
                self.session_name(node_id),
                "history-limit",
                "5000",
            ),
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.DEVNULL,
        )
        await configure.wait()
        if not await self.has_persistent_session(node_id):
            raise RuntimeError("persistent harness terminal disappeared after launch")

    async def run(
        self,
        node_id: uuid.UUID,
        command: list[str],
        *,
        cwd: str,
        environment: dict[str, str] | None = None,
        stream: StreamCallback | None = None,
        timeout: float | None = None,
        stall_timeout: float | None = None,
        idle_warning: float | None = None,
        idle_reap: float | None = None,
    ) -> TerminalResult:
        if not self._tmux:
            raise RuntimeError("tmux is required for harness terminals")
        if not await self.has_persistent_session(node_id):
            await self._create_persistent_session(node_id, command, cwd, environment)
        attach = self._tmux_command(
            "attach-session", "-t", self.session_name(node_id)
        )
        return await super().run(
            node_id,
            attach,
            cwd=cwd,
            environment=environment,
            stream=stream,
            timeout=timeout,
            stall_timeout=stall_timeout,
            idle_warning=idle_warning,
            idle_reap=idle_reap,
        )

    async def close_persistent_session(self, node_id: uuid.UUID) -> bool:
        if not self._tmux:
            return False
        process = await asyncio.create_subprocess_exec(
            *self._tmux_command("kill-session", "-t", self.session_name(node_id)),
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.DEVNULL,
        )
        await process.wait()
        return process.returncode == 0
