"""Helpers for native, file-completing interactive harness sessions."""
from __future__ import annotations

import asyncio
import json
import os
import time
import uuid
from pathlib import Path
import re
import shutil
import subprocess
import sys
from typing import Any, Awaitable, Callable


def _new_codex_session_id(cwd: str, started_at: float) -> str | None:
    """Find the session file Codex creates for a newly launched TUI.

    Codex does not print its conversation id in the native screen, but it
    writes a small metadata record before the first turn. Observing that
    local file keeps the lifecycle code provider-neutral while still making
    fresh sessions resumable after an idle reap.
    """
    codex_home = Path(os.getenv("CODEX_HOME", str(Path.home() / ".codex")))
    root = codex_home / "sessions"
    try:
        candidates = sorted(
            root.rglob("rollout-*.jsonl"),
            key=lambda item: item.stat().st_mtime,
            reverse=True,
        )
    except (FileNotFoundError, OSError):
        return None
    target = os.path.realpath(cwd)
    for path in candidates:
        try:
            if path.stat().st_mtime < started_at - 2:
                break
            with path.open() as handle:
                first = json.loads(handle.readline())
            payload = first.get("payload") if isinstance(first, dict) else None
            if not isinstance(payload, dict):
                continue
            if os.path.realpath(str(payload.get("cwd") or "")) != target:
                continue
            identifier = payload.get("session_id")
            if isinstance(identifier, str) and identifier:
                return identifier
        except (OSError, ValueError, json.JSONDecodeError):
            continue
    return None


def prepare_result_file(cwd: str, node_id: uuid.UUID, kind: str) -> Path:
    """Return the generated handoff path for one assigned project/node."""
    path = Path(cwd) / ".turn" / "interactive" / f"{node_id}.{kind}.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        path.unlink()
    except FileNotFoundError:
        pass
    return path


def agent_environment(
    cwd: str, node_id: uuid.UUID, kind: str, handoff: Path, agent: Any | None = None
) -> dict[str, str]:
    """Build the small, harness-neutral control-plane environment.

    The ``TURN_AGENT_*`` values are launch metadata, not a second terminal
    protocol. They let a harness adapter or a project-local wrapper configure
    skills, tools, and MCP servers without inspecting terminal output.
    """
    def csv(name: str) -> str:
        return ",".join(str(value) for value in (getattr(agent, name, None) or []))

    status = handoff.parent / f"{node_id}.status.json"
    return {
        "TURN_NODE_ID": str(node_id),
        "TURN_PROJECT_ID": os.getenv("TURN_PROJECT_ID", ""),
        "TURN_REPO": str(Path(cwd).resolve()),
        "TURN_HANDOFF_KIND": kind,
        "TURN_HANDOFF_FILE": str(handoff),
        "TURN_STATUS_FILE": str(status),
        "TURN_CLI": f"{sys.executable} -m turn",
        "TURN_HARNESS": str(getattr(getattr(agent, "harness", None), "value", "") or ""),
        "TURN_AGENT_MODEL": str(getattr(agent, "model", None) or ""),
        "TURN_AGENT_REASONING": str(getattr(getattr(agent, "reasoning", None), "value", "") or ""),
        "TURN_AGENT_SKILLS": csv("skills"),
        "TURN_AGENT_TOOLS": csv("tools"),
        "TURN_AGENT_MCP_SERVERS": csv("mcp_servers"),
    }


def read_result_file(path: Path) -> dict[str, Any] | None:
    """Read an atomically-written JSON handoff, rejecting partial/invalid data."""
    try:
        value = json.loads(path.read_text())
    except (FileNotFoundError, OSError, json.JSONDecodeError):
        return None
    return value if isinstance(value, dict) else None


def opencode_session_ids(binary: str = "opencode") -> list[str]:
    """Read OpenCode's own session index without coupling Turn to its storage."""
    if shutil.which(binary) is None:
        return []
    try:
        completed = subprocess.run(
            [binary, "session", "list"],
            capture_output=True,
            text=True,
            timeout=3,
        )
    except (OSError, subprocess.TimeoutExpired):
        return []
    return list(dict.fromkeys(re.findall(r"ses_[A-Za-z0-9]+", completed.stdout)))


async def run_until_result(
    transport: Any,
    node_id: uuid.UUID,
    command: list[str],
    *,
    cwd: str,
    result_path: Path,
    stream=None,
    timeout: float | None = None,
    idle_warning: float | None = None,
    idle_reap: float | None = None,
    session_callback=None,
    session_probe: Callable[[], Awaitable[str | None]] | None = None,
    initial_input: str | None = None,
    environment: dict[str, str] | None = None,
):
    """Keep a native TUI alive until it submits its result file.

    The process remains a normal interactive PTY while the agent works. The
    file is only a completion signal; all terminal bytes continue flowing to
    the browser and browser input continues flowing back to the PTY. Native
    sessions have no whole-run timeout. A detached, quiet process is reaped
    only after the shared terminal idle grace period so forgotten processes do
    not accumulate.
    """
    task = asyncio.create_task(
        transport.run(
            node_id,
            command,
            cwd=cwd,
            environment=environment,
            stream=stream,
            # A native TUI can legitimately be quiet while the model thinks
            # or while it waits for the user. Native sessions are deliberately
            # indefinite; `timeout` is retained for call-site compatibility.
            timeout=None,
            stall_timeout=None,
            idle_warning=idle_warning,
            idle_reap=idle_reap,
        )
    )
    if initial_input:
        # Native Codex must be started without a positional prompt. Passing
        # one on the command line makes the CLI run a single non-interactive
        # turn and exit at the very moment the user should be able to confirm
        # or correct the result. Send the first message through the PTY so the
        # process remains the same interactive conversation as a normal `codex`
        # invocation.
        for _ in range(50):
            snapshot = transport.snapshot(node_id)
            if task.done():
                break
            if snapshot.get("active") and snapshot.get("output"):
                # Codex's native process becomes writable before its composer
                # is painted. Give the TUI a short settling window so the
                # first message is not lost in startup noise.
                # PTY output starts with terminal capability probes. Allow
                # the interactive program to finish its first paint before
                # injecting the initial message; sending while a TUI is still
                # negotiating capabilities is indistinguishable from a user
                # typing into a half-started terminal and is flaky across
                # harnesses.
                await asyncio.sleep(2.5)
                break
            await asyncio.sleep(0.1)
        if not task.done():
            # Keep the submit key as a separate PTY event.  Codex renders a
            # long first message as pasted content; appending Enter to that
            # same write can leave the message in the composer instead of
            # submitting it.
            # This is ordinary PTY input. Preserve line breaks and spacing so
            # the harness receives exactly the same instruction the user
            # selected in Turn; the transport does not parse it.
            # Deliver the instruction as a standard terminal bracketed paste,
            # in bounded chunks. A single large write can overflow the PTY's
            # canonical input buffer (and has caused native TUIs to crash),
            # while bracketed paste preserves newlines without submitting
            # them as separate messages. The transport still treats every
            # byte as opaque terminal input.
            paste = f"\x1b[200~{initial_input}\x1b[201~"
            for offset in range(0, len(paste), 512):
                await transport.write(node_id, paste[offset : offset + 512])
                await asyncio.sleep(0.01)
            await asyncio.sleep(0.25)
            await transport.write(node_id, "\r")
    started_at = time.time()
    discovered_session: str | None = None
    last_probe = 0.0
    try:
        while not task.done():
            if session_callback is not None and discovered_session is None:
                discovered_session = _new_codex_session_id(cwd, started_at)
                if discovered_session:
                    await session_callback(discovered_session)
            if session_probe is not None and discovered_session is None:
                now = time.monotonic()
                if now - last_probe >= 0.5:
                    last_probe = now
                    try:
                        candidate = await session_probe()
                    except Exception:
                        candidate = None
                    if candidate:
                        discovered_session = candidate
                        if session_callback is not None:
                            await session_callback(candidate)
            if read_result_file(result_path) is not None:
                await transport.stop(node_id)
                break
            await asyncio.sleep(0.1)
        return await task
    except asyncio.CancelledError:
        await transport.stop(node_id)
        await asyncio.gather(task, return_exceptions=True)
        raise


def result_handoff(
    path: Path, *, plan: bool = False, await_confirmation: bool = True
) -> str:
    """Prompt fragment for the harness-neutral Turn control plane."""
    if plan:
        shape = '{"nodes":[{"key":"unique","objective":"Short title","executor":"codex","generated_prompt":"Detailed instructions","depends_on":[]}],"edges":[]}'
    else:
        shape = '{"outcome":"COMPLETE","summary":"What happened","missing_inputs":[]}'
    kind = "plan" if plan else "result"
    confirmation = (
        "When you believe the work is complete, explain the result and ask the user to confirm in this terminal conversation. Keep the session open for feedback. Submit only after the user confirms."
        if await_confirmation
        else "When the plan is complete, submit it and let Turn continue."
    )
    return f"""
TURN CONTROL PLANE:
This is an ordinary terminal session. Use the harness normally: type, run
commands, inspect files, and communicate with the user here. Turn does not
parse or summarize your terminal output.

Publish status when useful:
  {sys.executable} -m turn agent status --state working --message "..."

For the final {kind}, create one JSON object matching this shape:
{shape}
Then submit it through the Turn CLI (the command performs the atomic handoff):
  {sys.executable} -m turn agent submit --kind {kind} --file {path}

{confirmation}
""".strip()
