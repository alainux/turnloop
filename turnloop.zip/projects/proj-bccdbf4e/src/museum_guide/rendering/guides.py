"""Render normalized exhibits and analytics as HTML or plain text.

The renderer boundary intentionally accepts mapping-shaped contracts rather than
importing ingestion or analytics modules.  An exhibit may contain ``id``,
``title``, ``description``, ``artist`` or ``creators``, ``date``, ``location``,
``themes``, ``accessibility`` and ``media``.  Analytics is optional and may
contain ``theme_counts``/``themes`` and ``exhibit_count``.  Unknown fields are
ignored.  Missing values render as a small, explicit omission rather than an
exception.
"""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from html import escape
import re
from typing import Any

_CONTROL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")
_SPACE = re.compile(r"\s+")
_SLUG = re.compile(r"[^a-z0-9]+")


def _value(item: Any, key: str, default: Any = None) -> Any:
    if isinstance(item, Mapping):
        return item.get(key, default)
    return getattr(item, key, default)


def _text(value: Any, default: str = "") -> str:
    if value is None:
        return default
    if isinstance(value, (str, int, float)):
        value = str(value)
    else:
        return default
    return _SPACE.sub(" ", _CONTROL.sub("", value)).strip()


def _items(value: Any) -> list[Any]:
    if value is None or isinstance(value, (str, bytes, Mapping)):
        return []
    try:
        return list(value)
    except TypeError:
        return []


def _label(value: Any) -> str:
    if isinstance(value, Mapping):
        return _text(value.get("name") or value.get("label") or value.get("title"))
    for key in ("name", "label", "title", "display", "value"):
        found = getattr(value, key, None)
        if found is not None and not callable(found):
            return _text(found)
    return _text(value)


def _exhibits(value: Iterable[Any] | None) -> list[Any]:
    return [] if value is None else list(value)


def _anchor(exhibit: Any, used: set[str]) -> str:
    base = _SLUG.sub("-", _text(_value(exhibit, "id") or _value(exhibit, "title"), "exhibit" ).lower()).strip("-") or "exhibit"
    slug, index = base, 2
    while slug in used:
        slug = f"{base}-{index}"
        index += 1
    used.add(slug)
    return slug


def _creators(exhibit: Any) -> list[str]:
    values = _items(_value(exhibit, "creators")) or _items(_value(exhibit, "artists")) or [_value(exhibit, "artist")]
    return [name for name in (_label(v) for v in values) if name]


def _themes(exhibit: Any) -> list[str]:
    return [name for name in (_label(v) for v in _items(_value(exhibit, "themes"))) if name]


def _analytics_lines(analytics: Any) -> list[tuple[str, str]]:
    if not analytics:
        return []
    count = _value(analytics, "exhibit_count")
    lines = [("Exhibits", _text(count))] if count is not None else []
    counts = _value(analytics, "theme_counts")
    if counts is None:
        themes = _value(analytics, "themes")
        if isinstance(themes, (list, tuple)):
            counts = {item.get("theme"): item.get("total_score", 0) for item in themes if isinstance(item, Mapping)}
        else:
            counts = themes
    if isinstance(counts, Mapping):
        for name in sorted(counts, key=lambda key: _text(key).casefold()):
            lines.append((_text(name), _text(counts[name], "0")))
    return [(key, value) for key, value in lines if key and value]


def render_html(exhibits: Iterable[Any] | None, analytics: Any = None, *, title: str = "Museum Exhibit Guide") -> str:
    """Return a complete, UTF-8-friendly HTML document with semantic landmarks."""
    title = _text(title, "Museum Exhibit Guide") or "Museum Exhibit Guide"
    records, used = _exhibits(exhibits), set()
    anchors = [_anchor(record, used) for record in records]
    out = [
        "<!doctype html>", '<html lang="en">', "<head>", '<meta charset="utf-8">',
        '<meta name="viewport" content="width=device-width, initial-scale=1">',
        f"<title>{escape(title, quote=True)}</title>", "</head>", "<body>",
        '<a class="skip-link" href="#main-content">Skip to main content</a>',
        f"<header><h1>{escape(title)}</h1></header>", '<nav aria-label="Exhibits"><h2>Exhibits</h2><ol>',
    ]
    for record, anchor in zip(records, anchors):
        name = _text(_value(record, "title"), "Untitled exhibit")
        out.append(f'<li><a href="#{escape(anchor, quote=True)}">{escape(name)}</a></li>')
    out.extend(["</ol></nav>", '<main id="main-content">'])
    summary = _analytics_lines(analytics)
    if summary:
        out.extend(["<section aria-labelledby=\"summary-heading\"><h2 id=\"summary-heading\">Guide summary</h2><dl>"])
        for key, value in summary:
            out.extend([f"<dt>{escape(key)}</dt><dd>{escape(value)}</dd>"])
        out.append("</dl></section>")
    if not records:
        out.append("<p>No exhibits are available.</p>")
    for record, anchor in zip(records, anchors):
        name = _text(_value(record, "title"), "Untitled exhibit")
        description = _text(_value(record, "description"))
        out.extend([f'<article id="{escape(anchor, quote=True)}" aria-labelledby="{escape(anchor, quote=True)}-heading">', f'<h2 id="{escape(anchor, quote=True)}-heading">{escape(name)}</h2>'])
        metadata = []
        for key, label in (("artist", "Artist"), ("date", "Date"), ("location", "Location")):
            raw = _value(record, key)
            if key == "date" and raw is not None:
                raw = _value(raw, "display", raw)
            if key == "location" and raw is not None and not isinstance(raw, (str, int, float)):
                raw = ", ".join(filter(None, (_label(_value(raw, part)) for part in ("gallery", "room", "floor", "building"))))
            value = _label(raw)
            if value: metadata.append(f"<dt>{label}</dt><dd>{escape(value)}</dd>")
        creators = _creators(record)
        if creators: metadata.append(f"<dt>Creator</dt><dd>{escape(', '.join(creators))}</dd>")
        if metadata: out.extend(["<dl>", *metadata, "</dl>"])
        if description: out.append(f"<p>{escape(description)}</p>")
        themes = _themes(record)
        if themes: out.append(f"<p><strong>Themes:</strong> {escape(', '.join(themes))}</p>")
        access = _value(record, "accessibility")
        access_text = _text(access) if isinstance(access, str) else _text(_value(access, "description") or _value(access, "plain_language_summary") or _value(access, "audio_description") or _value(access, "notes"))
        if access_text: out.append(f'<aside aria-label="Accessibility information"><strong>Accessibility:</strong> {escape(access_text)}</aside>')
        out.append("</article>")
    out.extend(["</main>", '<footer><p>Published as an offline guide.</p></footer>', "</body>", "</html>", ""])
    return "\n".join(out)


def render_text(exhibits: Iterable[Any] | None, analytics: Any = None, *, title: str = "Museum Exhibit Guide") -> str:
    """Return a stable, screen-reader-friendly text guide with no markup."""
    title = _text(title, "Museum Exhibit Guide") or "Museum Exhibit Guide"
    records = _exhibits(exhibits)
    lines = [title, "=" * len(title), ""]
    summary = _analytics_lines(analytics)
    if summary:
        lines += ["GUIDE SUMMARY", "-------------", *[f"{key}: {value}" for key, value in summary], ""]
    if not records:
        lines += ["No exhibits are available.", ""]
    for number, record in enumerate(records, 1):
        name = _text(_value(record, "title"), "Untitled exhibit")
        lines += [f"{number}. {name}", "-" * (len(name) + 3)]
        creators = _creators(record)
        if creators: lines.append(f"Creator: {', '.join(creators)}")
        for key, label in (("date", "Date"), ("location", "Location")):
            raw = _value(record, key)
            if key == "date" and raw is not None: raw = _value(raw, "display", raw)
            if key == "location" and raw is not None and not isinstance(raw, (str, int, float)):
                raw = ", ".join(filter(None, (_label(_value(raw, part)) for part in ("gallery", "room", "floor", "building"))))
            value = _label(raw)
            if value: lines.append(f"{label}: {value}")
        description = _text(_value(record, "description"))
        if description: lines.append(f"Description: {description}")
        themes = _themes(record)
        if themes: lines.append(f"Themes: {', '.join(themes)}")
        access = _value(record, "accessibility")
        access_text = _text(access) if isinstance(access, str) else _text(_value(access, "description") or _value(access, "plain_language_summary") or _value(access, "audio_description") or _value(access, "notes"))
        if access_text: lines.append(f"Accessibility: {access_text}")
        lines.append("")
    return "\n".join(lines)
