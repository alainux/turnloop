# Guide rendering contract

`render_html(exhibits, analytics=None, *, title=...)` and
`render_text(...)` accept iterable normalized exhibit records and an optional
analytics mapping. Records are mapping- or attribute-shaped and may provide
`id`, `title`, `description`, `artist`, `creators`, `date`, `location`,
`themes`, and `accessibility`. Analytics may provide `exhibit_count` and a
`theme_counts` mapping. Optional values and empty inputs are valid.

HTML is a complete deterministic document with one language declaration, a
skip link, labeled navigation, a single main landmark, article-per-exhibit
sections, heading relationships, and escaped text. No supplied value is
treated as markup. Plain text contains no control characters or markup, uses
stable headings and numbered exhibits, and preserves all available descriptive
and accessibility text. Input order is preserved; analytics theme keys are
sorted case-insensitively.
