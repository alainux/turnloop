"""Deterministic analytics for the normalized exhibit contract.

The module intentionally consumes mappings or attribute-bearing model objects;
it does not import or recreate the content ingestion model.  See CONTRACT.md.
"""

from __future__ import annotations

import json
import re
from collections import Counter, defaultdict
from collections.abc import Iterable, Mapping
from typing import Any

_WORD_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9'-]*")

# Small, explainable vocabulary.  Matching is against normalized searchable
# text and is deliberately case-insensitive and deterministic.
THEME_RULES: dict[str, tuple[str, ...]] = {
    "identity": ("identity", "portrait", "self", "community", "belonging"),
    "nature": ("nature", "landscape", "river", "forest", "animal", "ecology"),
    "technology": ("technology", "machine", "digital", "engine", "science", "code"),
    "migration": ("migration", "journey", "border", "diaspora", "departure", "arrival"),
    "memory": ("memory", "archive", "remember", "history", "heritage", "memory"),
}


def _value(item: Any, key: str, default: Any = None) -> Any:
    if isinstance(item, Mapping):
        return item.get(key, default)
    return getattr(item, key, default)


def _items(value: Any) -> list[Any]:
    if value is None or isinstance(value, (str, bytes)):
        return [] if value is None else [value]
    if isinstance(value, Iterable):
        return list(value)
    return [value]


def _text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, Mapping):
        return " ".join(str(v) for v in value.values() if v is not None)
    return str(value)


def _label(value: Any) -> str:
    if isinstance(value, (str, int, float)):
        return str(value)
    if isinstance(value, Mapping):
        for key in ("name", "label", "title", "id", "value"):
            if value.get(key) is not None:
                return str(value[key])
    for key in ("name", "label", "title", "id", "value"):
        found = getattr(value, key, None)
        if found is not None:
            return str(found)
    return str(value)


def _id(exhibit: Any) -> str:
    result = _value(exhibit, "id")
    if result is None or str(result) == "":
        raise ValueError("every exhibit must have a non-empty id")
    return str(result)


def _search_text(exhibit: Any) -> str:
    fields = [_value(exhibit, key, "") for key in ("title", "description", "summary", "tags", "keywords", "materials")]
    return " ".join(_text(part) for field in fields for part in _items(field)).casefold()


def derive_themes(exhibit: Any) -> list[dict[str, Any]]:
    """Return sorted explainable assignments: ``theme``, ``score``, ``matches``."""
    text = _search_text(exhibit)
    words = set(_WORD_RE.findall(text))
    assignments = []
    for theme, terms in THEME_RULES.items():
        matches = sorted(term for term in terms if term.casefold() in words)
        if matches:
            assignments.append({"theme": theme, "score": len(matches), "matches": matches})
    assignments.sort(key=lambda entry: (-entry["score"], entry["theme"]))
    return assignments


def _date_label(exhibit: Any) -> str | None:
    value = _value(exhibit, "date")
    if value is None:
        value = _value(exhibit, "date_display")
    return None if value in (None, "") else _label(value)


def _location_label(exhibit: Any) -> str | None:
    value = _value(exhibit, "location")
    return None if value in (None, "") else _label(value)


def analyze_exhibits(exhibits: Iterable[Any]) -> dict[str, Any]:
    """Build a JSON-ready analytics report from normalized exhibits.

    Input is materialized once, validated for unique string-like IDs, and
    never mutated.  Every list in the result is deterministically sorted.
    Empty input returns the same complete shape with zero/empty values.
    """
    records = list(exhibits)
    ids = [_id(exhibit) for exhibit in records]
    if len(set(ids)) != len(ids):
        raise ValueError("exhibit ids must be unique")

    artists: Counter[str] = Counter()
    media: Counter[str] = Counter()
    dates: Counter[str] = Counter()
    locations: Counter[str] = Counter()
    relationships: Counter[tuple[str, str]] = Counter()
    theme_exhibits: defaultdict[str, list[str]] = defaultdict(list)
    theme_scores: defaultdict[str, int] = defaultdict(int)

    for exhibit, exhibit_id in zip(records, ids):
        for artist in _items(_value(exhibit, "artists", _value(exhibit, "creators", []))):
            artists[_label(artist)] += 1
        for medium in _items(_value(exhibit, "media", _value(exhibit, "mediums", []))):
            media[_label(medium)] += 1
        if (date := _date_label(exhibit)) is not None:
            dates[date] += 1
        if (location := _location_label(exhibit)) is not None:
            locations[location] += 1
        for relation in _items(_value(exhibit, "relationships", _value(exhibit, "related_exhibits", []))):
            target = _value(relation, "id", relation) if not isinstance(relation, str) else relation
            if target is not None and str(target) != exhibit_id:
                relationships[(exhibit_id, str(target))] += 1
        for assignment in derive_themes(exhibit):
            theme = assignment["theme"]
            theme_exhibits[theme].append(exhibit_id)
            theme_scores[theme] += assignment["score"]

    return {
        "schema_version": 1,
        "exhibit_count": len(records),
        "counts": {
            "exhibits": len(records),
            "artists": sum(artists.values()),
            "unique_artists": len(artists),
            "media": sum(media.values()),
            "unique_media": len(media),
            "relationships": sum(relationships.values()),
        },
        "artists": [{"name": name, "exhibit_count": artists[name]} for name in sorted(artists)],
        "media": [{"name": name, "exhibit_count": media[name]} for name in sorted(media)],
        "dates": [{"label": label, "exhibit_count": dates[label]} for label in sorted(dates)],
        "locations": [{"label": label, "exhibit_count": locations[label]} for label in sorted(locations)],
        "relationships": [
            {"source_id": source, "target_id": target, "count": relationships[(source, target)]}
            for source, target in sorted(relationships)
        ],
        "themes": [
            {"theme": theme, "exhibit_ids": sorted(theme_exhibits[theme]), "total_score": theme_scores[theme]}
            for theme in sorted(theme_exhibits)
        ],
    }


def serialize_report(report: Mapping[str, Any]) -> str:
    """Serialize a report in stable compact JSON for renderers and files."""
    return json.dumps(report, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
