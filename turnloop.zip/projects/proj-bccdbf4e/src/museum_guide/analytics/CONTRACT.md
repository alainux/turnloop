# Analytics contract

`analyze_exhibits(exhibits)` accepts an iterable of normalized exhibit records.
Records may be mappings or objects and must expose a non-empty unique `id`.
The model boundary supplies these optional fields: `title`, `description` (or
`summary`), `tags`, `keywords`, `materials`, `artists` (or `creators`),
`media` (or `mediums`), `date` (or `date_display`), `location`, and
`relationships` (or `related_exhibits`). Relationship entries are IDs or
objects with an `id`; artist/media/location entries are strings or objects with
`name`, `label`, `title`, `id`, or `value`.

The result is JSON-ready and has `schema_version`, `exhibit_count`, `counts`,
sorted `artists`, `media`, `dates`, `locations`, `relationships`, and `themes`.
Counts are occurrences across exhibits (not deduplicated except where named
`unique_*`). Lists are sorted by their stable labels/IDs; themes are scored by
the number of exact vocabulary terms found in searchable text and include
`theme`, `score`, and matched terms per exhibit via `derive_themes`. The report
groups theme IDs and total scores for renderer-friendly output. No input is
mutated. Duplicate IDs raise `ValueError`; empty input returns the full shape
with zero counts and empty lists. `serialize_report` emits deterministic JSON.
