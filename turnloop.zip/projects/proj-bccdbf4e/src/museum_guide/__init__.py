"""Offline museum guide publishing domains."""
