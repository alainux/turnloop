import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from museum_guide.publish import publish_catalog


class PublishTests(unittest.TestCase):
    def test_end_to_end_outputs_are_complete_and_repeatable(self):
        source = Path(__file__).parents[1] / "examples" / "exhibits.json"
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory)
            first = publish_catalog(source, output)
            snapshot = {path.name: path.read_text(encoding="utf-8") for path in output.iterdir()}
            second = publish_catalog(source, output)
            self.assertEqual(snapshot, {path.name: path.read_text(encoding="utf-8") for path in output.iterdir()})
            self.assertEqual(first.report, second.report)
            self.assertEqual(sorted(snapshot), ["analytics.json", "index.html", "index.txt"])
            report = json.loads(snapshot["analytics.json"])
            self.assertEqual(report["exhibit_count"], 3)
            self.assertTrue(report["themes"])
            self.assertIn('<main id="main-content">', snapshot["index.html"])
            self.assertIn("GUIDE SUMMARY", snapshot["index.txt"])
            self.assertIn("accessibility:", snapshot["index.txt"].lower())

    def test_cli_reports_invalid_input(self):
        with tempfile.TemporaryDirectory() as directory:
            bad = Path(directory) / "bad.json"
            bad.write_text("{", encoding="utf-8")
            result = subprocess.run([sys.executable, "-m", "museum_guide", str(bad), "-o", str(Path(directory) / "out")], capture_output=True, text=True)
            self.assertNotEqual(result.returncode, 0)
            self.assertIn("cannot read JSON", result.stderr)


if __name__ == "__main__":
    unittest.main()
