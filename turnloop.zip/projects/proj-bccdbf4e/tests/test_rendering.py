from museum_guide.rendering import render_html, render_text


EXHIBITS = [{
    "id": "a-1", "title": "<Sun & Stone>", "artist": "Ada <Lee>",
    "date": "1901", "location": "Gallery 2", "description": "A bright & quiet study.",
    "themes": ["light", "stone"], "accessibility": {"description": "Low light; tactile replica available."},
}]


def test_html_is_semantic_escaped_and_deterministic():
    result = render_html(EXHIBITS, {"exhibit_count": 1, "theme_counts": {"stone": 1, "light": 1}})
    assert result == render_html(EXHIBITS, {"exhibit_count": 1, "theme_counts": {"light": 1, "stone": 1}})
    assert '<main id="main-content">' in result
    assert '<article id="a-1"' in result
    assert "&lt;Sun &amp; Stone&gt;" in result
    assert "Ada &lt;Lee&gt;" in result
    assert "<script" not in result
    assert 'aria-label="Accessibility information"' in result


def test_text_contains_content_without_markup():
    result = render_text(EXHIBITS)
    assert "1. <Sun & Stone>" in result
    assert "Creator: Ada <Lee>" in result
    assert "Accessibility: Low light; tactile replica available." in result
    assert "<article" not in result


def test_empty_and_missing_optional_fields_are_valid():
    assert "No exhibits are available." in render_html([])
    assert "No exhibits are available." in render_text([])
    assert "Untitled exhibit" in render_html([{}])
    assert "Untitled exhibit" in render_text([{"title": None}])


def test_control_characters_are_removed_from_plain_text_and_html():
    assert "\x00" not in render_text([{"title": "A\x00\nB"}])
    assert "\x00" not in render_html([{"title": "A\x00\nB"}])
