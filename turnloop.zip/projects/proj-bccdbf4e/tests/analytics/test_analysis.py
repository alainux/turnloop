import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parents[2] / "src"))

from museum_guide.analytics import analyze_exhibits, derive_themes
from museum_guide.analytics.analysis import serialize_report


FIXTURES = [
    {"id": "b", "title": "River memory", "description": "A landscape archive", "artists": ["Ada"], "media": ["Photo"], "date": "1900", "location": "Berlin", "relationships": ["a"]},
    {"id": "a", "title": "Digital identity", "tags": ["technology", "portrait"], "artists": ["Ada", "Bo"], "media": ["Film"], "date": "2000", "location": "Paris", "relationships": ["b"]},
]


def test_themes_are_explainable_and_ranked():
    result = derive_themes(FIXTURES[1])
    assert result == [{"theme": "identity", "score": 2, "matches": ["identity", "portrait"]}, {"theme": "technology", "score": 2, "matches": ["digital", "technology"]}]


def test_report_is_complete_sorted_and_json_ready():
    report = analyze_exhibits(FIXTURES)
    assert report["counts"] == {"exhibits": 2, "artists": 3, "unique_artists": 2, "media": 2, "unique_media": 2, "relationships": 2}
    assert [item["name"] for item in report["artists"]] == ["Ada", "Bo"]
    assert report["relationships"] == [{"source_id": "a", "target_id": "b", "count": 1}, {"source_id": "b", "target_id": "a", "count": 1}]
    assert json.loads(serialize_report(report)) == report


def test_empty_report_has_stable_shape():
    report = analyze_exhibits([])
    assert report["exhibit_count"] == 0
    assert report["counts"]["unique_artists"] == 0
    assert all(report[key] == [] for key in ("artists", "media", "dates", "locations", "relationships", "themes"))


def test_duplicate_ids_fail():
    try:
        analyze_exhibits([{"id": "x"}, {"id": "x"}])
    except ValueError as error:
        assert "unique" in str(error)
    else:
        raise AssertionError("duplicate IDs should fail")
