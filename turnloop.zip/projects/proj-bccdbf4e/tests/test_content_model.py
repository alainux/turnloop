import json
import unittest
from pathlib import Path

from museum_guide.content import IngestionError, load_catalog, parse_catalog


class ContentModelTests(unittest.TestCase):
    def test_fixture_is_normalized_and_json_friendly(self):
        catalog = load_catalog(Path(__file__).parents[1] / "examples" / "exhibits.json")
        exhibit = catalog.exhibits[0]
        self.assertEqual(exhibit.id, "exhibit-001")
        self.assertIsNone(exhibit.location.floor)
        self.assertIsInstance(catalog.to_dict()["exhibits"], list)
        json.dumps(catalog.to_dict())

    def test_bare_list_and_blank_optionals(self):
        catalog = parse_catalog([{"id": "x", "title": " X ", "description": "   "}])
        self.assertEqual(catalog.exhibits[0].title, "X")
        self.assertIsNone(catalog.exhibits[0].description)
        self.assertEqual(catalog.exhibits[0].media, ())

    def test_aggregates_pathful_errors(self):
        with self.assertRaises(IngestionError) as raised:
            parse_catalog({"exhibits": [{"title": "Missing id", "media": [{"alt_text": "no uri"}]}]})
        self.assertIn("$.exhibits[0].id", str(raised.exception))
        self.assertIn("$.exhibits[0].media[0].uri", str(raised.exception))

    def test_rejects_duplicate_ids_and_non_boolean_accessibility(self):
        with self.assertRaises(IngestionError) as raised:
            parse_catalog({"exhibits": [
                {"id": "same", "title": "One"},
                {"id": "same", "title": "Two", "accessibility": {"tactile": "no"}},
            ]})
        self.assertIn("duplicates exhibit id", str(raised.exception))
        self.assertIn("tactile must be a boolean", str(raised.exception))


if __name__ == "__main__":
    unittest.main()
