"""Make the nested source checkout importable when pytest roots at the workspace."""

import sys
from pathlib import Path

PROJECT = Path(__file__).parents[1]
SOURCE = PROJECT / "src"
if str(SOURCE) not in sys.path:
    sys.path.append(str(SOURCE))
project_text = str(PROJECT)
while project_text in sys.path:
    sys.path.remove(project_text)
sys.path.insert(0, project_text)

# Import the checkout package after ordering paths; the sibling ``src`` tree
# also has a package named museum_guide and must remain an extension of this
# package rather than shadowing it.
sys.modules.pop("museum_guide", None)
import museum_guide  # noqa: E402,F401
