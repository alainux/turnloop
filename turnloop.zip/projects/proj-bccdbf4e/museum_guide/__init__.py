"""Offline museum guide domain package.

The project keeps independently developed domains in ``src/museum_guide``;
extend this package path so a source checkout can import them alongside the
ingestion package without requiring an installation step.
"""

from pathlib import Path

_source_domains = Path(__file__).parents[1] / "src" / "museum_guide"
if _source_domains.is_dir():
    __path__.append(str(_source_domains))

from .publish import PublishResult, publish_catalog

__all__ = ["PublishResult", "publish_catalog"]
