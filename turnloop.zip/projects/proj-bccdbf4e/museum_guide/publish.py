"""Offline end-to-end catalog publishing workflow.

This module is the integration boundary between the content, analytics, and
rendering branches.  It adapts the immutable content model to the mapping
shapes documented by the downstream branches and writes a small, stable set
of artifacts without network access.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .content import Catalog, load_catalog
from .analytics import analyze_exhibits
from .analytics.analysis import serialize_report
from .rendering import render_html, render_text


@dataclass(frozen=True, slots=True)
class PublishResult:
    """Paths and report produced by :func:`publish_catalog`."""

    html_path: Path
    text_path: Path
    analytics_path: Path
    report: dict[str, Any]


def _render_records(catalog: Catalog) -> list[dict[str, Any]]:
    """Translate model objects to the stable downstream renderer contracts."""
    records = []
    for exhibit in catalog.exhibits:
        records.append({
            "id": exhibit.id,
            "title": exhibit.title,
            "description": exhibit.description,
            "creators": [{"name": creator.name} for creator in exhibit.creators],
            "date": {"display": exhibit.date.display} if exhibit.date else None,
            "location": {
                key: value for key, value in (
                    ("gallery", exhibit.location.gallery), ("room", exhibit.location.room),
                    ("floor", exhibit.location.floor), ("building", exhibit.location.building),
                ) if value
            } if exhibit.location else None,
            "themes": [assignment["theme"] for assignment in _themes(exhibit)],
            "accessibility": {
                "plain_language_summary": exhibit.accessibility.plain_language_summary,
                "audio_description": exhibit.accessibility.audio_description,
                "notes": "; ".join(exhibit.accessibility.notes),
            },
        })
    return records


def _analytics_records(catalog: Catalog) -> list[dict[str, Any]]:
    return [{
        "id": exhibit.id,
        "title": exhibit.title,
        "description": exhibit.description,
        "tags": list(exhibit.tags),
        "creators": [{"name": creator.name} for creator in exhibit.creators],
        "media": [{"name": media.kind} for media in exhibit.media],
        "date": exhibit.date.display if exhibit.date else None,
        "location": ", ".join(filter(None, (
            exhibit.location.gallery, exhibit.location.room,
            exhibit.location.floor, exhibit.location.building,
        ))) if exhibit.location else None,
    } for exhibit in catalog.exhibits]


def _themes(exhibit: Any) -> list[dict[str, Any]]:
    from .analytics import derive_themes
    return derive_themes({"id": exhibit.id, "title": exhibit.title,
                          "description": exhibit.description, "tags": exhibit.tags})


def _write_atomic(path: Path, content: str) -> None:
    temporary = path.with_name(f".{path.name}.tmp")
    temporary.write_text(content, encoding="utf-8")
    temporary.replace(path)


def publish_catalog(input_path: str | Path, output_dir: str | Path) -> PublishResult:
    """Ingest *input_path* and publish deterministic HTML, text, and JSON files."""
    catalog = load_catalog(input_path)
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    report = analyze_exhibits(_analytics_records(catalog))
    records = _render_records(catalog)
    title = catalog.title or "Museum Exhibit Guide"
    html_path, text_path, analytics_path = (output / name for name in (
        "index.html", "index.txt", "analytics.json"))
    _write_atomic(html_path, render_html(records, report, title=title))
    _write_atomic(text_path, render_text(records, report, title=title))
    _write_atomic(analytics_path, serialize_report(report) + "\n")
    return PublishResult(html_path, text_path, analytics_path, report)


def main(argv: list[str] | None = None) -> int:
    import argparse
    parser = argparse.ArgumentParser(description="Publish an offline museum exhibit guide")
    parser.add_argument("input", type=Path, help="catalog JSON file")
    parser.add_argument("-o", "--output", type=Path, default=Path("build/museum-guide"), help="output directory")
    args = parser.parse_args(argv)
    try:
        result = publish_catalog(args.input, args.output)
    except (OSError, ValueError) as exc:
        parser.error(str(exc))
    else:
        print(f"Published {result.html_path}, {result.text_path}, and {result.analytics_path}")
        return 0
    return 2
