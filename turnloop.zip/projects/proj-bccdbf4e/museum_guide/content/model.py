"""Stable, dependency-free normalized content model.

All values are immutable and safe for analytics/rendering code to consume. Optional
text is represented by ``None``; collection fields are always tuples.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True, slots=True)
class DateValue:
    """A displayable date plus optional machine-friendly bounds."""

    display: str
    start_year: int | None = None
    end_year: int | None = None
    circa: bool = False

@dataclass(frozen=True, slots=True)
class Location:
    gallery: str | None = None
    room: str | None = None
    floor: str | None = None
    building: str | None = None

@dataclass(frozen=True, slots=True)
class Media:
    uri: str
    kind: str = "image"
    alt_text: str | None = None
    caption: str | None = None
    credit: str | None = None

@dataclass(frozen=True, slots=True)
class AccessibilityMetadata:
    plain_language_summary: str | None = None
    audio_description: str | None = None
    transcript: str | None = None
    tactile: bool = False
    wheelchair_accessible: bool | None = None
    notes: tuple[str, ...] = ()

@dataclass(frozen=True, slots=True)
class SourceRecord:
    """Provenance for the source material used to create an exhibit record."""

    source_id: str
    title: str | None = None
    uri: str | None = None
    provider: str | None = None
    retrieved: str | None = None
    license: str | None = None
    locator: str | None = None

@dataclass(frozen=True, slots=True)
class Creator:
    id: str
    name: str
    role: str | None = None
    nationality: str | None = None
    dates: DateValue | None = None

@dataclass(frozen=True, slots=True)
class Exhibit:
    id: str
    title: str
    description: str | None = None
    creators: tuple[Creator, ...] = ()
    date: DateValue | None = None
    location: Location | None = None
    media: tuple[Media, ...] = ()
    accessibility: AccessibilityMetadata = field(default_factory=AccessibilityMetadata)
    sources: tuple[SourceRecord, ...] = ()
    tags: tuple[str, ...] = ()

@dataclass(frozen=True, slots=True)
class Catalog:
    exhibits: tuple[Exhibit, ...]
    version: str | None = None
    title: str | None = None
    sources: tuple[SourceRecord, ...] = ()

    def by_id(self) -> dict[str, Exhibit]:
        return {item.id: item for item in self.exhibits}

    def to_dict(self) -> dict[str, Any]:
        """Return a stable JSON-serializable shape for analytics and rendering."""
        return {"version": self.version, "title": self.title,
                "exhibits": [_as_dict(item) for item in self.exhibits],
                "sources": [_as_dict(item) for item in self.sources]}


def _as_dict(value: Any) -> Any:
    if hasattr(value, "__dataclass_fields__"):
        return {name: _as_dict(getattr(value, name)) for name in value.__dataclass_fields__}
    if isinstance(value, tuple):
        return [_as_dict(item) for item in value]
    return value

