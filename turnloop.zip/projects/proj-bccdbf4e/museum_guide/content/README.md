# Exhibit content contract

The package uses only the Python standard library. `parse_catalog()` accepts either
the object form below or a bare list of exhibits; `load_catalog()` reads UTF-8 JSON.

```json
{
  "version": "1",
  "title": "A small collection",
  "sources": [{"source_id": "catalogue-2026", "provider": "Museum"}],
  "exhibits": [{
    "id": "object-001", "title": "Blue study",
    "description": "A short public description.",
    "creators": [{"id": "creator-1", "name": "A. Example", "role": "artist"}],
    "date": {"display": "c. 1900", "start_year": 1898, "end_year": 1903, "circa": true},
    "location": {"gallery": "2", "room": "West"},
    "media": [{"uri": "media/object-001.jpg", "alt_text": "Blue study"}],
    "accessibility": {"plain_language_summary": "A blue abstract study.", "tactile": false},
    "sources": [{"source_id": "catalogue-2026", "locator": "p. 4"}],
    "tags": ["abstract", "blue"]
  }]
}
```

Required fields are `exhibits[].id`, `exhibits[].title`, creator `id`/`name`,
media `uri`, and source `source_id`. Blank strings and missing optional fields
become `None`; lists become tuples in the model. Errors include JSON-like paths
and are aggregated in `IngestionError.errors`. Exhibit IDs must be unique, and
boolean accessibility fields are type-checked rather than truthiness-coerced.
