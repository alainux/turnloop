"""Validation and normalization for the sample-friendly JSON content format."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .model import AccessibilityMetadata, Catalog, Creator, DateValue, Exhibit, Location, Media, SourceRecord


class IngestionError(ValueError):
    """One or more input values violate the content contract."""

    def __init__(self, errors: list[str]):
        self.errors = tuple(errors)
        super().__init__("Invalid museum content:\n" + "\n".join(f"- {e}" for e in self.errors))


def load_catalog(path: str | Path) -> Catalog:
    """Read UTF-8 JSON from *path* and parse it as a catalog."""
    try:
        raw = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise IngestionError([f"$ : cannot read JSON: {exc}"]) from exc
    return parse_catalog(raw)


def parse_catalog(raw: Any) -> Catalog:
    errors: list[str] = []
    if isinstance(raw, list):
        raw = {"exhibits": raw}
    if not isinstance(raw, dict):
        raise IngestionError(["$ must be an object (or an exhibit list)"])
    exhibits_raw = raw.get("exhibits", [])
    if not isinstance(exhibits_raw, list):
        errors.append("$.exhibits must be a list")
        exhibits_raw = []
    exhibits = []
    exhibit_ids: set[str] = set()
    for index, item in enumerate(exhibits_raw):
        candidate_id = _text(item.get("id")) if isinstance(item, dict) else None
        duplicate = candidate_id is not None and candidate_id in exhibit_ids
        if candidate_id is not None and not duplicate:
            exhibit_ids.add(candidate_id)
        if duplicate:
            errors.append(f"$.exhibits[{index}].id duplicates exhibit id {candidate_id!r}")
        try:
            exhibit = _exhibit(item, f"$.exhibits[{index}]")
            if not duplicate:
                exhibits.append(exhibit)
        except IngestionError as exc:
            errors.extend(exc.errors)
    sources = _sources(raw.get("sources", []), "$.sources", errors)
    if errors:
        raise IngestionError(errors)
    return Catalog(tuple(exhibits), _text(raw.get("version")), _text(raw.get("title")), tuple(sources))


def _exhibit(value: Any, path: str) -> Exhibit:
    if not isinstance(value, dict):
        raise IngestionError([f"{path} must be an object"])
    errors: list[str] = []
    identifier = _required_text(value, "id", path, errors)
    title = _required_text(value, "title", path, errors)
    creators = _creators(value.get("creators", []), f"{path}.creators", errors)
    media = _media(value.get("media", []), f"{path}.media", errors)
    sources = _sources(value.get("sources", []), f"{path}.sources", errors)
    date = _date(value.get("date"), f"{path}.date", errors)
    location = _location(value.get("location"), f"{path}.location", errors)
    accessibility = _accessibility(value.get("accessibility", {}), f"{path}.accessibility", errors)
    tags = _texts(value.get("tags", []), f"{path}.tags", errors)
    if errors:
        raise IngestionError(errors)
    return Exhibit(identifier, title, _text(value.get("description")), tuple(creators), date, location,
                   tuple(media), accessibility, tuple(sources), tuple(tags))


def _date(value: Any, path: str, errors: list[str]) -> DateValue | None:
    if value is None or value == "": return None
    if isinstance(value, str): return DateValue(value.strip())
    if not isinstance(value, dict): errors.append(f"{path} must be text or an object"); return None
    display = _text(value.get("display"))
    if not display: errors.append(f"{path}.display is required"); return None
    years = []
    for key in ("start_year", "end_year"):
        item = value.get(key)
        if item is not None and (isinstance(item, bool) or not isinstance(item, int) or not 0 < item < 10000):
            errors.append(f"{path}.{key} must be a year integer")
        years.append(item if isinstance(item, int) and not isinstance(item, bool) else None)
    return DateValue(display, years[0], years[1], bool(value.get("circa", False)))


def _location(value: Any, path: str, errors: list[str]) -> Location | None:
    if value is None or value == "": return None
    if not isinstance(value, dict): errors.append(f"{path} must be an object"); return None
    return Location(*(_text(value.get(key)) for key in ("gallery", "room", "floor", "building")))


def _creators(value: Any, path: str, errors: list[str]) -> list[Creator]:
    if not isinstance(value, list): errors.append(f"{path} must be a list"); return []
    result = []
    for i, item in enumerate(value):
        p = f"{path}[{i}]"
        if not isinstance(item, dict): errors.append(f"{p} must be an object"); continue
        ident = _required_text(item, "id", p, errors); name = _required_text(item, "name", p, errors)
        if ident and name: result.append(Creator(ident, name, _text(item.get("role")), _text(item.get("nationality")), _date(item.get("dates"), f"{p}.dates", errors)))
    return result


def _media(value: Any, path: str, errors: list[str]) -> list[Media]:
    if not isinstance(value, list): errors.append(f"{path} must be a list"); return []
    result = []
    for i, item in enumerate(value):
        p = f"{path}[{i}]"
        if not isinstance(item, dict): errors.append(f"{p} must be an object"); continue
        uri = _required_text(item, "uri", p, errors)
        if uri: result.append(Media(uri, _text(item.get("kind")) or "image", _text(item.get("alt_text")), _text(item.get("caption")), _text(item.get("credit"))))
    return result


def _sources(value: Any, path: str, errors: list[str]) -> list[SourceRecord]:
    if not isinstance(value, list): errors.append(f"{path} must be a list"); return []
    result = []
    for i, item in enumerate(value):
        p = f"{path}[{i}]"
        if not isinstance(item, dict): errors.append(f"{p} must be an object"); continue
        ident = _required_text(item, "source_id", p, errors)
        if ident: result.append(SourceRecord(ident, *(_text(item.get(k)) for k in ("title", "uri", "provider", "retrieved", "license", "locator"))))
    return result


def _accessibility(value: Any, path: str, errors: list[str]) -> AccessibilityMetadata:
    if value is None: return AccessibilityMetadata()
    if not isinstance(value, dict): errors.append(f"{path} must be an object"); return AccessibilityMetadata()
    notes = _texts(value.get("notes", []), f"{path}.notes", errors)
    tactile = value.get("tactile", False)
    wheelchair = value.get("wheelchair_accessible")
    if not isinstance(tactile, bool):
        errors.append(f"{path}.tactile must be a boolean")
        tactile = False
    if wheelchair is not None and not isinstance(wheelchair, bool):
        errors.append(f"{path}.wheelchair_accessible must be a boolean or null")
        wheelchair = None
    return AccessibilityMetadata(_text(value.get("plain_language_summary")), _text(value.get("audio_description")), _text(value.get("transcript")), tactile, wheelchair, tuple(notes))


def _required_text(value: dict[str, Any], key: str, path: str, errors: list[str]) -> str | None:
    result = _text(value.get(key))
    if not result: errors.append(f"{path}.{key} is required and must be non-empty text")
    return result

def _text(value: Any) -> str | None:
    if not isinstance(value, str): return None
    value = value.strip()
    return value or None

def _texts(value: Any, path: str, errors: list[str]) -> list[str]:
    if value is None: return []
    if not isinstance(value, list): errors.append(f"{path} must be a list"); return []
    result = []
    for i, item in enumerate(value):
        text = _text(item)
        if text: result.append(text)
        else: errors.append(f"{path}[{i}] must be non-empty text")
    return result
