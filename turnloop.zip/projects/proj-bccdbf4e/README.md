# Offline museum guide

This standard-library-only package ingests a JSON catalog, derives deterministic
cross-exhibit themes and counts, and publishes accessible HTML, plain text, and
machine-readable analytics without network access.

From the project directory:

```sh
python3 -m museum_guide examples/exhibits.json --output build/museum-guide
python3 -m unittest discover -s tests -p 'test*.py'
# If pytest is installed, this is equivalent:
python3 -m pytest -q
```

The stable output names are `index.html`, `index.txt`, and `analytics.json`.
Invalid JSON or content contracts produce a non-zero CLI exit and a useful
validation message; existing output files are replaced atomically.
