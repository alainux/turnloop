#!/usr/bin/env python3
import datetime
import json
import os
import sys

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_FILE = os.path.join(SCRIPT_DIR, "notes.json")

USAGE = """usage: python3 notes.py <command> [args]

Commands:
  add "TEXT"   Add a timestamped note with an auto-incrementing id
  list         Print all notes as 'id: TEXT'
  delete ID    Delete the note with the given id
  --help       Show this help
"""


def load_notes():
    if not os.path.exists(DATA_FILE):
        return {"next_id": 1, "notes": {}}
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        if not isinstance(data, dict):
            raise ValueError("not a dict")
        notes = data.get("notes", {})
        if not isinstance(notes, dict):
            raise ValueError("bad notes")
        next_id = data.get("next_id", 1)
        if not isinstance(next_id, int):
            raise ValueError("bad next_id")
        return {"next_id": next_id, "notes": notes}
    except (ValueError, OSError, json.JSONDecodeError):
        return {"next_id": 1, "notes": {}}


def save_notes(state):
    with open(DATA_FILE, "w", encoding="utf-8") as fh:
        json.dump(state, fh, ensure_ascii=False, indent=2)
        fh.write("\n")


def cmd_add(args):
    if not args:
        print(USAGE, end="")
        return 2
    text = args[0]
    state = load_notes()
    note_id = state["next_id"]
    state["notes"][str(note_id)] = {
        "id": note_id,
        "text": text,
        "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    }
    state["next_id"] = note_id + 1
    save_notes(state)
    print(f"Added note {note_id}")
    return 0


def cmd_list():
    state = load_notes()
    notes = state["notes"]
    if not notes:
        print("No notes yet.")
        return 0
    for key in sorted(notes, key=int):
        note = notes[key]
        print(f"{note['id']}: {note['text']}")
    return 0


def cmd_delete(args):
    if not args:
        print(USAGE, end="")
        return 2
    try:
        note_id = int(args[0])
    except ValueError:
        print("Error: no such note")
        return 1
    state = load_notes()
    if str(note_id) not in state["notes"]:
        print("Error: no such note")
        return 1
    del state["notes"][str(note_id)]
    save_notes(state)
    print(f"Deleted note {note_id}")
    return 0


def main(argv):
    if len(argv) < 2 or argv[1] in ("--help", "-h", "help"):
        print(USAGE, end="")
        return 0
    command = argv[1]
    args = argv[2:]
    if command == "add":
        return cmd_add(args)
    if command == "list":
        return cmd_list()
    if command == "delete":
        return cmd_delete(args)
    print(USAGE, end="")
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv))