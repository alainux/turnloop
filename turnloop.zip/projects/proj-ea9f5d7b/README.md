# notes.py

A tiny offline notes utility.

## Requirements

- Python 3
- No external dependencies (stdlib only)

## Quick Start

```sh
python3 notes.py add "Buy milk"
python3 notes.py add "Call the dentist"
python3 notes.py list
python3 notes.py delete 1
python3 notes.py --help
```

## Command Reference

| Command | Description |
| --- | --- |
| `python3 notes.py add "TEXT"` | Adds a timestamped note with an auto-incrementing id. |
| `python3 notes.py list` | Prints all notes, one per line, as `id: TEXT`. |
| `python3 notes.py delete ID` | Removes the note with the given id and prints a confirmation. Errors on an unknown id with a non-zero exit. |
| `python3 notes.py --help` | Prints usage. Bare invocation prints usage too. |

## Data Storage

Notes persist in a local `notes.json` beside the script. Ids are never reused.

## Smoke Test

Expected output of a minimal add/list/delete sequence:

```sh
$ python3 notes.py add "hello"
Added note 1
$ python3 notes.py add "world"
Added note 2
$ python3 notes.py list
1: hello
2: world
$ python3 notes.py delete 1
Deleted note 1
$ python3 notes.py list
2: world
$ python3 notes.py delete 999
Error: no such note
$ echo $?
1
```