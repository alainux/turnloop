"""The discovery-to-exhibit integration boundary."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable, Mapping, Sequence

from studio.discovery import SearchIndex, build_index, search

from .renderer import RenderResult, render_exhibit


@dataclass(frozen=True)
class PublicationResult:
    """The reproducible outputs of one offline discovery/presentation run."""

    discovery: Mapping[str, Any]
    presentation: RenderResult
    index: SearchIndex


def publish_exhibits(
    records: Iterable[Mapping[str, Any]],
    *,
    query: str = "",
    filters: Mapping[str, Any] | None = None,
    facets: Sequence[str] = (),
    limit: int | None = None,
    view: Mapping[str, Any] | None = None,
) -> PublicationResult:
    """Search normalized records and render the matching index offline."""
    snapshot = tuple(records)
    index = build_index(snapshot)
    result = search(index, query, filters=filters, facets=facets, limit=limit)
    # The branches intentionally use different view-model shapes: discovery
    # returns record mappings, while presentation accepts an ID projection.
    render_selection = {"results": [item["id"] for item in result["results"]]}
    rendered = render_exhibit(snapshot, discovery=render_selection, view=view)
    return PublicationResult(result, rendered, index)
