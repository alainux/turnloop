# Presentation

This package renders normalized archive records as offline exhibit pages. The
branch-integrator interface is `studio.presentation.render_exhibit(records,
discovery=None, view=None)`, returning an immutable `RenderResult` with
`pages` (relative path to stable HTML) and `metadata` (`contract`, counts,
sorted paths, and a SHA-256 render digest).

Inputs are validated normalized records with required string `id` and `title`;
optional `description`, `date`, `collection`, string `subjects`, an `image`
(`src`, `alt`, optional `caption`), and labeled `links` are supported.
Discovery may provide a `results` list of record IDs; view may provide a
non-empty `title` and `intro`. Records missing required data, duplicate IDs,
wrong types, unsafe URL schemes, or malformed discovery results raise
`ValueError`. Text and attributes are HTML-escaped. Unknown discovery IDs are
ignored. Invalid data never produces partial output.

The renderer is read-only: it copies input mappings, performs no I/O, and
never writes to source records or search data. It emits a semantic document
landmark structure (`header`, labeled `nav`, `main`, `footer`), one page
heading, ordered exhibit links, keyboard-native anchors, image alt text,
captions, and descriptive link labels. Records and paths are sorted by title
then ID, making identical inputs and view parameters byte-stable. These
ordering, escaping, accessibility, reproducibility, and source-immutability
properties are invariants for integrators and release packaging.

Run focused tests with `pytest studio/presentation/tests`.

## Discovery integration

`studio.presentation.publish_exhibits(records, query=..., filters=..., facets=..., limit=..., view=...)`
is the branch-level offline entrypoint. `records` is one iterable snapshot of
content-model `NormalizedRecord` objects or their `to_dict()` mappings. The
function builds a deterministic `studio.discovery.SearchIndex`, searches it,
and passes that result to `render_exhibit`; it returns a `PublicationResult`
containing `index`, `discovery`, and `presentation` outputs. Search's
`DiscoveryError` and rendering's `ValueError` remain distinct so callers can
report query/index errors separately from exhibit validation errors.

The discovery result controls index cards, including its complete facet counts
before `limit`; the renderer owns HTML, escaping, accessibility, and exhibit
page paths. Both consumers copy the shared snapshot and neither mutates model
records or caller mappings. The shared compatibility contract is
`normalized-archive/v1`: stable `id`, `title`, `record_type`, optional
description/date/attributes/provenance, with presentation-specific fields
read from top-level keys or `attributes`.
