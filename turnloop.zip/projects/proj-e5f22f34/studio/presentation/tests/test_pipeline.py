import copy

from studio.content.model import normalize_record
from studio.presentation import publish_exhibits


def test_model_records_flow_through_discovery_into_presentation():
    records = [
        normalize_record(
            {"id": "one", "title": "River memory", "record_type": "oral_history",
             "description": "Water access", "date": "1952", "themes": ["water"],
             "place": "North Dock"},
            source_system="fixture", source_key="one",
        ),
        normalize_record(
            {"id": "two", "title": "Garden exchange", "record_type": "poster",
             "themes": ["community"], "place": "East Garden"},
            source_system="fixture", source_key="two",
        ),
    ]
    result = publish_exhibits(records, query="water", facets=("themes",), view={"title": "Archive", "intro": "Explore"})
    assert [item["id"] for item in result.discovery["results"]] == [records[0].id]
    assert result.discovery["facets"] == {"themes": {"water": 1}}
    assert f"exhibits/{records[0].id}.html" in result.presentation.pages


def test_pipeline_does_not_mutate_mapping_snapshot():
    records = [{"id": "r-1", "title": "A", "record_type": "note", "attributes": {"themes": ["x"]}}]
    original = copy.deepcopy(records)
    publish_exhibits(records, facets=("themes",))
    assert records == original
