import copy
import json
from pathlib import Path

import pytest

from studio.presentation import render_exhibit


FIXTURE = json.loads((Path(__file__).parents[1] / "fixtures/records.json").read_text())


def test_pages_are_semantic_accessible_and_escaped():
    records = copy.deepcopy(FIXTURE)
    records[1]["title"] = "River <Song>"
    result = render_exhibit(records, view={"title": "Local archive", "intro": "Read the exhibits."})
    index = result.pages["index.html"]
    exhibit = result.pages["exhibits/river-song.html"]
    assert "<main id=\"main-content\">" in index and "<nav aria-label=\"Primary\">" in index
    assert "<h1>Local archive</h1>" in index and "<h2>Exhibits</h2>" in index
    assert "River &lt;Song&gt;" in exhibit
    assert '<a href="index.html">Return to exhibit index</a>' in exhibit


def test_image_caption_alt_and_descriptive_links():
    result = render_exhibit(FIXTURE)
    page = result.pages["exhibits/market-day.html"]
    assert 'alt="People gathered beside market stalls"' in page
    assert "<figcaption>Market day in the town square.</figcaption>" in page
    assert '>Collection note</a>' in page


def test_is_deterministic_and_does_not_mutate_inputs():
    records = copy.deepcopy(FIXTURE)
    original = copy.deepcopy(records)
    first = render_exhibit(records)
    second = render_exhibit(records)
    assert records == original
    assert dict(first.pages) == dict(second.pages)
    assert first.metadata["sha256"] == second.metadata["sha256"]


def test_discovery_results_are_read_only_and_unknown_ids_ignored():
    result = render_exhibit(FIXTURE, discovery={"results": ["river-song", "missing"]})
    assert "market-day" not in result.pages["index.html"]
    assert "river-song.html" in result.pages["index.html"]


@pytest.mark.parametrize("bad", [[{"id": "x"}], [{"id": "x", "title": "X", "image": {"src": "javascript:bad", "alt": "x"}}]])
def test_invalid_required_data_fails_clearly(bad):
    with pytest.raises(ValueError):
        render_exhibit(bad)
