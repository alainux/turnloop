"""Render normalized archive records into stable, read-only exhibit pages."""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import html
import json
import re
from types import MappingProxyType
from typing import Any, Iterable, Mapping
from urllib.parse import urlparse


@dataclass(frozen=True)
class RenderResult:
    """Rendered pages and metadata describing the deterministic render."""

    pages: Mapping[str, str]
    metadata: Mapping[str, Any]


def _text(value: Any, field: str, *, required: bool = False) -> str:
    if not isinstance(value, str) or (required and not value.strip()):
        expectation = "a non-empty string" if required else "a string"
        raise ValueError(f"record {field!r} must be {expectation}")
    return value


def _safe_href(value: Any, field: str) -> str:
    href = _text(value, field, required=True)
    parsed = urlparse(href)
    if parsed.scheme and parsed.scheme not in {"http", "https", "mailto"}:
        raise ValueError(f"record {field!r} uses an unsupported URL scheme")
    if href.startswith("//"):
        raise ValueError(f"record {field!r} must not be a protocol-relative URL")
    return href


def _records(records: Iterable[Mapping[str, Any]]) -> list[dict[str, Any]]:
    if isinstance(records, (str, bytes, Mapping)):
        raise ValueError("records must be an iterable of mappings")
    result = []
    seen: set[str] = set()
    for index, original in enumerate(records):
        if hasattr(original, "to_dict") and callable(original.to_dict):
            original = original.to_dict()
        if not isinstance(original, Mapping):
            raise ValueError(f"record {index} must be a mapping or NormalizedRecord")
        record = dict(original)  # Never retain or mutate the source mapping.
        record_id = _text(record.get("id"), f"{index}.id", required=True)
        if record_id in {".", ".."} or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]*", record_id):
            raise ValueError(f"record {record_id!r}.id must be a path-safe identifier")
        title = _text(record.get("title"), f"{record_id}.title", required=True)
        if record_id in seen:
            raise ValueError(f"duplicate record id: {record_id}")
        seen.add(record_id)
        attributes = record.get("attributes", {})
        if attributes is not None and not isinstance(attributes, Mapping):
            raise ValueError(f"record {record_id!r}.attributes must be a mapping")
        # The content foundation keeps source-specific presentation values in
        # attributes. Project only known optional fields into this private copy.
        for field in ("description", "date", "collection", "subjects", "image", "links"):
            if field not in record and isinstance(attributes, Mapping) and field in attributes:
                record[field] = attributes[field]
        for field in ("description", "date", "collection"):
            if field in record and record[field] is not None:
                _text(record[field], f"{record_id}.{field}")
        subjects = record.get("subjects", ())
        if not isinstance(subjects, (list, tuple)) or not all(isinstance(x, str) for x in subjects):
            raise ValueError(f"record {record_id!r}.subjects must be a list of strings")
        image = record.get("image")
        if image is not None:
            if not isinstance(image, Mapping):
                raise ValueError(f"record {record_id!r}.image must be a mapping")
            _safe_href(image.get("src"), f"{record_id}.image.src")
            _text(image.get("alt"), f"{record_id}.image.alt", required=True)
            if image.get("caption") is not None:
                _text(image["caption"], f"{record_id}.image.caption")
        links = record.get("links", ())
        if not isinstance(links, (list, tuple)):
            raise ValueError(f"record {record_id!r}.links must be a list")
        for link_index, link in enumerate(links):
            if not isinstance(link, Mapping):
                raise ValueError(f"record {record_id!r}.links[{link_index}] must be a mapping")
            _text(link.get("label"), f"{record_id}.links[{link_index}].label", required=True)
            _safe_href(link.get("href"), f"{record_id}.links[{link_index}].href")
        record["subjects"] = tuple(subjects)
        record["links"] = tuple(dict(link) for link in links)
        result.append(record)
    return sorted(result, key=lambda item: (item["title"].casefold(), item["id"]))


def _e(value: Any) -> str:
    return html.escape(str(value), quote=True)


def _page(title: str, body: str, *, description: str) -> str:
    return "<!doctype html>\n<html lang=\"en\">\n<head>\n<meta charset=\"utf-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n<title>" + _e(title) + "</title>\n<meta name=\"description\" content=\"" + _e(description) + "\">\n</head>\n<body>\n" + body + "\n</body>\n</html>\n"


def render_exhibit(
    records: Iterable[Mapping[str, Any]],
    *,
    discovery: Mapping[str, Any] | None = None,
    view: Mapping[str, Any] | None = None,
) -> RenderResult:
    """Return an index and one page per record without changing any input.

    ``records`` are validated normalized records. ``discovery`` may contain a
    ``results`` iterable of record ids. ``view`` supports ``title`` and
    ``intro`` strings. All output ordering is explicit and deterministic.
    """
    items = _records(records)
    discovery = {} if discovery is None else dict(discovery)
    view = {} if view is None else dict(view)
    title = _text(view.get("title", "Community archive"), "view.title", required=True)
    intro = _text(view.get("intro", "Explore the collection."), "view.intro", required=True)
    by_id = {item["id"]: item for item in items}
    result_ids = discovery.get("results")
    if result_ids is None:
        shown = items
    else:
        if not isinstance(result_ids, (list, tuple)) or not all(isinstance(x, str) for x in result_ids):
            raise ValueError("discovery.results must be a list of record ids")
        shown = sorted((by_id[x] for x in set(result_ids) if x in by_id), key=lambda item: (item["title"].casefold(), item["id"]))

    cards = "\n".join(f'<li><article><h2><a href="exhibits/{_e(item["id"])}.html">{_e(item["title"])}</a></h2>'
        f'<p>{_e(item.get("description", "No description available."))}</p></article></li>' for item in shown)
    nav = '<nav aria-label="Primary"><a href="index.html">Exhibit index</a></nav>'
    pages: dict[str, str] = {"index.html": _page(title, f'<header><h1>{_e(title)}</h1><p>{_e(intro)}</p></header>{nav}<main id="main-content"><h2>Exhibits</h2><ol>{cards}</ol></main>', description=intro)}
    for position, item in enumerate(items, 1):
        parts = [f'<header><p>Exhibit {position} of {len(items)}</p><h1>{_e(item["title"])}</h1></header>', nav, '<main id="main-content">']
        if item.get("image"):
            image = item["image"]
            parts.append(f'<figure><img src="{_e(image["src"])}" alt="{_e(image["alt"])}">')
            if image.get("caption"):
                parts.append(f'<figcaption>{_e(image["caption"])}</figcaption>')
            parts.append('</figure>')
        if item.get("description"):
            parts.append(f'<p>{_e(item["description"])}</p>')
        details = [("Date", item.get("date")), ("Collection", item.get("collection")), ("Subjects", ", ".join(item["subjects"]) or None)]
        details = [(label, value) for label, value in details if value]
        if details:
            parts.append('<dl>' + ''.join(f'<dt>{_e(label)}</dt><dd>{_e(value)}</dd>' for label, value in details) + '</dl>')
        if item["links"]:
            parts.append('<h2>Related links</h2><ul>' + ''.join(f'<li><a href="{_e(_safe_href(link["href"], "link.href"))}">{_e(link["label"])}</a></li>' for link in item["links"]) + '</ul>')
        parts += ['</main>', '<footer><p><a href="index.html">Return to exhibit index</a></p></footer>']
        pages[f'exhibits/{item["id"]}.html'] = _page(item["title"], ''.join(parts), description=item.get("description", item["title"]))
    digest = hashlib.sha256(''.join(f'{path}\0{pages[path]}' for path in sorted(pages)).encode()).hexdigest()
    metadata = MappingProxyType({"contract": "normalized-archive/v1", "page_count": len(pages), "record_count": len(items), "sha256": digest, "paths": tuple(sorted(pages))})
    return RenderResult(MappingProxyType(pages), metadata)
