import copy
import json
import unittest

from studio.discovery import DiscoveryError, build_index, search, serialize_result


class DiscoveryTests(unittest.TestCase):
    def setUp(self):
        with open("studio/discovery/fixtures/records.json", encoding="utf-8") as handle:
            self.records = json.load(handle)

    def test_ranking_and_tie_breaking_are_stable(self):
        result = search(build_index(reversed(self.records)), "water")
        self.assertEqual([r["id"] for r in result["results"]], ["r-003", "r-001"])
        self.assertEqual(result, search(build_index(self.records), "water"))

    def test_filters_and_facets_only_use_matching_valid_records(self):
        result = search(build_index(self.records), filters={"place": "North Dock"}, facets=("themes", "year"))
        self.assertEqual([r["id"] for r in result["results"]], ["r-001", "r-003"])
        self.assertEqual(result["facets"]["themes"], {"labor": 1, "water": 2, "community": 1})
        self.assertEqual(result["facets"]["year"], {"1952": 1, "1984": 1})

    def test_source_and_returned_records_are_not_mutated(self):
        original = copy.deepcopy(self.records)
        index = build_index(self.records)
        result = search(index, "garden")
        result["results"][0]["title"] = "changed"
        self.assertEqual(self.records, original)
        self.assertEqual(index.records[1]["title"], "Garden exchange poster")

    def test_validation_and_stable_serialization(self):
        with self.assertRaises(DiscoveryError):
            build_index([{"title": "missing id"}])
        with self.assertRaises(DiscoveryError):
            build_index(self.records + [dict(self.records[0])])
        result = search(build_index(self.records), "COMMUNITY", limit=1)
        self.assertEqual(serialize_result(result), serialize_result(result))
        self.assertEqual(len(result["results"]), 1)


if __name__ == "__main__":
    unittest.main()
