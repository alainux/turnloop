"""Deterministic, offline discovery for normalized archive records."""

from .search import (
    DiscoveryError,
    SearchIndex,
    build_index,
    search,
    serialize_result,
)

__all__ = ["DiscoveryError", "SearchIndex", "build_index", "search", "serialize_result"]
