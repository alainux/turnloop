# Offline discovery contract

`studio.discovery` consumes normalized archive records produced by
`studio.content.model` (or an equivalent normalized mapping). It does not
normalize, rename, or rewrite that source schema. A record must have a stable
`id`, `record_id`, or `identifier`; the model's `title`, `record_type`,
`description`, `date`, `attributes`, and `provenance` are indexed as-is.
Attribute values such as `themes` and `place` are available for search and
facets.

## API

```python
from studio.discovery import build_index, search, serialize_result

index = build_index(normalized_records)
result = search(index, "river workers", filters={"place": "North Dock"},
                facets=("themes", "year"), limit=20)
wire_value = serialize_result(result)
```

Inputs are normalized record mappings and query parameters: `query` text,
exact/list/range `filters`, supported facet fields, and an optional
non-negative `limit`. Supported facets are `themes`, `subjects`, `tags`,
`type`, `format`, `place`, `collection`, `record_type`, and `year`.
`year` is read from a four-digit year in `year` or `date`.

Outputs contain `results`, `facets`, and `metadata`. Results are deep copies of
valid source records. Text matching uses Unicode NFKC/case-folded tokens;
title matches weigh most, followed by thematic fields and descriptive text.
Results are sorted by descending score, then stable record ID. Facet keys and
metadata fields serialize in sorted order. Metadata includes index version,
record count, indexed fields, and a SHA-256 digest of the canonical record
snapshot.

Invalid mappings, missing IDs, duplicate IDs, unsupported facets, non-string
queries, and invalid limits raise `DiscoveryError`. Empty queries return all
records subject to filters. Facets count the complete filtered/matched result
set before `limit`, so they never describe records outside the current query.
Records are copied when indexed and returned, so neither indexing nor a query
mutates source data. No network or process-global state is used; equal inputs
produce equal results and serialized output regardless of input order.

`build_index` also accepts immutable content-model `NormalizedRecord` objects
directly, using their `to_dict()` wire representation. This is the only model
adaptation owned by discovery; presentation owns rendering and does not
re-normalize records. The combined offline entrypoint is
`studio.presentation.publish_exhibits`.
