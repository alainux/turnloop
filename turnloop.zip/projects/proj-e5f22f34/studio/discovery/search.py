"""Small, dependency-free search/index API for normalized archive records.

The module deliberately treats records as opaque mappings.  It consumes the
content foundation's normalized records without importing or redefining that
schema.
"""

from __future__ import annotations

from collections import Counter
from copy import deepcopy
from dataclasses import dataclass
from datetime import date
import hashlib
import json
import re
import unicodedata
from typing import Any, Iterable, Mapping, Sequence


class DiscoveryError(ValueError):
    """Raised for invalid records, queries, filters, or facet requests."""


_TOKEN = re.compile(r"[\w]+", re.UNICODE)
_TEXT_FIELDS = ("title", "name", "description", "summary", "transcript", "text", "subjects", "themes", "tags", "record_type", "attributes")
_FACET_FIELDS = ("themes", "subjects", "tags", "type", "format", "place", "collection", "record_type", "year")


def _norm(value: Any) -> str:
    return unicodedata.normalize("NFKC", str(value)).casefold().strip()


def _tokens(value: Any) -> tuple[str, ...]:
    return tuple(_norm(token) for token in _TOKEN.findall(str(value)))


def _values(record: Mapping[str, Any], field: str) -> tuple[str, ...]:
    value = record.get(field)
    if value is None and isinstance(record.get("attributes"), Mapping):
        value = record["attributes"].get(field)
    if value is None:
        return ()
    if isinstance(value, Mapping):
        return tuple(_norm(item) for item in value.values() if item is not None and not isinstance(item, (Mapping, list, tuple, set)))
    if isinstance(value, (list, tuple, set)):
        return tuple(_norm(item) for item in value if item is not None and str(item).strip())
    return (_norm(value),)


def _canonical(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(k): _canonical(value[k]) for k in sorted(value, key=lambda k: str(k))}
    if isinstance(value, (list, tuple)):
        return [_canonical(item) for item in value]
    if isinstance(value, set):
        return sorted((_canonical(item) for item in value), key=lambda item: json.dumps(item, ensure_ascii=False, sort_keys=True))
    return value


def _record_id(record: Mapping[str, Any]) -> str:
    for key in ("id", "record_id", "identifier"):
        if key in record and str(record[key]).strip():
            return str(record[key])
    raise DiscoveryError("normalized record is missing a non-empty id")


def _record_mapping(record: Any, position: int) -> Mapping[str, Any]:
    """Accept the model's immutable record as well as its wire mapping."""
    if hasattr(record, "to_dict") and callable(record.to_dict):
        record = record.to_dict()
    if not isinstance(record, Mapping):
        raise DiscoveryError(f"record {position} must be a mapping or NormalizedRecord")
    return record


def _year(record: Mapping[str, Any]) -> str | None:
    value = record.get("year", record.get("date"))
    match = re.search(r"\b(\d{4})\b", str(value)) if value is not None else None
    return match.group(1) if match else None


@dataclass(frozen=True)
class SearchIndex:
    """Immutable snapshot of copied records and deterministic index metadata."""

    records: tuple[Mapping[str, Any], ...]
    metadata: Mapping[str, Any]
    _tokens_by_id: Mapping[str, Mapping[str, tuple[str, ...]]]

    def __post_init__(self) -> None:
        object.__setattr__(self, "records", tuple(deepcopy(record) for record in self.records))
        object.__setattr__(self, "metadata", deepcopy(dict(self.metadata)))


def build_index(records: Iterable[Mapping[str, Any]]) -> SearchIndex:
    """Build an offline index from normalized archive records.

    Input order does not affect the resulting snapshot.  Records are copied;
    later searches therefore cannot mutate the caller's source data.
    """
    copied: list[Mapping[str, Any]] = []
    seen: set[str] = set()
    for position, record in enumerate(records):
        item = deepcopy(dict(_record_mapping(record, position)))
        rid = _record_id(item)
        if rid in seen:
            raise DiscoveryError(f"duplicate normalized record id: {rid}")
        seen.add(rid)
        copied.append(item)
    copied.sort(key=lambda item: _record_id(item))
    token_map = {
        _record_id(record): {field: _tokens(" ".join(map(str, _values(record, field)))) for field in _TEXT_FIELDS}
        for record in copied
    }
    payload = json.dumps(_canonical(copied), ensure_ascii=False, separators=(",", ":"), sort_keys=True).encode("utf-8")
    metadata = {
        "version": 1,
        "record_count": len(copied),
        "fields": sorted({str(key) for record in copied for key in record}),
        "record_digest": hashlib.sha256(payload).hexdigest(),
    }
    return SearchIndex(tuple(copied), metadata, token_map)


def _matches(record: Mapping[str, Any], filters: Mapping[str, Any]) -> bool:
    for field, expected in filters.items():
        if field == "year":
            actual = _year(record)
        else:
            actual_values = _values(record, field)
            actual = actual_values if len(actual_values) != 1 else actual_values[0]
        if isinstance(expected, Mapping):
            if "min" in expected and (actual is None or str(actual) < _norm(expected["min"])):
                return False
            if "max" in expected and (actual is None or str(actual) > _norm(expected["max"])):
                return False
        elif isinstance(expected, (list, tuple, set)):
            wanted = {_norm(item) for item in expected}
            actual_set = set(actual if isinstance(actual, tuple) else (() if actual is None else (actual,)))
            if not actual_set.intersection(wanted):
                return False
        elif _norm(expected) not in (set(actual) if isinstance(actual, tuple) else {_norm(actual)}):
            return False
    return True


def search(index: SearchIndex, query: str = "", *, filters: Mapping[str, Any] | None = None,
           facets: Sequence[str] = (), limit: int | None = None) -> Mapping[str, Any]:
    """Search an index and return stable records, facet counts, and metadata."""
    if not isinstance(index, SearchIndex):
        raise DiscoveryError("index must be created with build_index")
    if not isinstance(query, str):
        raise DiscoveryError("query must be a string")
    filters = {} if filters is None else dict(filters)
    if not isinstance(filters, Mapping):
        raise DiscoveryError("filters must be a mapping")
    facets = tuple(facets)
    unknown = sorted(set(facets) - set(_FACET_FIELDS))
    if unknown:
        raise DiscoveryError(f"unsupported facet field(s): {', '.join(unknown)}")
    if limit is not None and (not isinstance(limit, int) or isinstance(limit, bool) or limit < 0):
        raise DiscoveryError("limit must be a non-negative integer or None")

    terms = _tokens(query)
    candidates: list[tuple[float, str, Mapping[str, Any]]] = []
    for record in index.records:
        if not _matches(record, filters):
            continue
        rid = _record_id(record)
        fields = index._tokens_by_id[rid]
        counts = {field: Counter(fields[field]) for field in _TEXT_FIELDS}
        score = 0.0
        for term in terms:
            score += 4 * counts["title"][term] + 3 * (counts["subjects"][term] + counts["themes"][term] + counts["tags"][term])
            score += 2 * (counts["description"][term] + counts["summary"][term] + counts["transcript"][term] + counts["text"][term])
        if terms and all(term in fields["title"] for term in terms):
            score += 2
        if not terms or score > 0:
            candidates.append((score, rid, record))
    candidates.sort(key=lambda item: (-item[0], item[1]))
    all_matching = [record for _, _, record in candidates]
    returned = all_matching if limit is None else all_matching[:limit]
    facet_counts: dict[str, dict[str, int]] = {}
    for field in facets:
        counts: Counter[str] = Counter()
        for record in all_matching:
            values = (_year(record),) if field == "year" else _values(record, field)
            counts.update(value for value in values if value is not None)
        facet_counts[field] = {key: counts[key] for key in sorted(counts)}
    return {"results": deepcopy(returned), "facets": facet_counts, "metadata": deepcopy(dict(index.metadata))}


def serialize_result(result: Mapping[str, Any]) -> str:
    """Serialize a search result with stable JSON ordering and UTF-8 text."""
    if not isinstance(result, Mapping) or not {"results", "facets", "metadata"} <= set(result):
        raise DiscoveryError("result must contain results, facets, and metadata")
    return json.dumps(_canonical(result), ensure_ascii=False, sort_keys=True, separators=(",", ":"))
