# Content foundation integration

The integration boundary composes the two prerequisite namespaces without
reimplementing either one:

```sh
python -m studio.content.integration studio/content/ingestion/fixtures/ingestion.json
```

The Python API is `integrate(config_path)`; `integrate_to_json` returns the
same records as canonical, sorted-key JSON. It reads only the local fixtures
accepted by `content.ingestion`, then passes each source record to
`content.model.normalize_record`.

Each output record has the model contract (`schema_version`, `id`, `title`,
`record_type`, `description`, `date`, `attributes`, `provenance`, and
`lossy_fields`) plus `source_record` and `ingestion_provenance` for audit and
reprocessing. Since the fixtures have no type field, the adapter assigns
`record_type: "community-item"`. The ingestion `record_id` (for example,
`community-alpha:alpha-001`) is passed as the model's explicit source key;
the resulting `id` is therefore a stable `arc_` hash independent of display
text or input ordering. Media and source metadata remain in `attributes`.

The operation is all-or-nothing: malformed local input, unsupported URI paths,
duplicate ingestion IDs, missing required model fields, or invalid provenance
raise `IntegrationError` and produce no partial list or JSON. Output order is
by canonical `id`, and repeated runs over unchanged fixtures produce identical
JSON. No network or environment data is consulted.
