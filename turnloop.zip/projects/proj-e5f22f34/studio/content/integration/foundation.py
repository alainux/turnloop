"""Compose ingestion envelopes into validated, normalized archive records.

This module is deliberately an adapter: source parsing remains in
``content.ingestion`` and canonical validation/ID generation remains in
``content.model``.  The adapter only reconciles their field contracts.
"""

from __future__ import annotations

import json
from collections.abc import Mapping
from pathlib import Path
from typing import Any

from ..ingestion import IngestionError, ingest
from ..model import NormalizationError, normalize_record


class IntegrationError(ValueError):
    """Raised when an ingestion envelope cannot cross the model boundary."""


def normalize_ingested_record(envelope: Mapping[str, Any]) -> dict[str, Any]:
    """Return one JSON-ready canonical record while retaining its source envelope.

    ``record_id`` is the ingestion namespace's stable identity.  It becomes
    the model's explicit source key, so changes to display text cannot change
    the canonical ``arc_`` identifier.  Collection fixtures do not provide a
    type, therefore this boundary assigns the documented ``community-item``
    type rather than guessing from media.
    """
    if not isinstance(envelope, Mapping):
        raise IntegrationError("ingested record must be a mapping")
    record_id = envelope.get("record_id")
    source_record = envelope.get("source_record")
    provenance = envelope.get("provenance")
    if not isinstance(record_id, str) or not record_id.strip():
        raise IntegrationError("ingested record.record_id must be a non-empty string")
    if not isinstance(source_record, Mapping):
        raise IntegrationError(f"{record_id}: source_record must be a mapping")
    if not isinstance(provenance, Mapping):
        raise IntegrationError(f"{record_id}: provenance must be a mapping")

    source = dict(source_record)
    source.setdefault("record_type", "community-item")
    source_system = provenance.get("source_identifier")
    if not isinstance(source_system, str) or not source_system.strip():
        raise IntegrationError(f"{record_id}: provenance.source_identifier must be a non-empty string")
    try:
        normalized = normalize_record(
            source,
            source_system=source_system,
            source_key=record_id,
            metadata={"ingestion": dict(provenance)},
        )
    except (NormalizationError, ValueError) as exc:
        raise IntegrationError(f"{record_id}: {exc}") from exc

    result = normalized.to_dict()
    # Keep the untouched source payload available to audit and reprocessing
    # tools.  Downstream discovery/presentation can ignore these extra keys.
    result["source_record"] = source
    result["ingestion_provenance"] = dict(provenance)
    return result


def integrate(config_path: str | Path) -> list[dict[str, Any]]:
    """Ingest and normalize all configured local fixtures atomically."""
    try:
        envelopes = ingest(config_path)
    except IngestionError as exc:
        raise IntegrationError(str(exc)) from exc
    records = [normalize_ingested_record(envelope) for envelope in envelopes]
    return sorted(records, key=lambda record: record["id"])


def integrate_to_json(config_path: str | Path) -> str:
    """Return deterministic UTF-8 JSON for a content-foundation artifact."""
    return json.dumps(integrate(config_path), ensure_ascii=False, indent=2, sort_keys=True) + "\n"
