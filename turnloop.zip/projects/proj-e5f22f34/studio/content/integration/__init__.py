"""Integration boundary between local ingestion and the canonical model."""

from .foundation import IntegrationError, integrate, integrate_to_json, normalize_ingested_record

__all__ = ["IntegrationError", "integrate", "integrate_to_json", "normalize_ingested_record"]
