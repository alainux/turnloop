"""Command-line entry point for the content foundation."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .foundation import IntegrationError, integrate_to_json


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Build normalized archive records from local fixtures")
    parser.add_argument("config", type=Path, help="path to an ingestion config JSON file")
    parser.add_argument("-o", "--output", type=Path, help="write JSON to this local file (default: stdout)")
    args = parser.parse_args(argv)
    try:
        output = integrate_to_json(args.config)
        if args.output:
            args.output.write_text(output, encoding="utf-8")
        else:
            sys.stdout.write(output)
    except (IntegrationError, OSError) as exc:
        print(f"content integration error: {exc}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
