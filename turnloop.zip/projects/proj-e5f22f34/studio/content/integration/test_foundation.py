import json
import tempfile
import unittest
from pathlib import Path

from .foundation import IntegrationError, integrate, integrate_to_json, normalize_ingested_record


HERE = Path(__file__).parents[1] / "ingestion" / "fixtures"


class FoundationIntegrationTests(unittest.TestCase):
    def test_fixtures_cross_both_contracts_and_preserve_audit_data(self):
        records = integrate(HERE / "ingestion.json")
        self.assertEqual(len(records), 3)
        self.assertEqual([record["record_type"] for record in records], ["community-item"] * 3)
        self.assertTrue(all(record["id"].startswith("arc_") for record in records))
        first = next(record for record in records if record["ingestion_provenance"]["source_record_id"] == "alpha-001")
        self.assertEqual(first["provenance"]["source_key"], "community-alpha:alpha-001")
        self.assertEqual(first["attributes"]["media"], ["audio/mpeg"])
        self.assertEqual(first["source_record"]["id"], "alpha-001")
        self.assertEqual(first["provenance"]["metadata"]["ingestion"]["source_record_index"], 1)

    def test_output_is_deterministic_and_consumable_by_json(self):
        first = integrate_to_json(HERE / "ingestion.json")
        self.assertEqual(first, integrate_to_json(HERE / "ingestion.json"))
        self.assertEqual(len(json.loads(first)), 3)
        self.assertTrue(first.endswith("\n"))

    def test_explicit_ingestion_identity_keeps_id_stable_when_title_changes(self):
        record = integrate(HERE / "ingestion.json")[0]
        envelope = {
            "record_id": record["provenance"]["source_key"],
            "source_record": {**record["source_record"], "title": "Edited display title"},
            "provenance": record["ingestion_provenance"],
        }
        self.assertEqual(normalize_ingested_record(envelope)["id"], record["id"])

    def test_invalid_ingestion_input_fails_at_boundary_without_partial_output(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config = root / "config.json"
            config.write_text('{"sources":[{"source_id":"local","fixture":"missing.json"}]}', encoding="utf-8")
            with self.assertRaisesRegex(IntegrationError, "does not exist"):
                integrate(config)


if __name__ == "__main__":
    unittest.main()
