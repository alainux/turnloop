"""The archive's canonical record contract.

The functions in this module accept ordinary mappings so ingestion adapters do
not need to depend on a particular source format.  Normalization is pure:
the input is never mutated and the same values produce the same output.
"""

from __future__ import annotations

from dataclasses import dataclass, field
import hashlib
import json
import re
import unicodedata
from collections.abc import Mapping
from typing import Any

CURRENT_SCHEMA_VERSION = 1
_MISSING = object()
_SPACE = re.compile(r"\s+")
_DEFAULT_ALIASES = {
    "name": "title",
    "label": "title",
    "type": "record_type",
    "kind": "record_type",
    "description": "description",
    "summary": "description",
    "date": "date",
    "identifier": "source_id",
    "id": "source_id",
}


@dataclass(frozen=True)
class ValidationIssue:
    """An actionable schema problem, suitable for a CLI or form display."""

    field: str
    message: str
    code: str


@dataclass(frozen=True)
class Provenance:
    """Traceability for one normalized record and each mapped field."""

    source_system: str
    source_key: str
    field_map: Mapping[str, tuple[str, ...]] = field(default_factory=dict)
    metadata: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class NormalizedRecord:
    """Versioned record consumed by publishing and discovery layers."""

    id: str
    title: str
    record_type: str
    description: str | None
    date: str | None
    attributes: Mapping[str, Any]
    provenance: Provenance
    schema_version: int = CURRENT_SCHEMA_VERSION
    lossy_fields: tuple[str, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-ready representation with stable key names."""
        return {
            "schema_version": self.schema_version,
            "id": self.id,
            "title": self.title,
            "record_type": self.record_type,
            "description": self.description,
            "date": self.date,
            "attributes": dict(self.attributes),
            "provenance": {
                "source_system": self.provenance.source_system,
                "source_key": self.provenance.source_key,
                "field_map": {
                    key: list(value) for key, value in self.provenance.field_map.items()
                },
                "metadata": dict(self.provenance.metadata),
            },
            "lossy_fields": list(self.lossy_fields),
        }


class NormalizationError(ValueError):
    """Raised when a source record cannot satisfy required fields."""

    def __init__(self, issues: list[ValidationIssue]):
        self.issues = tuple(issues)
        detail = "; ".join(f"{i.field}: {i.message}" for i in issues)
        super().__init__(f"record validation failed: {detail}")


def _text(value: Any) -> str:
    """Unicode-normalize and collapse whitespace without changing meaning."""
    return _SPACE.sub(" ", unicodedata.normalize("NFC", str(value))).strip()


def _jsonable(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(k): _jsonable(value[k]) for k in sorted(value, key=lambda k: str(k))}
    if isinstance(value, (list, tuple)):
        return [_jsonable(item) for item in value]
    if isinstance(value, set):
        return sorted((_jsonable(item) for item in value), key=lambda item: _canonical(item))
    if isinstance(value, str):
        return _text(value)
    return value


def _canonical(value: Any) -> str:
    return json.dumps(_jsonable(value), ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)


def derive_identifier(
    source_system: str,
    source_key: str | None = None,
    *,
    identity: Mapping[str, Any] | None = None,
) -> str:
    """Derive a stable `arc_<hex>` id from source identity or canonical content.

    A supplied source key is preferred.  If absent, ``identity`` is hashed with
    sorted keys, making the result independent of mapping insertion order.
    """
    system = _text(source_system).casefold()
    if not system:
        raise ValueError("source_system must not be empty")
    basis: Any = {"source_system": system, "source_key": _text(source_key)} if source_key else {
        "source_system": system,
        "identity": identity or {},
    }
    digest = hashlib.sha256(_canonical(basis).encode("utf-8")).hexdigest()[:32]
    return f"arc_{digest}"


def validate_record(record: Mapping[str, Any]) -> list[ValidationIssue]:
    """Return all required-field and type issues; never raises for bad input."""
    issues: list[ValidationIssue] = []
    if not isinstance(record, Mapping):
        return [ValidationIssue("record", "expected a mapping", "invalid_type")]
    for key in ("title", "record_type"):
        value = record.get(key, _MISSING)
        if value is _MISSING or (value is not None and not _text(value)):
            issues.append(ValidationIssue(key, "is required and must not be blank", "required"))
    for key in ("title", "record_type", "description", "date"):
        if key in record and record[key] is not None and not isinstance(record[key], (str, int, float)):
            issues.append(ValidationIssue(key, "must be text-like or null", "invalid_type"))
    return issues


def normalize_record(
    source: Mapping[str, Any],
    *,
    source_system: str,
    source_key: str | None = None,
    metadata: Mapping[str, Any] | None = None,
    aliases: Mapping[str, str] | None = None,
) -> NormalizedRecord:
    """Normalize a source mapping while retaining unmapped data and provenance."""
    if not isinstance(source, Mapping):
        raise NormalizationError(validate_record(source))
    active_aliases = {**_DEFAULT_ALIASES, **(aliases or {})}
    normalized: dict[str, Any] = {}
    field_map: dict[str, tuple[str, ...]] = {}
    extras: dict[str, Any] = {}
    lossy: list[str] = []
    for raw_key in sorted(source, key=lambda key: str(key)):
        key = str(raw_key)
        target = active_aliases.get(key.casefold(), key.casefold())
        value = source[raw_key]
        if target in {"title", "record_type", "description", "date", "source_id"}:
            normalized[target] = None if value is None else _text(value)
            field_map.setdefault(target, ())
            field_map[target] = (*field_map[target], key)
        else:
            extras[key] = _jsonable(value)
            field_map.setdefault(f"attributes.{key}", ())
            field_map[f"attributes.{key}"] = (*field_map[f"attributes.{key}"], key)
    issues = validate_record(normalized)
    if issues:
        raise NormalizationError(issues)
    title = normalized["title"]
    record_type = normalized["record_type"]
    identity = {"title": title, "record_type": record_type, "date": normalized.get("date"), "attributes": extras}
    identifier = derive_identifier(source_system, source_key or normalized.get("source_id"), identity=identity)
    if source_key is None and "source_id" not in normalized:
        lossy.append("whitespace_and_unicode_normalization")
    provenance = Provenance(_text(source_system), _text(source_key or identifier), field_map, _jsonable(metadata or {}))
    return NormalizedRecord(identifier, title, record_type, normalized.get("description"), normalized.get("date"), extras, provenance, lossy_fields=tuple(lossy))
