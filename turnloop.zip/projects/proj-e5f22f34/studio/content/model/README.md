# Normalized archive model

`studio.content.model` is the stable boundary between source adapters and
publishing. Call `normalize_record(source, source_system=..., source_key=...)`
with a mapping; consume the returned `NormalizedRecord` or its `to_dict()`.

Required fields are `title` and `record_type`. Values are Unicode NFC-normalized
and surrounding/repeated whitespace is collapsed. Known aliases (`name`,
`label`, `kind`, `type`, `summary`, `id`) are mapped to canonical names. Other
fields remain in `attributes`, so normalization is loss-aware. `provenance`
contains the source system/key, metadata, and a source-to-normalized field map.

Identifiers are `arc_` plus the first 32 hexadecimal characters of SHA-256.
The hash uses the source system and explicit source key when available;
otherwise it uses canonical, sorted content. Thus input ordering does not
affect IDs. Never use a display title as a mutable external identifier: pass a
stable source key whenever the source provides one.

`validate_record()` returns all actionable issues. `normalize_record()` raises
`NormalizationError` containing those issues when required fields are missing
or invalid.
