"""The stable ingestion API.

Only local filesystem reads are performed.  Network URLs are rejected before
any fixture is read so an invocation remains offline by construction.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Mapping
from urllib.parse import urlparse


class IngestionError(ValueError):
    """A configuration or source-fixture validation error."""


def _read_json(path: Path, label: str) -> Any:
    try:
        with path.open("r", encoding="utf-8") as handle:
            return json.load(handle)
    except FileNotFoundError as exc:
        raise IngestionError(f"{label}: file does not exist: {path}") from exc
    except json.JSONDecodeError as exc:
        raise IngestionError(f"{label}: invalid JSON at line {exc.lineno}, column {exc.colno}") from exc
    except OSError as exc:
        raise IngestionError(f"{label}: cannot read {path}: {exc}") from exc


def _local_path(value: Any, base: Path, label: str) -> Path:
    if not isinstance(value, str) or not value.strip():
        raise IngestionError(f"{label}: expected a non-empty local path")
    parsed = urlparse(value)
    if parsed.scheme or parsed.netloc:
        raise IngestionError(f"{label}: network or URI paths are not allowed: {value}")
    path = Path(value)
    if not path.is_absolute():
        path = base / path
    return path.resolve()


def load_config(config_path: str | Path) -> tuple[Path, list[dict[str, str]]]:
    """Load and validate a config, returning its base directory and sources."""

    path = Path(config_path).resolve()
    config = _read_json(path, "config")
    if not isinstance(config, dict):
        raise IngestionError("config: expected a JSON object")
    sources = config.get("sources")
    if not isinstance(sources, list) or not sources:
        raise IngestionError("config.sources: expected a non-empty array")

    validated: list[dict[str, str]] = []
    seen: set[str] = set()
    for index, source in enumerate(sources):
        label = f"config.sources[{index}]"
        if not isinstance(source, dict):
            raise IngestionError(f"{label}: expected an object")
        source_id = source.get("source_id")
        if not isinstance(source_id, str) or not source_id.strip():
            raise IngestionError(f"{label}.source_id: expected a non-empty string")
        if source_id in seen:
            raise IngestionError(f"{label}.source_id: duplicate source identifier: {source_id}")
        seen.add(source_id)
        fixture = source.get("fixture")
        fixture_path = _local_path(fixture, path.parent, f"{label}.fixture")
        validated.append({"source_id": source_id, "fixture": str(fixture_path)})
    return path.parent, validated


def _record(source: Mapping[str, Any], source_id: str, fixture: Path, index: int) -> dict[str, Any]:
    if not isinstance(source, dict):
        raise IngestionError(f"{fixture}: records[{index}] must be an object")
    record_id = source.get("id")
    if not isinstance(record_id, str) or not record_id.strip():
        raise IngestionError(f"{fixture}: records[{index}].id must be a non-empty string")
    title = source.get("title")
    if not isinstance(title, str) or not title.strip():
        raise IngestionError(f"{fixture}: records[{index}].title must be a non-empty string")
    description = source.get("description")
    if description is not None and not isinstance(description, str):
        raise IngestionError(f"{fixture}: records[{index}].description must be a string or null")
    date = source.get("date")
    if date is not None and not isinstance(date, str):
        raise IngestionError(f"{fixture}: records[{index}].date must be a string or null")
    media = source.get("media", [])
    if not isinstance(media, list) or any(not isinstance(item, str) or not item.strip() for item in media):
        raise IngestionError(f"{fixture}: records[{index}].media must be an array of non-empty strings")
    metadata = source.get("metadata", {})
    if not isinstance(metadata, dict):
        raise IngestionError(f"{fixture}: records[{index}].metadata must be an object")

    return {
        "record_id": f"{source_id}:{record_id}",
        "title": title,
        "description": description,
        "date": date,
        "media": media,
        "metadata": metadata,
        "provenance": {
            "fixture_path": str(fixture),
            "source_identifier": source_id,
            "source_record_id": record_id,
            "source_record_index": index,
        },
        "source_record": source,
    }


def ingest(config_path: str | Path) -> list[dict[str, Any]]:
    """Ingest all configured local fixtures into stable, sorted record envelopes."""

    _, sources = load_config(config_path)
    records: list[dict[str, Any]] = []
    seen_ids: set[str] = set()
    for source in sources:
        fixture = Path(source["fixture"])
        payload = _read_json(fixture, f"fixture {fixture}")
        if not isinstance(payload, dict) or not isinstance(payload.get("records"), list):
            raise IngestionError(f"{fixture}: expected an object with a records array")
        for index, item in enumerate(payload["records"]):
            record = _record(item, source["source_id"], fixture, index)
            if record["record_id"] in seen_ids:
                raise IngestionError(f"duplicate record identifier: {record['record_id']}")
            seen_ids.add(record["record_id"])
            records.append(record)
    return sorted(records, key=lambda item: (item["record_id"], item["provenance"]["fixture_path"]))


def ingest_to_json(config_path: str | Path) -> str:
    """Return canonical JSON suitable for a checked-in or pipeline artifact."""

    return json.dumps(ingest(config_path), ensure_ascii=False, indent=2, sort_keys=True) + "\n"
