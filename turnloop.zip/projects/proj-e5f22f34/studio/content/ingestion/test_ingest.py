import json
import tempfile
import unittest
from pathlib import Path

from .ingest import IngestionError, ingest, ingest_to_json


HERE = Path(__file__).parent


class IngestionTests(unittest.TestCase):
    def test_fixture_ingestion_is_sorted_and_traceable(self):
        config = HERE / "fixtures" / "ingestion.json"
        first = ingest(config)
        second = ingest(config)
        self.assertEqual(first, second)
        self.assertEqual([item["record_id"] for item in first], [
            "community-alpha:alpha-001", "community-alpha:alpha-002", "community-beta:beta-001"
        ])
        self.assertEqual(first[0]["provenance"]["source_identifier"], "community-alpha")
        self.assertEqual(first[0]["provenance"]["source_record_id"], "alpha-001")
        self.assertEqual(first[0]["source_record"]["media"], ["audio/mpeg"])

    def test_json_output_is_machine_readable_and_canonical(self):
        output = ingest_to_json(HERE / "fixtures" / "ingestion.json")
        self.assertEqual(json.loads(output)[0]["record_id"], "community-alpha:alpha-001")
        self.assertTrue(output.endswith("\n"))

    def test_malformed_record_fails_without_partial_results(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "bad.json").write_text('{"records":[{"id":"x"}]}', encoding="utf-8")
            config = root / "config.json"
            config.write_text('{"sources":[{"source_id":"local","fixture":"bad.json"}]}', encoding="utf-8")
            with self.assertRaisesRegex(IngestionError, r"title must be"):
                ingest(config)

    def test_network_fixture_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            config = Path(directory) / "config.json"
            config.write_text('{"sources":[{"source_id":"remote","fixture":"https://example.test/data.json"}]}', encoding="utf-8")
            with self.assertRaisesRegex(IngestionError, "not allowed"):
                ingest(config)


if __name__ == "__main__":
    unittest.main()
