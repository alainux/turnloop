# Offline collection ingestion

This namespace turns explicit local JSON fixtures into deterministic ingested-record JSON. It uses only the filesystem; URI and network fixture paths are rejected.

Run from the project root:

```sh
python -m studio.content.ingestion studio/content/ingestion/fixtures/ingestion.json
python -m unittest studio.content.ingestion.test_ingest
```

## Input

The config is a JSON object with a non-empty `sources` array. Each source has a unique non-empty `source_id` and a local `fixture` path, resolved relative to the config file. A fixture is an object with a `records` array. Each record requires non-empty string `id` and `title`; it may contain string-or-null `description` and `date`, an array of non-empty string `media`, and object `metadata`. Unknown fields are accepted and retained.

## Output

The API `ingest(config_path)` returns a list of envelopes, and the CLI writes the same list as indented, sorted-key JSON. Each envelope contains `record_id` (`source_id:id`), canonical fields, the original complete `source_record`, and `provenance` with `fixture_path`, `source_identifier`, `source_record_id`, and zero-based `source_record_index`.

Records are sorted by `record_id` (then fixture path), duplicate identifiers are errors, and validation is all-or-nothing: malformed config or fixtures raises `IngestionError` and produces no output. Missing files, invalid JSON, unsupported paths, and invalid field types produce explicit errors on stderr in the CLI (exit code 2).
