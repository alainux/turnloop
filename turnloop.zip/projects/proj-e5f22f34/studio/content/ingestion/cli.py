"""Command-line entry point for offline ingestion."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .ingest import IngestionError, ingest_to_json


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Ingest local community-archive fixtures")
    parser.add_argument("config", type=Path, help="path to an ingestion config JSON file")
    parser.add_argument("-o", "--output", type=Path, help="write JSON output to this local file (default: stdout)")
    args = parser.parse_args(argv)
    try:
        result = ingest_to_json(args.config)
        if args.output:
            args.output.write_text(result, encoding="utf-8")
        else:
            sys.stdout.write(result)
    except (IngestionError, OSError) as exc:
        print(f"ingestion error: {exc}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
