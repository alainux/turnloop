"""Offline, deterministic ingestion for community-archive source fixtures."""

from .ingest import IngestionError, ingest, ingest_to_json, load_config

__all__ = ["IngestionError", "ingest", "ingest_to_json", "load_config"]
