import json
from pathlib import Path
import tempfile
import unittest
import zipfile

from .release import PackagingError, package_release, stage_release


class ReleasePackagingTests(unittest.TestCase):
    def test_staging_and_packaging_are_byte_stable(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = root / "build"
            source.mkdir()
            (source / "site").mkdir()
            (source / "site" / "index.html").write_text("index\n", encoding="utf-8")
            (source / "site" / "b.txt").write_text("B\n", encoding="utf-8")
            (source / "site" / "a.txt").write_text("A\n", encoding="utf-8")
            first_stage = root / "stage-one"
            second_stage = root / "stage-two"
            artifacts = [{"source": "site/index.html", "path": "site/index.html"}, "site/b.txt", "site/a.txt"]
            stage_release(source, first_stage, version="2.0.0", artifacts=artifacts, metadata={"z": 1, "a": "x"})
            stage_release(source, second_stage, version="2.0.0", artifacts=list(reversed(artifacts)), metadata={"a": "x", "z": 1})
            first = package_release(first_stage, root / "first.zip")
            second = package_release(second_stage, root / "second.zip")
            self.assertEqual(first.sha256, second.sha256)
            self.assertEqual((root / "first.zip").read_bytes(), (root / "second.zip").read_bytes())
            with zipfile.ZipFile(root / "first.zip") as archive:
                self.assertEqual(archive.namelist(), ["manifest.json", "site/a.txt", "site/b.txt", "site/index.html"])
                self.assertTrue(all(info.date_time == (1980, 1, 1, 0, 0, 0) for info in archive.infolist()))
                self.assertEqual(json.loads(archive.read("manifest.json"))["release_version"], "2.0.0")

    def test_missing_and_unsafe_artifacts_fail(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = root / "source"
            source.mkdir()
            (source / "site").mkdir()
            (source / "site" / "index.html").write_text("ok", encoding="utf-8")
            for artifact in ("missing.txt", "../secret.txt", "/tmp/escape.txt"):
                with self.subTest(artifact=artifact), self.assertRaisesRegex(PackagingError, "artifact|path"):
                    stage_release(source, root / ("stage-" + str(len(artifact))), version="1.0.0", artifacts=[artifact])

    def test_stage_rejects_stale_contents_and_package_rejects_unlisted_files(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = root / "source"
            source.mkdir()
            (source / "site").mkdir()
            (source / "site" / "index.html").write_text("ok", encoding="utf-8")
            stage = root / "stage"
            stage.mkdir()
            (stage / "stale").write_text("stale", encoding="utf-8")
            with self.assertRaisesRegex(PackagingError, "absent or empty"):
                stage_release(source, stage, version="1.0.0", artifacts=["site/index.html"])
            stage_release(source, root / "clean", version="1.0.0", artifacts=["site/index.html"])
            (root / "clean" / "unlisted.txt").write_text("no", encoding="utf-8")
            with self.assertRaisesRegex(PackagingError, "not represented"):
                package_release(root / "clean", root / "out.zip")


if __name__ == "__main__":
    unittest.main()
