# Offline release packaging

`studio.release.packaging` stages an explicit list of local build artifacts and
packages the resulting directory as a deterministic ZIP. It performs no
network access. Source and destination paths are relative to their respective
roots; absolute paths, parent traversal, symlinks, missing files, duplicate
destinations, and stale stage contents are rejected.

```python
from studio.release.packaging import package_release, stage_release

stage_release(
    "build",
    ".release-stage",
    version="1.2.0",
    artifacts=[
        {"source": "demo/index.html", "path": "site/index.html", "role": "entrypoint"},
        {"source": "demo/app.js", "path": "runtime/app.js"},
    ],
    metadata={"channel": "offline"},
)
package_release(".release-stage", "dist/archive-1.2.0.zip", version="1.2.0")
```

The stage contains `manifest.json` conforming to the release layout contract,
with the release version, entrypoint, and sorted artifact records including
role, byte size, and SHA-256. ZIP entries are sorted, use fixed 1980
timestamps and 0644 permissions, and are stored without filesystem timestamps
or host paths. The current layout contract intentionally has no open-ended
metadata field; the `metadata` argument is reserved for forward compatibility.
