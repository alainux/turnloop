"""Build reproducible offline release directories and ZIP archives.

The artifact list is deliberately explicit so an integration branch can feed
the eventual layout/manifest contract without this helper guessing which
build products are required.  All paths in that list are relative to the
source root and are copied to relative paths in the staging root.
"""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
from pathlib import Path, PurePosixPath
import os
import tempfile
from typing import Any, Iterable, Mapping
import zipfile
import re

from ..paths import PackagePathError, normalize_package_path


class PackagingError(ValueError):
    """Raised when release inputs cannot safely produce a complete package."""


@dataclass(frozen=True)
class StageResult:
    """The immutable facts recorded after staging a release."""

    staging_root: Path
    version: str
    manifest_path: Path
    files: tuple[str, ...]
    sha256: str


@dataclass(frozen=True)
class PackageResult:
    """The output path and digest of a packaged release."""

    package_path: Path
    version: str
    sha256: str
    files: tuple[str, ...]


def _canonical(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _version(value: Any) -> str:
    if not isinstance(value, str) or not value.strip() or value.strip() in {".", ".."}:
        raise PackagingError("version must be a non-empty string")
    result = value.strip()
    if not re.fullmatch(r"[0-9]+\.[0-9]+\.[0-9]+(?:-[0-9A-Za-z.-]+)?(?:\+[0-9A-Za-z.-]+)?", result):
        raise PackagingError("version must be SemVer (for example, 1.2.3)")
    return result


def _relative_path(value: Any, label: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise PackagingError(f"{label}: expected a non-empty relative path")
    try:
        return normalize_package_path(value)
    except PackagePathError as exc:
        raise PackagingError(f"{label}: path must stay within its root: {value!r}") from exc


def _artifact_entries(artifacts: Iterable[Any]) -> list[tuple[str, str, str | None]]:
    entries: list[tuple[str, str, str | None]] = []
    for index, artifact in enumerate(artifacts):
        label = f"artifacts[{index}]"
        if isinstance(artifact, str):
            source = destination = artifact
        elif isinstance(artifact, Mapping):
            source = artifact.get("source")
            destination = artifact.get("path", source)
            role = artifact.get("role")
            if role is not None and not isinstance(role, str):
                raise PackagingError(f"{label}.role: expected a string")
        else:
            raise PackagingError(f"{label}: expected a path or object")
        if isinstance(artifact, str):
            role = None
        source_path = _relative_path(source, f"{label}.source")
        destination_path = _relative_path(destination, f"{label}.path")
        entries.append((source_path, destination_path, role))
    if not entries:
        raise PackagingError("artifacts: expected at least one source artifact")
    destinations = [destination for _, destination, _ in entries]
    if len(destinations) != len(set(destinations)):
        raise PackagingError("artifacts: duplicate destination path")
    return sorted(entries, key=lambda item: (item[1], item[0]))


def _inside(root: Path, relative: str, label: str) -> Path:
    lexical = root / Path(*PurePosixPath(relative).parts)
    candidate = lexical.resolve()
    try:
        candidate.relative_to(root.resolve())
    except ValueError as exc:
        raise PackagingError(f"{label}: path escapes its root: {relative!r}") from exc
    return candidate


def _reject_symlink_components(root: Path, relative: str, label: str) -> None:
    current = root
    for part in PurePosixPath(relative).parts:
        current /= part
        if current.is_symlink():
            raise PackagingError(f"{label}: symlinks are not allowed: {relative!r}")


def _digest(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def stage_release(
    source_root: str | Path,
    staging_root: str | Path,
    *,
    version: str,
    artifacts: Iterable[Any],
    metadata: Mapping[str, Any] | None = None,
    entrypoint: str = "site/index.html",
) -> StageResult:
    """Copy explicit local artifacts into a fresh, self-contained stage.

    ``artifacts`` accepts ``"source/file"`` or ``{"source": ..., "path":
    ...}``.  The latter permits a source build path to map to the stable
    eventual release layout.  The stage must be absent or empty; this avoids
    stale files silently entering a release.
    """
    source = Path(source_root).resolve()
    stage = Path(staging_root).resolve()
    release_version = _version(version)
    entries = _artifact_entries(artifacts)
    entrypoint_name = _relative_path(entrypoint, "entrypoint")
    if not source.is_dir():
        raise PackagingError(f"source root does not exist or is not a directory: {source}")
    if stage.exists() and (not stage.is_dir() or any(stage.iterdir())):
        raise PackagingError(f"staging root must be absent or empty: {stage}")
    stage.mkdir(parents=True, exist_ok=True)

    copied: list[dict[str, Any]] = []
    try:
        for source_name, destination_name, declared_role in entries:
            _reject_symlink_components(source, source_name, "source artifact")
            _reject_symlink_components(stage, destination_name, "destination artifact")
            source_path = _inside(source, source_name, "source artifact")
            if not source_path.is_file():
                raise PackagingError(f"missing source artifact: {source_name}")
            destination = _inside(stage, destination_name, "destination artifact")
            destination.parent.mkdir(parents=True, exist_ok=True)
            data = source_path.read_bytes()
            destination.write_bytes(data)
            os.chmod(destination, 0o644)
            role = declared_role or ("presentation" if destination_name.startswith("site/") else "data" if destination_name.startswith("data/") else "asset" if destination_name.startswith("assets/") else "runtime")
            if destination_name == entrypoint_name:
                role = "entrypoint"
            if role not in {"entrypoint", "presentation", "data", "asset", "runtime"}:
                raise PackagingError(f"invalid artifact role for {destination_name}: {role}")
            copied.append({"path": destination_name, "role": role, "size_bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
        if entrypoint_name not in {item["path"] for item in copied}:
            raise PackagingError(f"missing entrypoint artifact: {entrypoint_name}")
        manifest = {
            "manifest_version": 1,
            "release_version": release_version,
            "content_schema": "normalized-archive/v1",
            "discovery_schema_version": 1,
            "entrypoint": entrypoint_name,
            "files": sorted(copied, key=lambda item: item["path"]),
        }
        # `metadata` is accepted for forward compatibility, but the current
        # layout contract intentionally has no open-ended manifest field.
        if metadata is not None:
            _canonical(dict(metadata))
        manifest_path = stage / "manifest.json"
        manifest_path.write_text(_canonical(manifest) + "\n", encoding="utf-8")
        os.chmod(manifest_path, 0o644)
    except Exception:
        # Never leave a partially assembled stage for a caller to mistake as valid.
        for path in sorted(stage.rglob("*"), reverse=True):
            if path.is_file() or path.is_symlink():
                path.unlink()
            elif path.is_dir():
                path.rmdir()
        raise

    files = tuple([item["path"] for item in copied] + ["manifest.json"])
    return StageResult(stage, release_version, manifest_path, files, _digest(manifest_path))


def package_release(
    staging_root: str | Path,
    output_path: str | Path,
    *,
    version: str | None = None,
) -> PackageResult:
    """Write a byte-stable ZIP from a validated staging directory atomically."""
    stage = Path(staging_root).resolve()
    manifest_path = _inside(stage, "manifest.json", "manifest")
    if not manifest_path.is_file() or manifest_path.is_symlink():
        raise PackagingError(f"missing release manifest: {manifest_path}")
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        release_version = _version(manifest["release_version"])
        records = manifest["files"]
        if not isinstance(records, list):
            raise TypeError("files must be a list")
        listed_records = []
        for index, item in enumerate(records):
            if not isinstance(item, Mapping):
                raise TypeError(f"files[{index}] must be an object")
            name = _relative_path(item["path"], f"manifest.files[{index}].path")
            if not isinstance(item.get("sha256"), str) or not isinstance(item.get("size_bytes"), int):
                raise TypeError(f"files[{index}] has invalid digest metadata")
            listed_records.append((name, item["size_bytes"], item["sha256"]))
        listed = {name for name, _, _ in listed_records}
        if len(listed) != len(listed_records):
            raise ValueError("duplicate manifest path")
    except (OSError, json.JSONDecodeError, KeyError, TypeError, PackagingError) as exc:
        raise PackagingError(f"invalid release manifest: {manifest_path}") from exc
    if version is not None and _version(version) != release_version:
        raise PackagingError("requested version does not match release manifest")
    actual = {
        path.relative_to(stage).as_posix()
        for path in stage.rglob("*")
        if path.is_file() and not path.is_symlink()
    }
    expected = listed | {"manifest.json"}
    if actual != expected:
        raise PackagingError("staging root contains files not represented by the release manifest")
    for name, size, digest in listed_records:
        file_path = _inside(stage, name, "manifest file")
        if file_path.stat().st_size != size or _digest(file_path) != digest:
            raise PackagingError(f"manifest checksum mismatch: {name}")
    output = Path(output_path).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    file_names = tuple(sorted(actual))
    temp_name: str | None = None
    try:
        with tempfile.NamedTemporaryFile(prefix=".release-", suffix=".zip", dir=output.parent, delete=False) as handle:
            temp_name = handle.name
        with zipfile.ZipFile(temp_name, "w", compression=zipfile.ZIP_STORED) as archive:
            for name in file_names:
                info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
                info.create_system = 3
                info.external_attr = 0o100644 << 16
                archive.writestr(info, _inside(stage, name, "package file").read_bytes())
        os.replace(temp_name, output)
    finally:
        if temp_name and Path(temp_name).exists():
            Path(temp_name).unlink()
    return PackageResult(output, release_version, _digest(output), file_names)
