import json
from pathlib import Path
import tempfile
import zipfile

import pytest

from .validation import ValidationError, validate_release
from .workflow import build_release


RECORDS = [
    {"id": "record-2", "title": "Second", "record_type": "community-item", "description": "B"},
    {"id": "record-1", "title": "First", "record_type": "community-item", "description": "A"},
]


def test_workflow_packages_and_validates_complete_demo_release():
    with tempfile.TemporaryDirectory() as directory:
        result = build_release(RECORDS, Path(directory) / "archive.zip", version="1.4.0")
        assert result.package_validation.files == (
            "data/records.json", "data/search.json", "site/exhibits/record-1.html",
            "site/exhibits/record-2.html", "site/index.html",
        )
        with zipfile.ZipFile(result.package.package_path) as archive:
            assert json.loads(archive.read("data/records.json"))[0]["id"] == "record-1"
            assert "site/index.html" in archive.namelist()


def test_workflow_is_byte_reproducible_for_same_inputs():
    with tempfile.TemporaryDirectory() as directory:
        first = build_release(RECORDS, Path(directory) / "one.zip", version="1.0.0")
        second = build_release(list(reversed(RECORDS)), Path(directory) / "two.zip", version="1.0.0")
        assert first.package.sha256 == second.package.sha256


@pytest.mark.parametrize("bad_records, message", [
    ([{"id": "unsafe/record", "title": "Bad", "record_type": "item"}], "path-safe"),
    ([{"id": "record-1", "record_type": "item"}], "title"),
])
def test_workflow_rejects_malformed_demo_artifacts_before_packaging(bad_records, message):
    with tempfile.TemporaryDirectory() as directory:
        with pytest.raises(ValueError, match=message):
            build_release(bad_records, Path(directory) / "archive.zip", version="1.0.0")


def test_validator_reports_missing_artifact_from_workflow_package():
    with tempfile.TemporaryDirectory() as directory:
        output = Path(directory) / "archive.zip"
        build_release(RECORDS, output, version="1.0.0")
        broken = Path(directory) / "broken"
        broken.mkdir()
        with zipfile.ZipFile(output) as archive:
            for name in archive.namelist():
                if name != "data/search.json":
                    archive.extract(name, broken)
        with pytest.raises(ValidationError, match="data/search.json"):
            validate_release(broken)
