"""Command-line entry point for the complete offline release workflow."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

from .workflow import build_release


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Build and validate an offline archive release ZIP")
    parser.add_argument("records", type=Path, help="JSON file containing normalized archive records")
    parser.add_argument("output", type=Path, help="destination ZIP path")
    parser.add_argument("--version", required=True, help="explicit SemVer release version")
    args = parser.parse_args(argv)
    try:
        records = json.loads(args.records.read_text(encoding="utf-8"))
        if not isinstance(records, list):
            raise ValueError("records JSON must contain an array")
        result = build_release(records, args.output, version=args.version)
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        print(f"release error: {exc}", file=sys.stderr)
        return 2
    print(f"validated release {result.package_validation.release_version}: {result.package.package_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
