"""Command-line release validation for offline build scripts."""

from __future__ import annotations

import argparse

from .validate import ValidationError, validate_release


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate an offline archive release directory or ZIP")
    parser.add_argument("release", help="staged release directory or ZIP path")
    parser.add_argument("--version", dest="expected_version", help="require this SemVer release version")
    args = parser.parse_args()
    try:
        result = validate_release(args.release, expected_version=args.expected_version)
    except ValidationError as error:
        print(error)
        return 1
    print(f"valid release {result.release_version}: {result.entrypoint} ({len(result.files)} files)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
