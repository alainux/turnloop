# Release validation

`studio.release.validation.validate_release` validates a staged release
directory or a ZIP produced by release packaging. It is offline and uses only
the Python standard library.

The same check is available to release scripts with `python -m
studio.release.validation RELEASE [--version VERSION]`. The test module builds
its fixtures through the packaging API, keeping byte sizes and digests tied to
the actual layout contract rather than duplicating stale manifest snapshots.

Validation first checks the declared manifest contract (required fields,
SemVer, schema values, supported roles, unique normalized paths, and SHA-256
format), then checks the assembled artifact: the required entrypoint and
`data/records.json` plus `data/search.json` exist, every shipped file is listed,
every listed file exists, and its byte size and digest match. Symlinks, unsafe
paths, duplicate ZIP entries, malformed JSON, and unlisted/extraneous files
fail with all available field- or artifact-specific diagnostics.

```python
from studio.release.validation import ValidationError, validate_release

try:
    result = validate_release(".release-stage", expected_version="1.2.3")
except ValidationError as error:
    print(error)
else:
    print(f"validated {result.release_version}: {result.entrypoint}")
```
