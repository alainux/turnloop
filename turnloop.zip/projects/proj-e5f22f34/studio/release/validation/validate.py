"""Validate release artifacts against the release/layout contract.

This module deliberately has no network or third-party dependencies.  It
checks both the manifest and the bytes it describes, so a successful result is
safe to consume as a self-contained offline release.
"""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import re
import zipfile
from typing import Any

from ..paths import PackagePathError, normalize_package_path


class ValidationError(ValueError):
    """Raised when a release is invalid; ``errors`` contains diagnostics."""

    def __init__(self, errors: list[str]):
        self.errors = tuple(errors)
        super().__init__("release validation failed:\n" + "\n".join(f"- {error}" for error in self.errors))


@dataclass(frozen=True)
class ValidationResult:
    """Facts about a release that passed validation."""

    release_version: str
    entrypoint: str
    files: tuple[str, ...]


_SEMVER = re.compile(r"^[0-9]+\.[0-9]+\.[0-9]+(?:-[0-9A-Za-z.-]+)?(?:\+[0-9A-Za-z.-]+)?$")
_ROLES = {"entrypoint", "presentation", "data", "asset", "runtime"}
_REQUIRED = {"site/index.html", "data/records.json", "data/search.json"}
_FIELDS = {"manifest_version", "release_version", "content_schema", "discovery_schema_version", "entrypoint", "files"}
_FILE_FIELDS = {"path", "role", "size_bytes", "sha256"}


def _loads(data: bytes, label: str) -> Any:
    try:
        return json.loads(data.decode("utf-8"), object_pairs_hook=_pairs)
    except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as exc:
        raise ValidationError([f"{label}: invalid UTF-8 JSON ({exc})"]) from exc


def _pairs(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate JSON key {key!r}")
        result[key] = value
    return result


def _path(value: Any, label: str, errors: list[str]) -> str | None:
    try:
        normalized = normalize_package_path(value)
    except (PackagePathError, TypeError) as exc:
        errors.append(f"{label}: unsafe package path ({exc})")
        return None
    if normalized != value:
        errors.append(f"{label}: must use its normalized POSIX form ({normalized!r})")
    return normalized


def _manifest(manifest: Any) -> tuple[dict[str, Any] | None, list[str]]:
    errors: list[str] = []
    if not isinstance(manifest, dict):
        return None, ["manifest.json: expected a JSON object"]
    extra = set(manifest) - _FIELDS
    missing = _FIELDS - set(manifest)
    errors.extend(f"manifest.{key}: unsupported field" for key in sorted(extra))
    errors.extend(f"manifest.{key}: missing required field" for key in sorted(missing))
    if manifest.get("manifest_version") != 1:
        errors.append("manifest.manifest_version: expected 1")
    if manifest.get("content_schema") != "normalized-archive/v1":
        errors.append("manifest.content_schema: expected 'normalized-archive/v1'")
    if manifest.get("discovery_schema_version") != 1:
        errors.append("manifest.discovery_schema_version: expected 1")
    version = manifest.get("release_version")
    if not isinstance(version, str) or not _SEMVER.fullmatch(version):
        errors.append("manifest.release_version: expected SemVer MAJOR.MINOR.PATCH")
    entrypoint = _path(manifest.get("entrypoint"), "manifest.entrypoint", errors)
    records = manifest.get("files")
    if not isinstance(records, list) or not records:
        errors.append("manifest.files: expected a non-empty array")
        return manifest, errors
    paths: set[str] = set()
    for index, record in enumerate(records):
        label = f"manifest.files[{index}]"
        if not isinstance(record, dict):
            errors.append(f"{label}: expected an object")
            continue
        errors.extend(f"{label}.{key}: unsupported field" for key in sorted(set(record) - _FILE_FIELDS))
        errors.extend(f"{label}.{key}: missing required field" for key in sorted(_FILE_FIELDS - set(record)))
        path = _path(record.get("path"), f"{label}.path", errors)
        if path is not None:
            if path in paths:
                errors.append(f"{label}.path: duplicate path {path!r}")
            paths.add(path)
        if record.get("role") not in _ROLES:
            errors.append(f"{label}.role: unsupported role {record.get('role')!r}")
        size = record.get("size_bytes")
        if isinstance(size, bool) or not isinstance(size, int) or size < 0:
            errors.append(f"{label}.size_bytes: expected a non-negative integer")
        digest = record.get("sha256")
        if not isinstance(digest, str) or not re.fullmatch(r"[a-f0-9]{64}", digest):
            errors.append(f"{label}.sha256: expected 64 lowercase hexadecimal characters")
    if entrypoint is not None and entrypoint not in paths:
        errors.append(f"manifest.entrypoint: not listed in files ({entrypoint!r})")
    if entrypoint is not None:
        matches = [r for r in records if isinstance(r, dict) and r.get("path") == entrypoint]
        if matches and matches[0].get("role") != "entrypoint":
            errors.append(f"manifest.files: entrypoint {entrypoint!r} must have role 'entrypoint'")
    missing_required = _REQUIRED - paths
    errors.extend(f"manifest.files: missing required artifact {path!r}" for path in sorted(missing_required))
    return manifest, errors


def _digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def validate_release(release: str | Path, *, expected_version: str | None = None) -> ValidationResult:
    """Validate a release directory or ZIP and return its manifest facts.

    All discovered errors are returned in one :class:`ValidationError` with
    field paths and artifact names suitable for build logs.
    """
    source = Path(release)
    errors: list[str] = []
    entries: dict[str, bytes] = {}
    if source.is_dir():
        for path in source.rglob("*"):
            relative = path.relative_to(source).as_posix()
            _path(relative, "release entry", errors)
            if path.is_symlink():
                errors.append(f"release.{relative}: symlinks are not allowed")
            elif path.is_file():
                entries[relative] = path.read_bytes()
    elif source.is_file() and zipfile.is_zipfile(source):
        try:
            with zipfile.ZipFile(source) as archive:
                for info in archive.infolist():
                    name = info.filename
                    safe = _path(name, "archive entry", errors)
                    if safe is None or safe in entries:
                        if safe in entries:
                            errors.append(f"archive entry: duplicate path {safe!r}")
                        continue
                    if info.is_dir():
                        continue
                    if info.create_system == 3 and ((info.external_attr >> 16) & 0o170000) == 0o120000:
                        errors.append(f"archive entry {name!r}: symlinks are not allowed")
                    entries[safe] = archive.read(info)
        except (OSError, zipfile.BadZipFile) as exc:
            errors.append(f"release archive: cannot read ZIP ({exc})")
    else:
        raise ValidationError([f"release: expected a directory or ZIP file: {source}"])
    if "manifest.json" not in entries:
        errors.append("manifest.json: missing required release manifest")
        raise ValidationError(errors)
    try:
        manifest = _loads(entries["manifest.json"], "manifest.json")
    except ValidationError as exc:
        errors.extend(exc.errors)
        raise ValidationError(errors)
    manifest, manifest_errors = _manifest(manifest)
    errors.extend(manifest_errors)
    if manifest is None:
        raise ValidationError(errors)
    version = manifest.get("release_version")
    if expected_version is not None and version != expected_version:
        errors.append(f"manifest.release_version: expected {expected_version!r}, got {version!r}")
    records = manifest.get("files") if isinstance(manifest.get("files"), list) else []
    listed = {r.get("path") for r in records if isinstance(r, dict) and isinstance(r.get("path"), str)}
    actual = set(entries) - {"manifest.json"}
    for path in sorted(listed - actual):
        errors.append(f"artifact {path!r}: listed in manifest but missing from release")
    for path in sorted(actual - listed):
        errors.append(f"artifact {path!r}: present in release but not listed in manifest")
    for record in records:
        path = record.get("path") if isinstance(record, dict) else None
        if path not in entries:
            continue
        data = entries[path]
        if record.get("size_bytes") != len(data):
            errors.append(f"manifest.files[{path!r}].size_bytes: expected {len(data)}, got {record.get('size_bytes')}")
        if record.get("sha256") != _digest(data):
            errors.append(f"manifest.files[{path!r}].sha256: digest does not match artifact bytes")
    if errors:
        raise ValidationError(errors)
    return ValidationResult(version, manifest["entrypoint"], tuple(sorted(listed)))
