import json
from pathlib import Path
import tempfile
import zipfile

import pytest

from studio.release.packaging import stage_release
from .validate import ValidationError, validate_release


def _stage(root: Path) -> Path:
    source = root / "build"
    (source / "site").mkdir(parents=True)
    (source / "data").mkdir()
    (source / "site/index.html").write_text("<main>offline</main>\n", encoding="utf-8")
    (source / "data/records.json").write_text("[]\n", encoding="utf-8")
    (source / "data/search.json").write_text('{"records":[]}\n', encoding="utf-8")
    stage_release(source, root / "release", version="1.2.3", artifacts=[
        {"source": "site/index.html", "path": "site/index.html", "role": "entrypoint"},
        "data/records.json", "data/search.json",
    ])
    return root / "release"


def _remove_last(_path: Path, manifest: dict) -> None:
    manifest["files"].pop()


def _bad_version(_path: Path, manifest: dict) -> None:
    manifest["release_version"] = "not-semver"


def test_valid_staged_release_passes_and_zip_is_supported():
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        release = _stage(root)
        result = validate_release(release, expected_version="1.2.3")
        assert result.entrypoint == "site/index.html"
        archive_path = root / "release.zip"
        with zipfile.ZipFile(archive_path, "w") as archive:
            for path in sorted(release.rglob("*")):
                if path.is_file():
                    archive.write(path, path.relative_to(release).as_posix())
        assert validate_release(archive_path).files == result.files


@pytest.mark.parametrize("change, expected", [
    (_remove_last, "missing required artifact"),
    (_bad_version, "release_version"),
    (lambda p, m: (p / "data/records.json").write_text("changed", encoding="utf-8"), "digest does not match"),
    (lambda p, m: (p / "extra.txt").write_text("extra", encoding="utf-8"), "not listed"),
])
def test_invalid_release_reports_actionable_diagnostics(change, expected):
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        release = _stage(root)
        manifest_path = release / "manifest.json"
        manifest = json.loads(manifest_path.read_text())
        change(release, manifest)
        manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
        with pytest.raises(ValidationError, match=expected):
            validate_release(release)


def test_manifest_rejects_unsafe_path_and_mismatched_size():
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        release = _stage(root)
        manifest_path = release / "manifest.json"
        manifest = json.loads(manifest_path.read_text())
        manifest["files"][0]["path"] = "../outside.html"
        manifest["files"][1]["size_bytes"] += 1
        manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
        with pytest.raises(ValidationError) as caught:
            validate_release(release)
        assert "unsafe package path" in str(caught.value)
        assert "size_bytes" in str(caught.value)
