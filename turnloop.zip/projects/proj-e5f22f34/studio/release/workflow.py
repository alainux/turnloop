"""End-to-end offline release assembly for the runnable archive demo."""

from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
import tempfile
from typing import Any, Iterable, Mapping, Sequence

from studio.discovery import serialize_result
from studio.presentation import PublicationResult, publish_exhibits

from .packaging import PackageResult, StageResult, package_release, stage_release
from .validation import ValidationResult, validate_release


@dataclass(frozen=True)
class ReleaseResult:
    """Outputs and validation facts for one completed release operation."""

    publication: PublicationResult
    stage: StageResult
    package: PackageResult
    stage_validation: ValidationResult
    package_validation: ValidationResult


def _records(records: Iterable[Any]) -> tuple[dict[str, Any], ...]:
    """Take one JSON-ready snapshot without changing caller-owned records."""
    snapshot: list[dict[str, Any]] = []
    for index, record in enumerate(records):
        if hasattr(record, "to_dict") and callable(record.to_dict):
            record = record.to_dict()
        if not isinstance(record, Mapping):
            raise ValueError(f"record {index} must be a mapping or NormalizedRecord")
        snapshot.append(dict(record))
    return tuple(snapshot)


def _json_bytes(value: Any) -> bytes:
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n").encode("utf-8")


def build_release(
    records: Iterable[Any],
    output_path: str | Path,
    *,
    version: str,
    query: str = "",
    filters: Mapping[str, Any] | None = None,
    facets: Sequence[str] = (),
    limit: int | None = None,
    view: Mapping[str, Any] | None = None,
) -> ReleaseResult:
    """Publish, package, and validate a self-contained offline ZIP release.

    The output is written only after the explicit artifacts have been staged
    and validated.  The final ZIP is validated again before this function
    returns, so callers can treat a returned result as release-ready.
    """
    snapshot = _records(records)
    publication = publish_exhibits(
        snapshot, query=query, filters=filters, facets=facets, limit=limit, view=view
    )
    output = Path(output_path)
    with tempfile.TemporaryDirectory(prefix="studio-release-") as directory:
        build_root = Path(directory) / "build"
        for relative, page in publication.presentation.pages.items():
            page_path = build_root / "site" / relative
            page_path.parent.mkdir(parents=True, exist_ok=True)
            page_path.write_text(page, encoding="utf-8", newline="\n")
        data_root = build_root / "data"
        data_root.mkdir(parents=True, exist_ok=True)
        (data_root / "records.json").write_bytes(_json_bytes(publication.index.records))
        (data_root / "search.json").write_bytes(_json_bytes(publication.discovery))

        artifacts = [
            {"source": "site/index.html", "path": "site/index.html", "role": "entrypoint"},
            *({"source": f"site/{path}", "path": f"site/{path}", "role": "presentation"}
              for path in publication.presentation.pages if path != "index.html"),
            {"source": "data/records.json", "path": "data/records.json", "role": "data"},
            {"source": "data/search.json", "path": "data/search.json", "role": "data"},
        ]
        stage = stage_release(build_root, Path(directory) / "stage", version=version, artifacts=artifacts)
        stage_validation = validate_release(stage.staging_root, expected_version=version)
        package = package_release(stage.staging_root, output, version=version)
    package_validation = validate_release(package.package_path, expected_version=version)
    return ReleaseResult(publication, stage, package, stage_validation, package_validation)
