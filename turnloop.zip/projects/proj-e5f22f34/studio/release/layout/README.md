# Offline release layout

This directory defines the boundary between studio outputs and release
packaging. It is a contract, not a packager or a manifest validator.

## Package tree

Every release is a self-contained directory (or archive) with this shape:

```text
<release-root>/
├── manifest.json                 # required; conforms to manifest.schema.json
├── site/                         # required static presentation
│   ├── index.html                # manifest.entrypoint
│   └── exhibits/<record-id>.html # renderer output; zero or more
├── data/                         # required machine-readable studio outputs
│   ├── records.json              # normalized archive records
│   └── search.json               # serialized discovery result/index payload
├── assets/                       # optional local media, styles, and scripts
└── runtime/                      # optional local runtime support files
```

`site/index.html` must work when opened directly from the filesystem. Runtime
code may only reference files inside this release; network requests, remote
fonts, CDNs, and absolute URLs for package content are not release inputs.

The presentation renderer's `index.html` and `exhibits/<id>.html` paths map
directly into `site/`. The content model is `normalized-archive/v1`; discovery
metadata is version `1`. Packaging may add files under `assets/` or `runtime/`,
but every shipped file must be listed in `manifest.json`.

## Manifest rules

The canonical schema is [manifest.schema.json](manifest.schema.json), and a
small valid fixture is [manifest.example.json](manifest.example.json).

Required top-level fields are `manifest_version`, `release_version`,
`content_schema`, `discovery_schema_version`, `entrypoint`, and `files`.
`release_version` is an explicit SemVer value (`MAJOR.MINOR.PATCH` with an
optional prerelease/build suffix). `files` is the complete package inventory:
paths are relative POSIX paths, unique, and rooted nowhere outside the release;
each entry includes a role, byte size, and lowercase SHA-256 digest. The
manifest itself is included in the package but is not listed in `files`, which
avoids a self-referential digest.

Missing fields, wrong types, unsupported roles, duplicate paths, unsafe paths,
and invalid digests are validation errors. A consumer should report the field
path (for example, `files[2].sha256`) and the reason; it should not guess a
default version or silently skip an invalid entry. `manifest.schema.json`
provides structural validation; `normalize_package_path` provides the shared
path-boundary check for producers and consumers.

All JSON written into a release should be UTF-8, deterministic, and use
relative references. Packaging, hashing, and full validation are deliberately
left to the downstream release-operation nodes.
