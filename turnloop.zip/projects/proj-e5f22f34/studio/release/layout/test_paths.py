import pytest

from studio.release import PackagePathError, join_package_path, normalize_package_path


def test_package_paths_are_normalized_as_relative_posix_paths():
    assert normalize_package_path("./site//exhibits/index.html") == "site/exhibits/index.html"
    assert join_package_path("site", ".", "index.html") == "site/index.html"


@pytest.mark.parametrize("value", ["", "/site/index.html", "../secret", "site/../secret", "site\\index.html", "C:/site/index.html"])
def test_package_paths_reject_escape_and_platform_ambiguity(value):
    with pytest.raises(PackagePathError):
        normalize_package_path(value)
