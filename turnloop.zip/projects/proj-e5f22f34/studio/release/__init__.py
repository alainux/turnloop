"""Release assembly and packaging for offline archive releases."""

from .paths import PackagePathError, join_package_path, normalize_package_path
from .workflow import ReleaseResult, build_release

__all__ = [
    "PackagePathError",
    "ReleaseResult",
    "build_release",
    "join_package_path",
    "normalize_package_path",
]

from .paths import PackagePathError, join_package_path, normalize_package_path

__all__ = ["PackagePathError", "join_package_path", "normalize_package_path"]
