"""Pure helpers for the release package's relative POSIX path boundary."""

from __future__ import annotations

import re


class PackagePathError(ValueError):
    """Raised when a path cannot safely name a file inside a release."""


_CONTROL = re.compile(r"[\x00-\x1f\x7f]")


def normalize_package_path(value: str) -> str:
    """Return a normalized, package-relative POSIX path.

    Duplicate separators and ``.`` components are removed. Traversal,
    absolute paths, backslashes, URI/drive prefixes, and control characters
    are rejected rather than silently rewritten across a package boundary.
    """
    if not isinstance(value, str) or not value:
        raise PackagePathError("package path must be a non-empty string")
    if _CONTROL.search(value):
        raise PackagePathError("package path must not contain control characters")
    if "\\" in value:
        raise PackagePathError("package path must use POSIX separators ('/')")
    if value.startswith("/"):
        raise PackagePathError("package path must be relative")
    components = [component for component in value.split("/") if component]
    if not components:
        raise PackagePathError("package path must name a file or directory")
    if components[0].endswith(":") or ":" in components[0]:
        raise PackagePathError("package path must not contain a drive or URI prefix")
    if any(component == ".." for component in components):
        raise PackagePathError("package path must not traverse its package root")
    components = [component for component in components if component != "."]
    if not components:
        raise PackagePathError("package path must name a file or directory")
    return "/".join(components)


def join_package_path(*parts: str) -> str:
    """Join path fragments and apply :func:`normalize_package_path`."""
    if not parts:
        raise PackagePathError("at least one package path part is required")
    return normalize_package_path("/".join(parts))
