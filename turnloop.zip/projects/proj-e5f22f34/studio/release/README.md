# Offline release workflow

`studio.release.build_release(records, output_path, version=...)` is the
runnable demo's release entry point. It composes the existing presentation
pipeline, layout, packaging, and validation contracts; it does not fetch
network resources or infer a release version.

```sh
python -m studio.release records.json dist/community-archive-1.0.0.zip --version 1.0.0
```

The input is a JSON array of normalized archive records. The workflow writes
renderer pages to `site/`, deterministic index and search payloads to `data/`,
stages the complete explicit inventory, validates the stage, creates a stable
ZIP, and validates the ZIP again. A successful return includes both validation
results. Missing, malformed, unsafe, unlisted, or checksum-mismatched
artifacts raise clear `ValueError`, packaging, or validation errors and do not
produce a successful result.

The release contract remains in [layout/README.md](layout/README.md), while
the lower-level operations remain available from `packaging` and `validation`
for scripts that need individual stages.
