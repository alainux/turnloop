from pathlib import Path
import zipfile

from studio.demo import run_demo
from studio.release.validation import validate_release


FIXTURE = Path(__file__).parents[1] / "content" / "ingestion" / "fixtures" / "ingestion.json"


def test_demo_connects_local_ingestion_search_and_accessible_exhibits(tmp_path):
    result = run_demo(FIXTURE, tmp_path / "archive.zip", version="1.0.0", query="map")

    assert len(result.records) == 3
    assert [item["title"] for item in result.release.publication.discovery["results"]] == ["Neighborhood map"]
    index = result.release.publication.presentation.pages["index.html"]
    assert 'lang="en"' in index
    assert 'aria-label="Primary"' in index
    assert "Neighborhood map" in index
    assert "Harvest gathering poster" not in index
    assert validate_release(result.release.package.package_path, expected_version="1.0.0").files


def test_demo_release_is_byte_reproducible(tmp_path):
    first = run_demo(FIXTURE, tmp_path / "one.zip", version="1.0.0")
    second = run_demo(FIXTURE, tmp_path / "two.zip", version="1.0.0")

    assert first.release.package.sha256 == second.release.package.sha256
    assert (tmp_path / "one.zip").read_bytes() == (tmp_path / "two.zip").read_bytes()
    with zipfile.ZipFile(tmp_path / "one.zip") as archive:
        assert "manifest.json" in archive.namelist()
        assert "site/index.html" in archive.namelist()
        assert "data/search.json" in archive.namelist()
