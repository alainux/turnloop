"""The smallest runnable composition of the offline archive studio."""

from .app import DemoResult, run_demo

__all__ = ["DemoResult", "run_demo"]
