# Studio demo integration result

The final integration lives in `studio.demo` and composes the completed
content, discovery/presentation, and release-operation contracts.

The runnable path is:

1. `content.integration.integrate` reads the local ingestion config and emits
   stable normalized records with provenance.
2. `release.workflow.build_release` calls the discovery/presentation pipeline,
   writes the selected search result and rendered exhibit pages, stages the
   explicit release inventory, and validates both stage and ZIP.
3. `studio.demo` exposes that path as `run_demo()` and `python -m studio.demo`.

Verification completed on 2026-08-14:

- `pytest -q`: 47 passed.
- CLI build from `studio/content/ingestion/fixtures/ingestion.json`: 3 records,
  1 `map` match, 4 pages, validated release.
- Two builds from identical inputs and version `1.0.0` had identical ZIP bytes
  and SHA-256 digest.
- No network or environment inputs are used; all source data is local JSON.
