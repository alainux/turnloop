"""Compose ingestion, discovery, presentation, and release operations.

This module owns orchestration only.  The domain contracts stay in their
respective namespaces and the demo passes their values through unchanged.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Sequence

from studio.content.integration import integrate
from studio.release import ReleaseResult, build_release


@dataclass(frozen=True)
class DemoResult:
    """The durable facts from one complete local demo run."""

    records: tuple[dict, ...]
    release: ReleaseResult


def run_demo(
    config_path: str | Path,
    output_path: str | Path,
    *,
    version: str,
    query: str = "",
    facets: Sequence[str] = ("record_type", "year"),
) -> DemoResult:
    """Build a validated, self-contained release from local source fixtures."""
    records = tuple(integrate(config_path))
    release = build_release(
        records,
        output_path,
        version=version,
        query=query,
        facets=facets,
        view={
            "title": "Community archive",
            "intro": "Explore stories, places, and materials preserved by the community.",
        },
    )
    return DemoResult(records, release)
