# Offline studio demo

`studio.demo` is the top-level composition boundary for the archive studio.
It reads only local ingestion fixtures, normalizes them through the content
foundation, searches them offline, renders accessible exhibit HTML, and
builds and validates a deterministic ZIP release.

From the repository root:

```sh
python -m studio.demo studio/content/ingestion/fixtures/ingestion.json dist/community-archive.zip --version 1.0.0 --query map
```

The query is applied before rendering the index; all validated exhibit pages
remain available in the package.  Use `--facet` repeatedly to choose discovery
facets.  No network access, timestamps, or environment values are used.
