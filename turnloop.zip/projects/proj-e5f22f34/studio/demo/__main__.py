"""Command-line entry point for the complete offline studio demo."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

from .app import run_demo


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Build a local community archive release")
    parser.add_argument("config", type=Path, help="local ingestion config JSON")
    parser.add_argument("output", type=Path, help="destination release ZIP")
    parser.add_argument("--version", required=True, help="explicit SemVer release version")
    parser.add_argument("--query", default="", help="offline thematic search query")
    parser.add_argument(
        "--facet", action="append", default=None,
        help="facet field to include (repeatable; defaults to record_type and year)",
    )
    args = parser.parse_args(argv)
    try:
        result = run_demo(
            args.config,
            args.output,
            version=args.version,
            query=args.query,
            facets=tuple(args.facet) if args.facet is not None else ("record_type", "year"),
        )
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"demo error: {exc}", file=sys.stderr)
        return 2

    publication = result.release.publication
    summary = {
        "records": len(result.records),
        "matches": len(publication.discovery["results"]),
        "pages": publication.presentation.metadata["page_count"],
        "release": str(result.release.package.package_path),
        "sha256": result.release.package.sha256,
    }
    print(json.dumps(summary, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
