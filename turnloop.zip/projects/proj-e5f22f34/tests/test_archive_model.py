import pytest

from studio.content.model import NormalizationError, derive_identifier, normalize_record, validate_record


def test_normalization_maps_aliases_and_keeps_provenance():
    record = normalize_record(
        {"name": "  Café\n  History ", "kind": " oral-history ", "year": 1984},
        source_system="catalogue",
        source_key="item-7",
        metadata={"batch": "spring"},
    )
    assert record.title == "Café History"
    assert record.record_type == "oral-history"
    assert record.attributes == {"year": 1984}
    assert record.provenance.field_map["title"] == ("name",)
    assert record.provenance.metadata == {"batch": "spring"}
    assert record.provenance.source_key == "item-7"


def test_identifier_is_order_independent_and_explicit_key_wins():
    first = {"title": "A", "record_type": "photo", "tags": ["x", "y"]}
    second = {"tags": ["x", "y"], "record_type": "photo", "title": "A"}
    assert derive_identifier("x", identity=first) == derive_identifier("x", identity=second)
    assert normalize_record(first, source_system="x", source_key="fixed").id == normalize_record(second, source_system="x", source_key="fixed").id


def test_required_errors_are_actionable_and_collective():
    issues = validate_record({"title": "  "})
    assert {issue.field for issue in issues} == {"title", "record_type"}
    with pytest.raises(NormalizationError) as error:
        normalize_record({}, source_system="x")
    assert "record_type" in str(error.value)


def test_edge_values_are_deterministically_normalized():
    record = normalize_record({"title": "A\u0301\t  B", "record_type": "note", "empty": None}, source_system="x")
    assert record.title == "Á B"
    assert record.attributes == {"empty": None}
    assert record.lossy_fields == ("whitespace_and_unicode_normalization",)
