"""JSON persistence and domain operations for habits.

``HabitStore`` persists this versioned JSON schema::

    {
      "version": 1,
      "next_id": 3,
      "habits": [
        {
          "id": 1,
          "name": "Read",
          "completions": ["2026-08-13", "2026-08-14"]
        }
      ]
    }

Habit IDs are positive integers and are never reused, including after ``clear``.
Habits are returned in ascending ID order and each habit's completion dates are
returned in ascending order.  A missing file represents an empty store.
"""

from __future__ import annotations

from datetime import date
import json
import os
from pathlib import Path
import re
import tempfile
from typing import Any


SCHEMA_VERSION = 1
_DATE_PATTERN = re.compile(r"[0-9]{4}-[0-9]{2}-[0-9]{2}\Z")
_CONTROL_CHARACTER_PATTERN = re.compile(r"[\x00-\x1f\x7f]")


class HabitTrackerError(Exception):
    """Base class for expected habit data-layer errors."""


class InvalidNameError(HabitTrackerError, ValueError):
    """Raised when a habit name cannot be used."""


class InvalidDateError(HabitTrackerError, ValueError):
    """Raised when a completion date is not a real strict ISO date."""


class InvalidHabitIdError(HabitTrackerError, ValueError):
    """Raised when a habit ID is not a positive integer."""


class HabitNotFoundError(HabitTrackerError):
    """Raised when a requested habit ID does not exist."""

    def __init__(self, habit_id: int) -> None:
        self.habit_id = habit_id
        super().__init__(f"habit ID {habit_id} does not exist")


class StorageError(HabitTrackerError):
    """Raised when the data file cannot be read or written."""


class CorruptDataError(StorageError):
    """Raised when the data file is not valid habit-tracker JSON."""


class HabitStore:
    """Store habits in a JSON file supplied by the caller.

    Public methods return fresh dictionaries; mutating a returned value never
    changes the store.  Every operation reloads the file so separate store
    instances observe one another's completed writes.
    """

    def __init__(self, path: str | os.PathLike[str]) -> None:
        try:
            self.path = Path(path)
        except TypeError as exc:
            raise StorageError("data path must be a path-like value") from exc

    def add(self, name: str) -> dict[str, Any]:
        """Add a named habit and return its new record."""

        clean_name = _normalise_name(name)
        state = self._load()
        habit = {
            "id": state["next_id"],
            "name": clean_name,
            "completions": [],
        }
        state["habits"].append(habit)
        state["next_id"] += 1
        self._save(state)
        return _copy_habit(habit)

    def list(self) -> list[dict[str, Any]]:
        """Return every habit in stable ascending ID order."""

        state = self._load()
        return [_copy_habit(habit) for habit in state["habits"]]

    def list_habits(self) -> list[dict[str, Any]]:
        """Descriptive alias for :meth:`list`."""

        return self.list()

    def complete(self, habit_id: int, completion_date: str) -> dict[str, Any]:
        """Record a habit completion on a strict ``YYYY-MM-DD`` date.

        Completing the same habit on the same date more than once is
        idempotent; the date appears only once.
        """

        clean_id = _validate_habit_id(habit_id)
        clean_date = _validate_date(completion_date)
        state = self._load()

        for habit in state["habits"]:
            if habit["id"] != clean_id:
                continue
            if clean_date not in habit["completions"]:
                habit["completions"].append(clean_date)
                habit["completions"].sort()
                self._save(state)
            return _copy_habit(habit)

        raise HabitNotFoundError(clean_id)

    def clear(self) -> int:
        """Remove all habits and return the number removed.

        ``next_id`` is deliberately retained so an ID is never reused.
        """

        state = self._load()
        removed = len(state["habits"])
        state["habits"] = []
        self._save(state)
        return removed

    def _load(self) -> dict[str, Any]:
        try:
            with self.path.open("r", encoding="utf-8") as data_file:
                raw = json.load(data_file)
        except FileNotFoundError:
            return _empty_state()
        except (json.JSONDecodeError, UnicodeDecodeError) as exc:
            raise CorruptDataError(
                f"data file {self.path} is not valid JSON"
            ) from exc
        except OSError as exc:
            raise StorageError(f"could not read data file {self.path}: {exc}") from exc

        return _validate_stored_state(raw, self.path)

    def _save(self, state: dict[str, Any]) -> None:
        parent = self.path.parent
        temporary_path: str | None = None

        try:
            parent.mkdir(parents=True, exist_ok=True)
            descriptor, temporary_path = tempfile.mkstemp(
                dir=parent,
                prefix=f".{self.path.name}.",
                suffix=".tmp",
            )
            with os.fdopen(descriptor, "w", encoding="utf-8") as data_file:
                json.dump(state, data_file, ensure_ascii=False, indent=2)
                data_file.write("\n")
                data_file.flush()
                os.fsync(data_file.fileno())
            os.replace(temporary_path, self.path)
            temporary_path = None
        except OSError as exc:
            raise StorageError(f"could not write data file {self.path}: {exc}") from exc
        finally:
            if temporary_path is not None:
                try:
                    os.unlink(temporary_path)
                except FileNotFoundError:
                    pass


# Compatibility-friendly names for callers that prefer "storage" terminology.
HabitStorage = HabitStore
JsonHabitStore = HabitStore


def _empty_state() -> dict[str, Any]:
    return {"version": SCHEMA_VERSION, "next_id": 1, "habits": []}


def _normalise_name(name: str) -> str:
    if not isinstance(name, str):
        raise InvalidNameError("habit name must be text")
    clean_name = name.strip()
    if not clean_name:
        raise InvalidNameError("habit name must not be empty")
    if _CONTROL_CHARACTER_PATTERN.search(clean_name):
        raise InvalidNameError("habit name must not contain control characters")
    return clean_name


def _validate_habit_id(habit_id: int) -> int:
    if isinstance(habit_id, bool) or not isinstance(habit_id, int) or habit_id < 1:
        raise InvalidHabitIdError("habit ID must be a positive integer")
    return habit_id


def _validate_date(value: str) -> str:
    if not isinstance(value, str) or _DATE_PATTERN.fullmatch(value) is None:
        raise InvalidDateError("date must use YYYY-MM-DD format")
    try:
        date.fromisoformat(value)
    except ValueError as exc:
        raise InvalidDateError(f"date is not a valid calendar date: {value}") from exc
    return value


def _validate_stored_state(raw: object, path: Path) -> dict[str, Any]:
    try:
        return _validated_state(raw)
    except (InvalidNameError, InvalidDateError, InvalidHabitIdError, ValueError) as exc:
        raise CorruptDataError(f"data file {path} has invalid contents: {exc}") from exc


def _validated_state(raw: object) -> dict[str, Any]:
    if not isinstance(raw, dict):
        raise ValueError("top-level value must be an object")
    if set(raw) != {"version", "next_id", "habits"}:
        raise ValueError("top-level keys must be version, next_id, and habits")

    version = raw["version"]
    if (
        not isinstance(version, int)
        or isinstance(version, bool)
        or version != SCHEMA_VERSION
    ):
        raise ValueError(f"version must be {SCHEMA_VERSION}")

    next_id = _validate_habit_id(raw["next_id"])
    habits = raw["habits"]
    if not isinstance(habits, list):
        raise ValueError("habits must be an array")

    clean_habits: list[dict[str, Any]] = []
    seen_ids: set[int] = set()
    for index, raw_habit in enumerate(habits):
        if not isinstance(raw_habit, dict):
            raise ValueError(f"habit at index {index} must be an object")
        if set(raw_habit) != {"id", "name", "completions"}:
            raise ValueError(
                f"habit at index {index} must contain id, name, and completions"
            )

        habit_id = _validate_habit_id(raw_habit["id"])
        if habit_id in seen_ids:
            raise ValueError(f"habit ID {habit_id} is duplicated")
        seen_ids.add(habit_id)

        name = _normalise_name(raw_habit["name"])
        if name != raw_habit["name"]:
            raise ValueError(f"habit ID {habit_id} has surrounding whitespace in its name")

        completions = raw_habit["completions"]
        if not isinstance(completions, list):
            raise ValueError(f"habit ID {habit_id} completions must be an array")
        clean_completions = [_validate_date(value) for value in completions]
        if len(set(clean_completions)) != len(clean_completions):
            raise ValueError(f"habit ID {habit_id} has duplicate completion dates")

        clean_habits.append(
            {
                "id": habit_id,
                "name": name,
                "completions": sorted(clean_completions),
            }
        )

    if seen_ids and next_id <= max(seen_ids):
        raise ValueError("next_id must be greater than every existing habit ID")

    clean_habits.sort(key=lambda habit: habit["id"])
    return {"version": SCHEMA_VERSION, "next_id": next_id, "habits": clean_habits}


def _copy_habit(habit: dict[str, Any]) -> dict[str, Any]:
    return {
        "id": habit["id"],
        "name": habit["name"],
        "completions": habit["completions"].copy(),
    }
