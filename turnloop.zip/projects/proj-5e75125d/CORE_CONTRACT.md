# Reading-list core contract

This document is the small domain contract for `reading_list.py`. The utility
is intentionally offline, single-user, and dependency-free.

## Concepts

- A **reading item** has a stable integer `id`, a non-blank `title`, a boolean
  `completed` state, and an ISO-8601 UTC `created_at` timestamp.
- The **reading list** is an ordered collection of items. File order is the
  insertion/display order.
- The **storage file** is a JSON object with one top-level `items` array. A
  missing file means an empty list for reads and is created by `add`.

## Commands and state transitions

| Command | Effect |
| --- | --- |
| `add TITLE` | Append one incomplete item with the next positive ID. |
| `list` | Show incomplete items in storage order. |
| `list --all` | Show every item in storage order. |
| `complete ID` | Change the matching item from incomplete to complete. |
| `remove ID` | Delete the matching item, whether complete or incomplete. |

Completion is idempotent: completing an already-complete item succeeds and
does not rewrite the file. IDs are never reused during normal operation: a new
ID is one greater than the greatest stored ID, including IDs of removed items
that are no longer available to the utility.

## Invariants

1. Every item ID is a unique positive integer; booleans are not valid IDs.
2. Every title is a non-empty string after trimming. Stored titles are trimmed
   before they are written.
3. `completed` is always a real boolean, and `created_at` is a non-empty
   ISO-8601 timestamp with an explicit UTC offset.
4. Commands either complete their whole state change or leave the prior file
   intact. Writes use a same-directory temporary file and atomic replacement.
5. Read-only commands never create or modify the storage file.
6. Invalid persisted data is rejected with a concise error and nonzero exit
   status; it is never silently repaired.
7. The program makes no network calls and uses only Python's standard library.

These invariants are deliberately small enough to preserve if a future
interface is added around the command-line script.
