# Offline Reading List

`reading_list.py` is a tiny dependency-free command-line reading list for
books, articles, and other titles. It runs entirely offline and uses only
Python's standard library.

## Storage

The storage path is the first argument and points to a local JSON file. `add`
creates the file when needed; a missing file is treated as an empty list for
read-only commands. Items stay in the file when completed until they are
explicitly removed. Writes use a temporary file and atomic replacement so a
partial write does not replace the existing list.

## Assumptions and invariants

- The utility is local and offline; it has no network, account, or third-party
  package requirements.
- The caller supplies a writable JSON path when a mutating command is used.
- Item IDs are positive integers and remain stable until that item is removed.
- Completion is reversible only by editing the JSON file; `complete` is
  intentionally idempotent and does not create a duplicate item.

The delivery surface is intentionally limited to this README and the
executable `reading_list.py` script. A later integrator can copy these two
files into the final project namespace without adding a build step.

## Commands

```text
python3 reading_list.py STORAGE add TITLE
python3 reading_list.py STORAGE list [--all]
python3 reading_list.py STORAGE complete ITEM_ID
python3 reading_list.py STORAGE remove ITEM_ID
```

`list` shows unfinished items by default; use `--all` to include completed
items. Invalid storage data, missing items, and unwritable paths produce a
helpful error and a nonzero exit status.

## Example

```console
$ python3 reading_list.py /tmp/reading-list.json add "The Left Hand of Darkness"
Added [1] The Left Hand of Darkness
$ python3 reading_list.py /tmp/reading-list.json list
[ ] 1: The Left Hand of Darkness
$ python3 reading_list.py /tmp/reading-list.json complete 1
Completed [1] The Left Hand of Darkness
$ python3 reading_list.py /tmp/reading-list.json list --all
[x] 1: The Left Hand of Darkness
```

## Local verification

From this directory, run the following offline smoke test. It keeps data in a
temporary directory and removes that directory when finished:

```sh
tmpdir="$(mktemp -d)"
trap 'rm -rf "$tmpdir"' EXIT
store="$tmpdir/reading-list.json"
python3 reading_list.py "$store" add "Smoke Test"
python3 reading_list.py "$store" list
python3 reading_list.py "$store" complete 1
python3 reading_list.py "$store" list
python3 reading_list.py "$store" list --all
python3 reading_list.py "$store" remove 1
python3 reading_list.py "$store" list --all
```
