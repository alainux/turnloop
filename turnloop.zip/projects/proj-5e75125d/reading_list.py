#!/usr/bin/env python3
"""A small, offline reading-list command-line utility.

CLI contract:
    reading_list.py STORAGE add TITLE
    reading_list.py STORAGE list [--all]
    reading_list.py STORAGE complete ITEM_ID
    reading_list.py STORAGE remove ITEM_ID

STORAGE is a JSON file.  ``add`` creates it when needed; all other commands
read the existing file (a missing file is treated as an empty list).  Items
are retained in the file until explicitly removed, even after completion.
Writes use a same-directory temporary file followed by an atomic replacement
so an interrupted write cannot leave a partially written storage file.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


class StorageError(Exception):
    """An expected storage or input error suitable for the CLI."""


def is_utc_timestamp(value: object) -> bool:
    if not isinstance(value, str) or not value.strip():
        return False
    try:
        parsed = datetime.fromisoformat(value)
    except ValueError:
        return False
    return (
        parsed.tzinfo is not None
        and parsed.utcoffset() is not None
        and parsed.utcoffset() == timezone.utc.utcoffset(parsed)
    )


def load_items(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    try:
        with path.open("r", encoding="utf-8") as handle:
            data = json.load(handle)
    except OSError as exc:
        raise StorageError(f"cannot read storage file '{path}': {exc}") from exc
    except json.JSONDecodeError as exc:
        raise StorageError(f"storage file '{path}' is not valid JSON") from exc

    if not isinstance(data, dict) or not isinstance(data.get("items"), list):
        raise StorageError(f"storage file '{path}' has an invalid format")
    seen_ids: set[int] = set()
    for item in data["items"]:
        if (
            not isinstance(item, dict)
            or not isinstance(item.get("id"), int)
            or isinstance(item.get("id"), bool)
            or item["id"] <= 0
            or item["id"] in seen_ids
            or not isinstance(item.get("title"), str)
            or not item["title"].strip()
            or item["title"] != item["title"].strip()
            or not isinstance(item.get("completed"), bool)
            or not is_utc_timestamp(item.get("created_at"))
        ):
            raise StorageError(f"storage file '{path}' contains an invalid item")
        seen_ids.add(item["id"])
    return data["items"]


def save_items(path: Path, items: list[dict[str, Any]]) -> None:
    parent = path.parent
    if not parent.exists():
        raise StorageError(f"storage directory does not exist: '{parent}'")
    try:
        fd, temporary_name = tempfile.mkstemp(
            prefix=f".{path.name}.", suffix=".tmp", dir=parent
        )
        temporary_path = Path(temporary_name)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump({"items": items}, handle, indent=2)
                handle.write("\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary_path, path)
        except Exception:
            temporary_path.unlink(missing_ok=True)
            raise
    except OSError as exc:
        raise StorageError(f"cannot write storage file '{path}': {exc}") from exc


def find_item(items: list[dict[str, Any]], item_id: int) -> dict[str, Any]:
    for item in items:
        if item["id"] == item_id:
            return item
    raise StorageError(f"no reading item with id {item_id}")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__.split("\n", 1)[0])
    parser.add_argument("storage", type=Path, help="path to the local JSON storage file")
    commands = parser.add_subparsers(dest="command", required=True)

    add = commands.add_parser("add", help="add a reading item")
    add.add_argument("title", help="title of the item")

    listing = commands.add_parser("list", help="list unfinished items")
    listing.add_argument("--all", action="store_true", help="include completed items")

    for name in ("complete", "remove"):
        command = commands.add_parser(name, help=f"{name} a reading item")
        command.add_argument("id", type=int, metavar="ITEM_ID")
    return parser


def run(args: argparse.Namespace) -> int:
    path = args.storage
    if args.command == "add":
        title = args.title.strip()
        if not title:
            raise StorageError("title must not be empty")
        items = load_items(path)
        next_id = max((item["id"] for item in items), default=0) + 1
        item = {
            "id": next_id,
            "title": title,
            "completed": False,
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
        items.append(item)
        save_items(path, items)
        print(f"Added [{next_id}] {title}")
        return 0

    items = load_items(path)
    if args.command == "list":
        visible = items if args.all else [item for item in items if not item["completed"]]
        if not visible:
            print("Reading list is empty.")
        else:
            for item in visible:
                marker = "x" if item["completed"] else " "
                print(f"[{marker}] {item['id']}: {item['title']}")
        return 0

    item = find_item(items, args.id)
    if args.command == "complete":
        if item["completed"]:
            print(f"Item {args.id} is already complete.")
        else:
            item["completed"] = True
            save_items(path, items)
            print(f"Completed [{args.id}] {item['title']}")
    else:
        items.remove(item)
        save_items(path, items)
        print(f"Removed [{args.id}] {item['title']}")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    try:
        return run(parser.parse_args(argv))
    except StorageError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
