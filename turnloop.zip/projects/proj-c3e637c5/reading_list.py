#!/usr/bin/env python3
"""A tiny, dependency-free, offline reading-list CLI."""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Any


DEFAULT_DATA_FILE = Path.home() / ".reading_list.json"
SCHEMA_VERSION = 1


class DataError(Exception):
    """Raised when the JSON data cannot be read or written safely."""


def load_items(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    try:
        with path.open(encoding="utf-8") as stream:
            document = json.load(stream)
    except (OSError, json.JSONDecodeError) as exc:
        raise DataError(f"could not read {path}: {exc}") from exc
    if (
        not isinstance(document, dict)
        or document.get("version") != SCHEMA_VERSION
        or not isinstance(document.get("items"), list)
    ):
        raise DataError(f"invalid reading-list data in {path}")
    items = document["items"]
    for item in items:
        if (
            not isinstance(item, dict)
            or not isinstance(item.get("id"), int)
            or not isinstance(item.get("title"), str)
            or not item["title"].strip()
            or not isinstance(item.get("completed"), bool)
        ):
            raise DataError(f"invalid item in {path}")
    return items


def save_items(path: Path, items: list[dict[str, Any]]) -> None:
    document = {"version": SCHEMA_VERSION, "items": items}
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_name(f".{path.name}.tmp")
        with temporary.open("w", encoding="utf-8") as stream:
            json.dump(document, stream, indent=2)
            stream.write("\n")
        os.replace(temporary, path)
    except OSError as exc:
        raise DataError(f"could not write {path}: {exc}") from exc


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="reading_list.py",
        description="Manage a small offline reading list.",
        epilog=(
            "JSON schema: {version: 1, items: [{id: integer, title: string, "
            "completed: boolean}]}"
        ),
    )
    parser.add_argument(
        "--data-file",
        metavar="PATH",
        type=Path,
        default=DEFAULT_DATA_FILE,
        help=f"JSON storage path (default: {DEFAULT_DATA_FILE})",
    )
    commands = parser.add_subparsers(dest="command", required=True)

    add = commands.add_parser("add", help="add a title")
    add.add_argument("title", help="title to add")

    commands.add_parser("list", help="list saved titles")

    complete = commands.add_parser("complete", help="mark a title complete")
    complete.add_argument("id", type=int, metavar="ID")
    commands.add_parser("help", help="show usage information")
    return parser


def run(args: argparse.Namespace) -> int:
    if args.command == "help":
        build_parser().print_help()
        return 0
    items = load_items(args.data_file)
    if args.command == "add":
        title = args.title.strip()
        if not title:
            raise ValueError("title must not be empty")
        next_id = max((item["id"] for item in items), default=0) + 1
        items.append({"id": next_id, "title": title, "completed": False})
        save_items(args.data_file, items)
        print(next_id)
    elif args.command == "list":
        for item in items:
            state = "complete" if item["completed"] else "to read"
            print(f'{item["id"]}: {item["title"]} [{state}]')
    elif args.command == "complete":
        for item in items:
            if item["id"] == args.id:
                if not item["completed"]:
                    item["completed"] = True
                    save_items(args.data_file, items)
                print(f'completed {args.id}: {item["title"]}')
                return 0
        raise ValueError(f"no item with id {args.id}")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    try:
        args = parser.parse_args(argv)
        return run(args)
    except (DataError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
