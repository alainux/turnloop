"""Habit data model and JSON-backed persistence.

The on-disk format is deliberately small and explicit::

    {
      "version": 1,
      "next_id": 2,
      "habits": [
        {
          "id": 1,
          "name": "Walk",
          "created_date": "2026-08-14",
          "completed_dates": ["2026-08-14"]
        }
      ]
    }

Missing files represent an empty collection. Existing files, however, are
validated strictly so that corrupt data is reported instead of silently lost.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
import json
import os
from pathlib import Path
import tempfile
from typing import Any, Mapping


SCHEMA_VERSION = 1


class StorageError(ValueError):
    """Raised when stored habit data cannot be read or validated."""


class HabitNotFoundError(LookupError):
    """Raised when an operation refers to an unknown habit ID."""

    def __init__(self, habit_id: int) -> None:
        self.habit_id = habit_id
        super().__init__(f"Habit with ID {habit_id} does not exist")


def _require_mapping(value: Any, location: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise StorageError(f"{location} must be a JSON object")
    return value


def _require_exact_keys(
    value: Mapping[str, Any], required: set[str], location: str
) -> None:
    missing = required - value.keys()
    extra = value.keys() - required
    if missing:
        raise StorageError(
            f"{location} is missing required field(s): {', '.join(sorted(missing))}"
        )
    if extra:
        raise StorageError(
            f"{location} contains unknown field(s): {', '.join(sorted(extra))}"
        )


def _require_integer(value: Any, location: str, *, minimum: int = 1) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise StorageError(f"{location} must be an integer")
    if value < minimum:
        raise StorageError(f"{location} must be at least {minimum}")
    return value


def validate_iso_date(value: Any, location: str = "date") -> str:
    """Return *value* after validating its exact ``YYYY-MM-DD`` form."""

    if not isinstance(value, str):
        raise StorageError(f"{location} must be a YYYY-MM-DD string")
    try:
        parsed = date.fromisoformat(value)
    except ValueError as exc:
        raise StorageError(f"{location} must be a valid YYYY-MM-DD date") from exc
    if parsed.isoformat() != value:
        raise StorageError(f"{location} must use YYYY-MM-DD format")
    return value


def _date_string(value: str | date | None, location: str) -> str:
    if value is None:
        return date.today().isoformat()
    if isinstance(value, date):
        return value.isoformat()
    return validate_iso_date(value, location)


@dataclass
class Habit:
    """One habit and its completion history."""

    id: int
    name: str
    created_date: str
    completed_dates: list[str] = field(default_factory=list)

    @classmethod
    def from_dict(cls, value: Any, *, index: int | None = None) -> "Habit":
        location = "habit" if index is None else f"habits[{index}]"
        item = _require_mapping(value, location)
        _require_exact_keys(
            item, {"id", "name", "created_date", "completed_dates"}, location
        )

        habit_id = _require_integer(item["id"], f"{location}.id")
        name = item["name"]
        if not isinstance(name, str) or not name.strip():
            raise StorageError(f"{location}.name must be a non-empty string")
        created_date = validate_iso_date(
            item["created_date"], f"{location}.created_date"
        )

        raw_completed_dates = item["completed_dates"]
        if not isinstance(raw_completed_dates, list):
            raise StorageError(f"{location}.completed_dates must be a list")
        completed_dates = [
            validate_iso_date(entry, f"{location}.completed_dates[{date_index}]")
            for date_index, entry in enumerate(raw_completed_dates)
        ]
        return cls(habit_id, name, created_date, completed_dates)

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-serializable representation of the habit."""

        return {
            "id": self.id,
            "name": self.name,
            "created_date": self.created_date,
            "completed_dates": list(self.completed_dates),
        }


@dataclass
class HabitData:
    """The complete, versioned habit collection stored in one JSON file."""

    version: int = SCHEMA_VERSION
    next_id: int = 1
    habits: list[Habit] = field(default_factory=list)

    @classmethod
    def from_dict(cls, value: Any) -> "HabitData":
        document = _require_mapping(value, "storage document")
        _require_exact_keys(document, {"version", "next_id", "habits"}, "storage document")

        version = _require_integer(document["version"], "storage document.version")
        if version != SCHEMA_VERSION:
            raise StorageError(
                f"Unsupported storage version {version}; expected {SCHEMA_VERSION}"
            )
        next_id = _require_integer(document["next_id"], "storage document.next_id")

        raw_habits = document["habits"]
        if not isinstance(raw_habits, list):
            raise StorageError("storage document.habits must be a list")
        habits = [
            Habit.from_dict(raw_habit, index=index)
            for index, raw_habit in enumerate(raw_habits)
        ]

        ids = [habit.id for habit in habits]
        if len(ids) != len(set(ids)):
            raise StorageError("storage document contains duplicate habit IDs")
        if ids and next_id <= max(ids):
            raise StorageError(
                "storage document.next_id must be greater than every habit ID"
            )
        return cls(version=version, next_id=next_id, habits=habits)

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-serializable representation of all stored data."""

        return {
            "version": self.version,
            "next_id": self.next_id,
            "habits": [habit.to_dict() for habit in self.habits],
        }


class HabitStorage:
    """Path-injected JSON storage for habits.

    The file path is the only configuration needed, which keeps command-line
    callers simple and lets tests use a path inside ``TemporaryDirectory``.
    """

    def __init__(self, path: str | os.PathLike[str]) -> None:
        self.path = Path(path)

    def load(self) -> HabitData:
        """Load and validate the collection, or return empty data if absent."""

        try:
            with self.path.open("r", encoding="utf-8") as handle:
                raw_data = json.load(handle)
        except FileNotFoundError:
            return HabitData()
        except json.JSONDecodeError as exc:
            raise StorageError(
                f"Could not parse habit storage {self.path}: "
                f"invalid JSON at line {exc.lineno}, column {exc.colno}"
            ) from exc
        except OSError as exc:
            raise StorageError(f"Could not read habit storage {self.path}: {exc}") from exc

        try:
            return HabitData.from_dict(raw_data)
        except StorageError as exc:
            raise StorageError(f"Invalid habit storage {self.path}: {exc}") from exc

    def save(self, data: HabitData) -> None:
        """Validate and atomically save *data* using a same-directory replace."""

        if not isinstance(data, HabitData):
            raise TypeError("data must be a HabitData instance")
        # Round-tripping through the public representation also validates
        # objects assembled or mutated directly by callers.
        validated = HabitData.from_dict(data.to_dict())

        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            descriptor, temporary_name = tempfile.mkstemp(
                dir=self.path.parent,
                prefix=f".{self.path.name}.",
                suffix=".tmp",
            )
        except OSError as exc:
            raise StorageError(f"Could not prepare habit storage {self.path}: {exc}") from exc

        temporary_path = Path(temporary_name)
        try:
            with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
                json.dump(validated.to_dict(), handle, indent=2)
                handle.write("\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary_path, self.path)
        except (OSError, TypeError, ValueError) as exc:
            try:
                temporary_path.unlink(missing_ok=True)
            except OSError:
                pass
            raise StorageError(f"Could not save habit storage {self.path}: {exc}") from exc

    def add(self, name: str, created_date: str | date | None = None) -> Habit:
        """Add a habit, persist it, and return its assigned stable ID."""

        if not isinstance(name, str) or not name.strip():
            raise ValueError("Habit name must be a non-empty string")
        normalized_name = name.strip()
        normalized_date = _date_string(created_date, "created_date")

        data = self.load()
        habit = Habit(
            id=data.next_id,
            name=normalized_name,
            created_date=normalized_date,
        )
        data.habits.append(habit)
        data.next_id += 1
        self.save(data)
        return habit

    def list_habits(self) -> list[Habit]:
        """Return all habits in insertion order."""

        return self.load().habits

    def complete(
        self, habit_id: int, completed_date: str | date | None = None
    ) -> Habit:
        """Record a completion date for a habit ID and persist the change.

        Recording an already-present date is idempotent.
        """

        if isinstance(habit_id, bool) or not isinstance(habit_id, int):
            raise TypeError("habit_id must be an integer")
        normalized_date = _date_string(completed_date, "completed_date")
        data = self.load()

        for habit in data.habits:
            if habit.id == habit_id:
                if normalized_date not in habit.completed_dates:
                    habit.completed_dates.append(normalized_date)
                    self.save(data)
                return habit
        raise HabitNotFoundError(habit_id)

    def clear(self) -> None:
        """Remove all habits and reset the next assigned ID."""

        self.save(HabitData())


# Small functional wrappers are convenient for callers that do not need to
# retain a HabitStorage instance.
def load(path: str | os.PathLike[str]) -> HabitData:
    """Load habit data from *path*."""

    return HabitStorage(path).load()


def save(path: str | os.PathLike[str], data: HabitData) -> None:
    """Atomically save habit data to *path*."""

    HabitStorage(path).save(data)


def add_habit(
    path: str | os.PathLike[str], name: str, created_date: str | date | None = None
) -> Habit:
    """Add and return a habit stored at *path*."""

    return HabitStorage(path).add(name, created_date)


def list_habits(path: str | os.PathLike[str]) -> list[Habit]:
    """List habits stored at *path*."""

    return HabitStorage(path).list_habits()


def complete_habit(
    path: str | os.PathLike[str],
    habit_id: int,
    completed_date: str | date | None = None,
) -> Habit:
    """Complete a habit stored at *path*."""

    return HabitStorage(path).complete(habit_id, completed_date)


def clear_habits(path: str | os.PathLike[str]) -> None:
    """Clear all habits stored at *path*."""

    HabitStorage(path).clear()
