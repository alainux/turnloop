# Terminal interface

Launch the assembled game with:

```sh
python -m cli
```

The UI renders the current scene and numbered choices. Enter a number to call
the engine's public `choose(choice_id)` API. `q`, `quit`, `exit`, and end-of-file
leave cleanly; malformed or out-of-range input prints a message and redraws
the same scene.

## Engine boundary

`cli.app.GameUI` expects the engine's documented `scene`, `available_choices`,
`is_ended`, `ending`, and `choose(choice_id)` API. A scene exposes `text` and
`choices`; choices expose `id` and `label` (the renderer also accepts `text`).
The engine owns transition validation and state mutation. The module entry point
prefers an assembler-provided `engine.create_game()` factory. If absent, it
uses the documented `Story.from_json` and `AdventureEngine` constructors with
`content/adventure.json`.

## Smoke test

```sh
python - <<'PY'
from io import StringIO
from cli import run

class Game:
    def __init__(self):
        self.scene = {"text": "At a fork.", "choices": [{"id": "bridge", "label": "Take the bridge"}]}
        self.is_ended = False
    def choose(self, index):
        assert index == "bridge"
        self.scene = {"text": "You arrive safely.", "choices": []}
        self.is_ended = True

out = StringIO()
run(Game(), StringIO("nonsense\n1\n"), out)
assert "Please enter" in out.getvalue()
assert "You arrive safely." in out.getvalue()
print("CLI smoke test passed")
PY
```
