# Game engine contract

`engine.runtime.AdventureEngine` is the runtime boundary for the adventure.
It has no terminal or input dependencies.

Story data is a JSON object with `start_scene` and a `scenes` object. Each
scene has string `text`, an optional string `ending`, and a `choices` list.
Each choice has stable string `id`, display `label`, and destination `next`.
Terminal scenes have an `ending` and no choices. Story loading rejects missing
or malformed fields and every destination must name a known scene.

The public API is `engine.Story.from_json(path)`,
`AdventureEngine(story, player={})`, `engine.scene`,
`engine.available_choices`, `engine.state`, `engine.is_ended`, and
`engine.choose(choice_id)`. `InvalidChoice` and `EndingReached` are raised
without mutating state. Player data is intentionally minimal and read-only at
the runtime boundary; interfaces may use `state.player` for display.

Run the focused checks with `python -m pytest engine/tests`.
