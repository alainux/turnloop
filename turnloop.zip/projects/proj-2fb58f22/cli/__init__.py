"""Terminal presentation for the adventure game."""

from .app import GameUI, main, run

__all__ = ["GameUI", "main", "run"]
