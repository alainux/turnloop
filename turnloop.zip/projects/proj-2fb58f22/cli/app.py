"""Terminal boundary for the choose-your-own-adventure game."""

from __future__ import annotations

import argparse
import sys
from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Protocol, TextIO


class AdventureEngine(Protocol):
    """Public engine contract consumed by the UI."""
    scene: Any
    available_choices: Sequence[Any]
    is_ended: bool

    def choose(self, choice_id: str) -> Any: ...


@dataclass(frozen=True)
class UIStrings:
    title: str = "THE LAST LANTERN"
    quit_hint: str = "Type q to quit."
    prompt: str = "Your choice"
    invalid: str = "Please enter one of the numbered choices (or q to quit)."
    goodbye: str = "\nAdventure ended. Thanks for playing!"


def _value(item: Any, *names: str, default: str = "") -> str:
    for name in names:
        value = item.get(name) if isinstance(item, dict) else getattr(item, name, None)
        if value is not None:
            return str(value)
    return default


def _choices(scene: Any) -> Sequence[Any]:
    choices = scene.get("choices", ()) if isinstance(scene, dict) else getattr(scene, "choices", ())
    return tuple(choices or ())


def _finished(engine: AdventureEngine) -> bool:
    value = getattr(engine, "is_ended", getattr(engine, "is_finished", False))
    return bool(value() if callable(value) else value)


class GameUI:
    """Render scenes and delegate every move to the engine."""

    def __init__(self, engine: AdventureEngine, *, input_stream: TextIO = sys.stdin,
                 output_stream: TextIO = sys.stdout, strings: UIStrings | None = None) -> None:
        self.engine = engine
        self.input = input_stream
        self.output = output_stream
        self.strings = strings or UIStrings()

    def render(self) -> None:
        scene = self.engine.scene
        print(f"\n{self.strings.title}\n{'=' * len(self.strings.title)}", file=self.output)
        print(_value(scene, "text", "description", default="(The scene is silent.)"), file=self.output)
        choices = _choices(scene)
        if _finished(self.engine) or not choices:
            ending = getattr(self.engine, "ending", None)
            if ending:
                print(f"\n{_value(ending, 'text', 'description', default=str(ending))}", file=self.output)
            return
        print(f"\n{self.strings.quit_hint}\n", file=self.output)
        for number, choice in enumerate(choices, 1):
            print(f"  {number}. {_value(choice, 'text', 'label', 'description', default=str(choice))}", file=self.output)

    def play(self) -> bool:
        """Run until an ending, EOF, or quit; return True for a clean quit."""
        while True:
            self.render()
            choices = tuple(getattr(self.engine, "available_choices", _choices(self.engine.scene)))
            if _finished(self.engine) or not choices:
                return False
            print(f"\n{self.strings.prompt} [1-{len(choices)}]: ", end="", file=self.output)
            self.output.flush()
            raw = self.input.readline()
            if raw == "":
                print(self.strings.goodbye, file=self.output)
                return True
            answer = raw.strip().lower()
            if answer in {"q", "quit", "exit"}:
                print(self.strings.goodbye, file=self.output)
                return True
            try:
                index = int(answer) - 1
            except ValueError:
                print(f"\n{self.strings.invalid}", file=self.output)
                continue
            if not 0 <= index < len(choices):
                print(f"\n{self.strings.invalid}", file=self.output)
                continue
            # Transition validation and state mutation belong to the engine.
            choice = choices[index]
            choice_id = _value(choice, "id", default=str(choice))
            self.engine.choose(choice_id)


def run(engine: AdventureEngine, input_stream: TextIO = sys.stdin, output_stream: TextIO = sys.stdout) -> int:
    """Play an already-created engine; useful for integration and smoke tests."""
    GameUI(engine, input_stream=input_stream, output_stream=output_stream).play()
    return 0


def _load_engine() -> AdventureEngine:
    """Build a session through the engine's public construction API."""
    try:
        from engine import create_game
    except ImportError:
        try:
            from engine import AdventureEngine, Story
        except ImportError as exc:  # pragma: no cover
            raise RuntimeError("The game engine is not installed; run the assembled game from the project root.") from exc
        story_path = Path(__file__).resolve().parents[1] / "content" / "adventure.json"
        return AdventureEngine(Story.from_json(story_path))
    return create_game()


def main(argv: Iterable[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Play The Last Lantern.")
    parser.parse_args(list(argv) if argv is not None else None)
    try:
        return run(_load_engine())
    except BrokenPipeError:
        return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
