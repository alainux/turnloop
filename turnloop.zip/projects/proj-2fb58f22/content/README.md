# Adventure content contract

`adventure.json` is the narrative source of truth for the CLI adventure. It contains story data only; input handling, state transitions, and terminal rendering belong to the engine and interface layers.

## Contract (schema version 1)

- `schemaVersion`: integer for future migrations.
- `adventureId`, `title`: stable adventure metadata.
- `startSceneId`: ID of the scene shown first.
- `scenes`: array of scene objects.
- Each scene has a stable `id`, display `text`, and `choices`.
- Each choice has a stable-in-content `id`, display `label`, and `destinationId`.
- A terminal scene has `choices: []` and an `ending` object. Its ending contains stable `id`, display `title`, normalized `outcome` (`win`, `loss`, or `neutral`), and display `text`.
- A non-terminal scene omits `ending` and must have at least one choice.

The engine should resolve `startSceneId`, display the current scene's `text`, offer each choice's `label`, and follow the selected `destinationId`. It should stop when the current scene has an `ending` and expose that ending to the renderer.

## Content invariants

1. Every scene ID is unique.
2. Every `startSceneId` and `choice.destinationId` refers to a scene ID.
3. Every terminal scene has ending metadata; every non-terminal scene has choices.
4. At least one ending is reachable from `startSceneId`.

The current adventure intentionally has multiple reachable outcomes: one win, two loss endings, and one neutral ending.
