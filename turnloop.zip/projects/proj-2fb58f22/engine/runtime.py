"""Core adventure state machine.

The runtime consumes a mapping (or JSON file) with this shape::

    {"start_scene": "start", "scenes": {
      "start": {"text": "...", "choices": [
        {"id": "go", "label": "Go", "next": "finish"}
      ]},
      "finish": {"text": "...", "ending": "escaped"}
    }}

Scene IDs and choice IDs are stable machine identifiers. ``ending`` is an
optional string; its presence makes a scene terminal. The engine never reads
input or writes output, so a CLI, tests, or another interface can drive it.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from types import MappingProxyType
from typing import Any, Mapping


class StoryValidationError(ValueError):
    """Raised when story data violates the runtime contract."""


class InvalidChoice(ValueError):
    """Raised when a choice is not available in the current scene."""


class EndingReached(RuntimeError):
    """Raised when code attempts to advance from a terminal scene."""


@dataclass(frozen=True)
class Choice:
    id: str
    label: str
    next_scene: str


@dataclass(frozen=True)
class Scene:
    id: str
    text: str
    choices: tuple[Choice, ...] = ()
    ending: str | None = None

    @property
    def is_terminal(self) -> bool:
        return self.ending is not None


@dataclass(frozen=True)
class Story:
    start_scene: str
    scenes: Mapping[str, Scene]

    @classmethod
    def from_mapping(cls, data: Mapping[str, Any]) -> "Story":
        if not isinstance(data, Mapping):
            raise StoryValidationError("story must be an object")
        start = data.get("start_scene")
        raw_scenes = data.get("scenes")
        if not isinstance(start, str) or not start:
            raise StoryValidationError("start_scene must be a non-empty string")
        if not isinstance(raw_scenes, Mapping) or not raw_scenes:
            raise StoryValidationError("scenes must be a non-empty object")

        scenes: dict[str, Scene] = {}
        for scene_id, raw in raw_scenes.items():
            if not isinstance(scene_id, str) or not scene_id:
                raise StoryValidationError("scene IDs must be non-empty strings")
            if not isinstance(raw, Mapping):
                raise StoryValidationError(f"scene {scene_id!r} must be an object")
            text = raw.get("text")
            if not isinstance(text, str):
                raise StoryValidationError(f"scene {scene_id!r} text must be a string")
            ending = raw.get("ending")
            if ending is not None and (not isinstance(ending, str) or not ending):
                raise StoryValidationError(f"scene {scene_id!r} ending must be a non-empty string")
            raw_choices = raw.get("choices", [])
            if not isinstance(raw_choices, list):
                raise StoryValidationError(f"scene {scene_id!r} choices must be a list")
            choices: list[Choice] = []
            seen: set[str] = set()
            for raw_choice in raw_choices:
                if not isinstance(raw_choice, Mapping):
                    raise StoryValidationError(f"scene {scene_id!r} has an invalid choice")
                choice_id, label, target = (raw_choice.get(key) for key in ("id", "label", "next"))
                if not all(isinstance(value, str) and value for value in (choice_id, label, target)):
                    raise StoryValidationError(f"scene {scene_id!r} choices need id, label, and next strings")
                if choice_id in seen:
                    raise StoryValidationError(f"scene {scene_id!r} repeats choice ID {choice_id!r}")
                seen.add(choice_id)
                choices.append(Choice(choice_id, label, target))
            scenes[scene_id] = Scene(scene_id, text, tuple(choices), ending)

        if start not in scenes:
            raise StoryValidationError(f"start_scene {start!r} is unknown")
        for scene in scenes.values():
            if scene.is_terminal and scene.choices:
                raise StoryValidationError(f"terminal scene {scene.id!r} cannot have choices")
            for choice in scene.choices:
                if choice.next_scene not in scenes:
                    raise StoryValidationError(
                        f"choice {choice.id!r} in scene {scene.id!r} targets unknown scene {choice.next_scene!r}"
                    )
        return cls(start, MappingProxyType(scenes))

    @classmethod
    def from_json(cls, path: str | Path) -> "Story":
        with Path(path).open(encoding="utf-8") as stream:
            data = json.load(stream)
        return cls.from_mapping(data)


@dataclass(frozen=True)
class GameState:
    current_scene: str
    player: Mapping[str, Any] = field(default_factory=dict)


class AdventureEngine:
    """Mutable game session backed by an immutable, validated :class:`Story`."""

    def __init__(self, story: Story | Mapping[str, Any], player: Mapping[str, Any] | None = None):
        self.story = story if isinstance(story, Story) else Story.from_mapping(story)
        self._state = GameState(self.story.start_scene, MappingProxyType(dict(player or {})))

    @property
    def state(self) -> GameState:
        return self._state

    @property
    def scene(self) -> Scene:
        return self.story.scenes[self._state.current_scene]

    @property
    def available_choices(self) -> tuple[Choice, ...]:
        return self.scene.choices

    @property
    def is_ended(self) -> bool:
        return self.scene.is_terminal

    @property
    def ending(self) -> str | None:
        return self.scene.ending

    def choose(self, choice_id: str) -> Scene:
        """Apply a current-scene choice and return the newly active scene.

        Validation happens before state mutation: failed calls leave both the
        current scene and player mapping untouched.
        """
        if self.is_ended:
            raise EndingReached(f"ending {self.ending!r} has already been reached")
        choice = next((item for item in self.available_choices if item.id == choice_id), None)
        if choice is None:
            raise InvalidChoice(f"choice {choice_id!r} is not available in scene {self.scene.id!r}")
        self._state = GameState(choice.next_scene, self._state.player)
        return self.scene
