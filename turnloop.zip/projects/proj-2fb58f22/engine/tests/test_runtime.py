import pytest

from engine import AdventureEngine, EndingReached, InvalidChoice, Story, StoryValidationError


STORY = {
    "start_scene": "cabin",
    "scenes": {
        "cabin": {
            "text": "A storm surrounds the cabin.",
            "choices": [
                {"id": "door", "label": "Open the door", "next": "shore"},
                {"id": "wait", "label": "Wait for dawn", "next": "safe"},
            ],
        },
        "shore": {"text": "The sea is calm.", "ending": "escaped"},
        "safe": {"text": "Morning arrives.", "ending": "safe"},
    },
}


def test_exposes_scene_choices_and_transitions_to_ending():
    game = AdventureEngine(STORY, player={"name": "Ada"})
    assert game.scene.id == "cabin"
    assert [choice.id for choice in game.available_choices] == ["door", "wait"]
    assert game.state.player["name"] == "Ada"

    scene = game.choose("door")
    assert scene.id == "shore"
    assert game.is_ended is True
    assert game.ending == "escaped"


def test_invalid_choice_does_not_corrupt_state():
    game = AdventureEngine(STORY)
    before = game.state
    with pytest.raises(InvalidChoice):
        game.choose("not-a-choice")
    assert game.state == before
    assert game.scene.id == "cabin"


def test_terminal_scene_cannot_advance():
    game = AdventureEngine(STORY)
    game.choose("wait")
    before = game.state
    with pytest.raises(EndingReached):
        game.choose("anything")
    assert game.state == before


@pytest.mark.parametrize(
    "bad_story",
    [
        {"start_scene": "missing", "scenes": {"start": {"text": "x"}}},
        {"start_scene": "start", "scenes": {"start": {"text": "x", "choices": [{"id": "go", "label": "Go", "next": "missing"}]}}},
        {"start_scene": "start", "scenes": {"start": {"text": "x", "ending": "done", "choices": [{"id": "go", "label": "Go", "next": "start"}]}}},
    ],
)
def test_story_validation_rejects_broken_contract(bad_story):
    with pytest.raises(StoryValidationError):
        Story.from_mapping(bad_story)
