# Notes Utility

A tiny **offline** command-line notes tool. It requires **no network access**
and **no third-party packages** — it uses only the Python standard library.

Notes are stored as small JSON files inside a local `.notes/` directory that
the script creates automatically in the current working directory.

## Requirements

- Python 3.7+ (standard library only)

## How to run

From this project's working directory:

```bash
python3 notes.py <command> [args]
```

Replace `python3` with `python` if that is how Python 3 is invoked on your
system.

## Commands

| Command            | Description                                                  |
| ------------------ | ------------------------------------------------------------ |
| `add "text"`       | Create a note from the given text. Prints the new note's id. |
| `list`             | List all notes (id, created time, and a short preview).      |
| `show <id>`        | Show the full contents of a note by its id.                  |
| `help`             | Show the built-in help.                                      |

## Examples

Create a note:

```bash
python3 notes.py add "hello world"
# -> prints an id like: 3f9a1c2b
```

List notes:

```bash
python3 notes.py list
# -> 3f9a1c2b  2026-08-14T12:00:00Z  hello world
```

Show a note by id:

```bash
python3 notes.py show 3f9a1c2b
# -> id:      3f9a1c2b
#    created: 2026-08-14T12:00:00Z
#    text:
#    hello world
```

## Storage

- Notes are saved under `.notes/<id>.json` in the directory where the script
  is run.
- Each note is a JSON object with `id`, `created` (UTC timestamp), and `text`.
- Everything runs fully offline; no data is sent anywhere.
