#!/usr/bin/env python3
"""Offline notes utility.

A tiny command-line notes tool that requires no network and no third-party
packages. It uses only the Python standard library and stores notes as small
JSON files inside a local ``.notes/`` directory in the current working area.

Commands:
    add "text"            Create a note from the given text and print its id.
    list                  List all notes (id, created time, preview).
    show <id>             Show the full contents of a note by id.
    help                  Show this help text.

Everything runs fully offline. No data leaves the machine.
"""

import argparse
import json
import os
import sys
import uuid
from datetime import datetime, timezone

NOTES_DIR = os.path.join(os.getcwd(), ".notes")


def _ensure_store():
    """Create the notes directory if it does not exist."""
    os.makedirs(NOTES_DIR, exist_ok=True)


def _note_path(note_id):
    return os.path.join(NOTES_DIR, "{}.json".format(note_id))


def _now_iso():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def cmd_add(text):
    _ensure_store()
    note_id = uuid.uuid4().hex[:8]
    note = {
        "id": note_id,
        "created": _now_iso(),
        "text": text,
    }
    with open(_note_path(note_id), "w", encoding="utf-8") as fh:
        json.dump(note, fh, indent=2, ensure_ascii=False)
    print(note_id)
    return 0


def cmd_list():
    _ensure_store()
    entries = []
    for name in sorted(os.listdir(NOTES_DIR)):
        if not name.endswith(".json"):
            continue
        with open(os.path.join(NOTES_DIR, name), encoding="utf-8") as fh:
            note = json.load(fh)
        entries.append(note)

    if not entries:
        print("No notes yet.")
        return 0

    for note in entries:
        preview = note.get("text", "").replace("\n", " ")
        if len(preview) > 50:
            preview = preview[:47] + "..."
        print("{}  {}  {}".format(note.get("id"), note.get("created"), preview))
    return 0


def cmd_show(note_id):
    path = _note_path(note_id)
    if not os.path.exists(path):
        print("note not found: {}".format(note_id), file=sys.stderr)
        return 1
    with open(path, encoding="utf-8") as fh:
        note = json.load(fh)
    print("id:      {}".format(note.get("id")))
    print("created: {}".format(note.get("created")))
    print("text:")
    print(note.get("text", ""))
    return 0


def build_parser():
    parser = argparse.ArgumentParser(
        prog="notes.py",
        description="Offline notes utility (standard library only).",
    )
    sub = parser.add_subparsers(dest="command")

    p_add = sub.add_parser("add", help="Add a note from text.")
    p_add.add_argument("text", help="Note text.")

    sub.add_parser("list", help="List all notes.")

    p_show = sub.add_parser("show", help="Show a note by id.")
    p_show.add_argument("id", help="Note id.")

    sub.add_parser("help", help="Show help.")
    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.command == "add":
        return cmd_add(args.text)
    if args.command == "list":
        return cmd_list()
    if args.command == "show":
        return cmd_show(args.id)
    # No/unknown command -> print help.
    parser.print_help()
    return 0


if __name__ == "__main__":
    sys.exit(main())
