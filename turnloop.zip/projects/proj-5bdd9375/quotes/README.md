# Quotes

An offline catalog of quotes stored locally as JSON.

## Data file

`quotes.json` holds the catalog as a JSON array of objects. Each entry has:

- `text`  — the quote text (string)
- `author` — the quote's author (string)
- `tags`   — list of topic tags (array of strings)

## List quotes by tag

Print every quote that has a given tag:

    python quotes/list_by_tag.py <tag>

## Run the tests

    python -m unittest quotes.test_list_by_tag
