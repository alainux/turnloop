#!/usr/bin/env python3
"""Focused smoke test for quotes/list_by_tag.py.

Invokes the command as a subprocess against quotes/quotes.json and verifies
that, given a known-existing tag, the output contains the text of every
matching quote and does NOT contain the text of a quote that does not carry
that tag.
"""

import os
import subprocess
import sys
import unittest

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_COMMAND = os.path.join(_SCRIPT_DIR, "list_by_tag.py")

# Tag chosen by inspecting quotes/quotes.json: the "humor" tag matches exactly
# two quotes and deliberately excludes the stoic quotes.
TAG = "humor"

# Texts that MUST appear (quotes carrying the "humor" tag).
MATCHING_TEXTS = [
    "I told my computer I needed a break, and it said 'no problem, I'll go to sleep.'",
    "Why do programmers prefer dark mode? Because light attracts bugs.",
]

# Text that MUST NOT appear (a quote that does not carry the "humor" tag).
NON_MATCHING_TEXT = (
    "The impediment to action advances action. What stands in the way becomes the way."
)


class ListByTagSmokeTest(unittest.TestCase):
    def test_humor_tag_filters_correctly(self):
        proc = subprocess.run(
            [sys.executable, _COMMAND, TAG],
            capture_output=True,
            text=True,
        )
        self.assertEqual(proc.returncode, 0, msg=proc.stderr)

        output = proc.stdout
        for text in MATCHING_TEXTS:
            self.assertIn(text, output)
        self.assertNotIn(NON_MATCHING_TEXT, output)


if __name__ == "__main__":
    unittest.main()
