#!/usr/bin/env python3
"""Offline command-line tool to list quotes filtered by tag.

Reads quotes/quotes.json (produced by the quotes-data step) and prints every
quote whose ``tags`` array contains the given tag (case-insensitive match).

Invocation:
    python quotes/list_by_tag.py <tag>
"""

import json
import os
import sys

# Locate quotes.json relative to this script so the tool works regardless of
# the current working directory the test invokes it from.
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_QUOTES_PATH = os.path.join(_SCRIPT_DIR, "quotes.json")

USAGE_HINT = "Usage: python list_by_tag.py <tag>"


def load_quotes(path):
    """Load the quote catalog from a JSON file.

    Raises FileNotFoundError if the file is missing, or json.JSONDecodeError /
    OSError if it cannot be read or parsed.
    """
    with open(path, "r", encoding="utf-8") as fh:
        return json.load(fh)


def list_by_tag(tag):
    """Print every quote whose tags contain ``tag`` (case-insensitive)."""
    try:
        quotes = load_quotes(_QUOTES_PATH)
    except FileNotFoundError:
        print(
            "Error: could not find quotes.json at '{}'.".format(_QUOTES_PATH),
            file=sys.stderr,
        )
        return 1
    except (json.JSONDecodeError, OSError) as exc:
        print(
            "Error: could not read quotes.json ({}).".format(exc),
            file=sys.stderr,
        )
        return 1

    needle = tag.lower()
    matches = [
        q
        for q in quotes
        if needle in [t.lower() for t in q.get("tags", [])]
    ]

    if not matches:
        print("No quotes found for tag: {}".format(tag))
        return 0

    blocks = []
    for q in matches:
        text = q.get("text", "")
        author = q.get("author", "")
        blocks.append("{}\n— {}".format(text, author))
    print("\n\n".join(blocks))
    return 0


def main(argv):
    if len(argv) < 2 or not argv[1].strip():
        print(USAGE_HINT)
        return 2
    return list_by_tag(argv[1])


if __name__ == "__main__":
    sys.exit(main(sys.argv))
