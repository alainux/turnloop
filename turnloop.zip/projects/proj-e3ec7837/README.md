# Choose Your Own Adventure — Narrative Layer

The narrative is data-driven and independent of the 3D scene and HUD. Import
`createStoryEngine` from `src/story-engine.js` and let the presentation layer
render the node returned by `getCurrentNode()`.

```js
import { createStoryEngine } from "./src/story-engine.js";

const story = createStoryEngine();
const node = story.getCurrentNode();
const choices = story.getAvailableChoices();

story.applyChoice(choices[0].id);
story.resetState();
```

## Data contract

`src/story-data.js` exports `STORY_DATA`, with an `initialNodeId` and a `nodes`
record. Each node supplies `id`, `title`, `text`, and `choices`; ending nodes
also set `isEnding: true`. A choice supplies `id`, `label`, and `target`, with
optional `requires` flag matches, `effects` flag updates, and `reset: true` for
restart choices. The engine filters unavailable choices, applies effects, and
owns the current node and flags. HUD and scene code should not mutate the data.
