#!/usr/bin/env python3
"""Offline reading-list utility.

A tiny, dependency-free command-line tool for keeping track of articles and
pages you want to read. Everything is stored in a single local JSON file so the
tool works completely offline with no network access and no third-party
packages (Python standard library only).

Commands:
    add      Save a new item (URL + title).
    list     Show all saved items, marking which are read.
    read     Mark an item as read (by its index, shown by `list`).
    remove   Delete an item (by its index, shown by `list`).

Data lives in the same directory as this script, in `reading_list.json`.
"""

import argparse
import json
import os
import sys

# The data file is stored next to this script so the whole tool is self-contained.
DATA_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "reading_list.json")


def load_items():
    """Load the reading list from disk.

    Returns a list of item dicts. An empty list is returned if the file does
    not exist yet or is not valid JSON.
    """
    if not os.path.exists(DATA_FILE):
        return []
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        if not isinstance(data, list):
            return []
        return data
    except (json.JSONDecodeError, OSError):
        return []


def save_items(items):
    """Persist the reading list to disk as pretty-printed JSON."""
    with open(DATA_FILE, "w", encoding="utf-8") as fh:
        json.dump(items, fh, indent=2, ensure_ascii=False)
        fh.write("\n")


def add_item(url, title):
    """Add a URL + title to the list and report the new item's index."""
    items = load_items()
    items.append({"url": url, "title": title, "read": False})
    save_items(items)
    print(f"Added #{len(items) - 1}: {title}\n  {url}")


def list_items():
    """Print every saved item with its 0-based index and read status."""
    items = load_items()
    if not items:
        print("Reading list is empty. Use `add` to save an item.")
        return
    print(f"Reading list ({len(items)} item(s)):")
    for i, item in enumerate(items):
        status = "read" if item.get("read") else "unread"
        print(f"  [{i}] ({status}) {item.get('title', '')}")
        print(f"      {item.get('url', '')}")


def mark_read(index):
    """Mark the item at the given index as read."""
    items = load_items()
    if not _valid_index(items, index):
        return
    items[index]["read"] = True
    save_items(items)
    print(f"Marked #{index} as read: {items[index].get('title', '')}")


def remove_item(index):
    """Remove the item at the given index and report what was removed."""
    items = load_items()
    if not _valid_index(items, index):
        return
    removed = items.pop(index)
    save_items(items)
    print(f"Removed #{index}: {removed.get('title', '')}")


def _valid_index(items, index):
    """Validate a user-supplied index; print an error and return False if bad."""
    if index < 0 or index >= len(items):
        print(f"Error: no item at index {index} (list has {len(items)} item(s)).")
        return False
    return True


def build_parser():
    """Construct the argparse CLI parser with all subcommands."""
    parser = argparse.ArgumentParser(
        description="A tiny offline reading-list utility (standard library only)."
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p_add = sub.add_parser("add", help="Add a URL + title to the list.")
    p_add.add_argument("url", help="The URL to save.")
    p_add.add_argument("title", help="A short title for the item.")

    sub.add_parser("list", help="List all saved items.")

    p_read = sub.add_parser("read", help="Mark an item as read by index.")
    p_read.add_argument("index", type=int, help="Index of the item (from `list`).")

    p_rm = sub.add_parser("remove", help="Remove an item by index.")
    p_rm.add_argument("index", type=int, help="Index of the item (from `list`).")

    return parser


def main(argv=None):
    """Entry point: parse args and dispatch to the right handler."""
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.command == "add":
        add_item(args.url, args.title)
    elif args.command == "list":
        list_items()
    elif args.command == "read":
        mark_read(args.index)
    elif args.command == "remove":
        remove_item(args.index)
    else:
        parser.print_help()
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
