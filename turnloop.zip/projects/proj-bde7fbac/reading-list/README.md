# Reading List

A tiny, **offline** reading-list utility. Save articles and pages you want to
read, see what you've saved, mark items as read, and remove them when you're
done.

- **Zero dependencies** — Python standard library only (`argparse`, `json`,
  `os`, `sys`). No `pip install` required.
- **Fully offline** — no network calls, no external services.
- **Durable** — every change is saved to a local JSON file (`reading_list.json`)
  in this directory, so your list survives across runs.

## Files

| File                | Purpose                                                     |
| ------------------- | ----------------------------------------------------------- |
| `reading_list.py`   | The runnable CLI tool (standard library only).              |
| `reading_list.json` | The data store (created automatically on first use).        |
| `README.md`         | This file.                                                  |

## Requirements

- Python 3 (tested with Python 3.12). No packages to install.

## Usage

Run the script with `python3` and a subcommand. Item indices shown by `list`
are 0-based.

```bash
# Save a URL + title
python3 reading_list.py add <url> "<title>"

# Show everything you've saved (with read status)
python3 reading_list.py list

# Mark an item as read (use the index from `list`)
python3 reading_list.py read <index>

# Delete an item
python3 reading_list.py remove <index>
```

### Examples

```bash
python3 reading_list.py add https://example.com/a "Example Article A"
python3 reading_list.py add https://example.com/b "Example Article B"
python3 reading_list.py list
python3 reading_list.py read 0
python3 reading_list.py list
python3 reading_list.py remove 1
```

## Verification (reproducible)

The commands below were run from the `reading-list/` directory with Python 3.12.
Run them yourself to confirm identical behavior. The data file
(`reading_list.json`) starts empty.

```text
$ python3 reading_list.py add https://example.com/a "Example Article A"
Added #0: Example Article A
  https://example.com/a

$ python3 reading_list.py add https://example.com/b "Example Article B"
Added #1: Example Article B
  https://example.com/b

$ python3 reading_list.py list
Reading list (2 item(s)):
  [0] (unread) Example Article A
      https://example.com/a
  [1] (unread) Example Article B
      https://example.com/b

$ python3 reading_list.py read 0
Marked #0 as read: Example Article A

$ python3 reading_list.py list
Reading list (2 item(s)):
  [0] (read) Example Article A
      https://example.com/a
  [1] (unread) Example Article B
      https://example.com/b

$ python3 reading_list.py remove 1
Removed #1: Example Article B

$ python3 reading_list.py list
Reading list (1 item(s)):
  [0] (read) Example Article A
      https://example.com/a
```

Edge-case handling was also verified: referencing an out-of-range index prints a
clear error (e.g. `Error: no item at index 9 (list has 1 item(s)).`) rather than
crashing, and the list is persisted to `reading_list.json` after every change.

## How it works

Each item is a small JSON object `{"url": ..., "title": ..., "read": false}`.
The whole list is loaded into memory, mutated, and written back to
`reading_list.json` on every operation. Because the file lives next to the
script, the tool is fully self-contained and portable.
