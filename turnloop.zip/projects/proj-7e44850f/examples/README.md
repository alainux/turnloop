# Reading-log sample data

The fixtures in this directory use the persistence shape expected by the
reading-log CLI:

```json
{
  "books": [],
  "entries": []
}
```

`empty-reading-log.json` is the valid empty starting state. Load
`sample-reading-log.json` to exercise book totals, status counts, completion,
partial progress, and nullable dates/ratings. Each entry references a book by
`book_id`; dates are ISO `YYYY-MM-DD` strings and IDs are deterministic.

The sample uses these statuses: `to_read`, `reading`, `finished`, and
`abandoned`.
