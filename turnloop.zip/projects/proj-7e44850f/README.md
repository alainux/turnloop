# Offline reading log

A small dependency-free Python 3.12 CLI backed by a versioned JSON file.

```sh
python -m reading_log --file reading-log.json init
python -m reading_log --file reading-log.json add "Kindred" --id kindred-1 \
  --author "Octavia E. Butler" --status in_progress \
  --total-pages 264 --pages-read 40
python -m reading_log --file reading-log.json list
python -m reading_log --file reading-log.json summary
```

The bundled `examples/sample-reading-log.json` can be listed directly; the
CLI imports its `{books, entries}` shape and writes the canonical repository
shape on the next update. Runtime dependencies are limited to Python's
standard library.
