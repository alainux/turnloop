"""Small, deterministic JSON repository for reading-log records.

The storage boundary deliberately does not define the domain model.  A record
is any mapping with string keys and JSON-compatible values, or an object with a
zero-argument ``to_dict()`` method returning such a mapping.  Loading returns
plain dictionaries so the domain package can decide how to construct its own
objects.

Files use this stable shape::

    {"version": 1, "entries": [{...}, {...}]}

Writes are UTF-8, indented, and atomic when the target already exists or its
parent directory exists.  Missing files read as an empty log.
"""

from __future__ import annotations

import json
import os
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any, Protocol, TypeAlias

CURRENT_SCHEMA_VERSION = 1
_ENTRIES_KEY = "entries"
_VERSION_KEY = "version"

JsonValue: TypeAlias = None | bool | int | float | str | list["JsonValue"] | dict[str, "JsonValue"]


class Record(Protocol):
    def to_dict(self) -> Mapping[str, Any]: ...


class JsonStorageError(Exception):
    """Base exception for persistence failures."""


class JsonStorageFormatError(JsonStorageError, ValueError):
    """Raised when a persistence file or record violates the storage contract."""


def _record_to_mapping(record: Mapping[str, Any] | Record, index: int) -> dict[str, Any]:
    if isinstance(record, Mapping):
        value = dict(record)
    else:
        converter = getattr(record, "to_dict", None)
        if not callable(converter):
            raise JsonStorageFormatError(
                f"record {index} must be a mapping or expose to_dict()"
            )
        try:
            converted = converter()
        except Exception as exc:  # preserve a useful storage boundary error
            raise JsonStorageFormatError(f"record {index} could not be serialized: {exc}") from exc
        if not isinstance(converted, Mapping):
            raise JsonStorageFormatError(f"record {index}.to_dict() must return a mapping")
        value = dict(converted)

    if any(not isinstance(key, str) for key in value):
        raise JsonStorageFormatError(f"record {index} must use string keys")
    try:
        json.dumps(value, ensure_ascii=False, allow_nan=False)
    except (TypeError, ValueError) as exc:
        raise JsonStorageFormatError(f"record {index} contains a non-JSON value: {exc}") from exc
    return value


def _document(records: Sequence[Mapping[str, Any] | Record]) -> dict[str, Any]:
    return {
        _VERSION_KEY: CURRENT_SCHEMA_VERSION,
        _ENTRIES_KEY: [_record_to_mapping(record, index) for index, record in enumerate(records)],
    }


def _validate_document(document: Any, path: Path) -> list[dict[str, Any]]:
    if not isinstance(document, Mapping):
        raise JsonStorageFormatError(f"{path} must contain a JSON object")
    if document.get(_VERSION_KEY) != CURRENT_SCHEMA_VERSION:
        raise JsonStorageFormatError(
            f"{path} has unsupported or missing version; expected {CURRENT_SCHEMA_VERSION}"
        )
    entries = document.get(_ENTRIES_KEY)
    if not isinstance(entries, list):
        raise JsonStorageFormatError(f"{path} field 'entries' must be a JSON array")
    return [_record_to_mapping(entry, index) for index, entry in enumerate(entries)]


def save_records(path: str | os.PathLike[str], records: Sequence[Mapping[str, Any] | Record]) -> None:
    """Persist *records* to *path* using the canonical JSON representation."""

    target = Path(path)
    try:
        payload = json.dumps(_document(records), ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    except TypeError as exc:
        raise JsonStorageFormatError(f"records must be a sequence: {exc}") from exc

    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_name(f".{target.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w", encoding="utf-8", newline="\n") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, target)
    except OSError as exc:
        try:
            temporary.unlink()
        except OSError:
            pass
        raise JsonStorageError(f"could not write {target}: {exc}") from exc


def load_records(path: str | os.PathLike[str]) -> list[dict[str, Any]]:
    """Load records from *path*, returning an empty list when it is absent."""

    target = Path(path)
    if not target.exists():
        return []
    try:
        with target.open("r", encoding="utf-8") as stream:
            document = json.load(stream)
    except (OSError, UnicodeError) as exc:
        raise JsonStorageError(f"could not read {target}: {exc}") from exc
    except json.JSONDecodeError as exc:
        raise JsonStorageFormatError(f"{target} is not valid JSON: {exc.msg}") from exc
    return _validate_document(document, target)


class ReadingLogRepository:
    """Convenience object binding the functional API to one JSON path."""

    def __init__(self, path: str | os.PathLike[str]):
        self.path = Path(path)

    def load(self) -> list[dict[str, Any]]:
        return load_records(self.path)

    def save(self, records: Sequence[Mapping[str, Any] | Record]) -> None:
        save_records(self.path, records)

