"""Building blocks for the offline reading log."""

