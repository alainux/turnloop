"""Domain types for the reading log.

The domain package deliberately contains no persistence, terminal, or other UI
concerns.  Its public values are immutable and can be converted to plain
JSON-compatible dictionaries with ``to_dict``.
"""

from .models import (
    Book,
    DomainValidationError,
    ReadingEntry,
    ReadingStatus,
)

__all__ = [
    "Book",
    "DomainValidationError",
    "ReadingEntry",
    "ReadingStatus",
]
