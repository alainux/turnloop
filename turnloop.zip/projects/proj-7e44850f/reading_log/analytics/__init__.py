"""Pure summary functions for reading-log records."""

from .summary import ReadingSummary, summarize, summarize_reading_log

__all__ = ["ReadingSummary", "summarize", "summarize_reading_log"]

