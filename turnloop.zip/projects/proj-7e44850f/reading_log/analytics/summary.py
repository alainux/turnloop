"""Deterministic, presentation-free analytics for reading-log records.

The public functions accept an iterable of records.  A record may be a
``Mapping`` (the shape normally loaded from JSON) or an object with matching
attributes.  The supported fields are:

* ``status``: a string such as ``planned``, ``in_progress``, ``completed`` or
  ``abandoned``;
* ``total_pages`` (or ``pages``): the positive page target; and
* ``pages_read`` (or ``current_page``): the number of pages read.

Missing page fields are simply excluded from page aggregates.  Records with
no usable status are counted as ``unknown``; malformed page values are
excluded from page aggregates and counted in ``invalid_entries``.  This makes
analytics safe for partially edited logs while keeping the result explicit.
No input is mutated and no I/O or formatting is performed here.
"""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from math import isfinite
from numbers import Real
from typing import Any


@dataclass(frozen=True, slots=True)
class ReadingSummary:
    """The stable output shape returned by :func:`summarize_reading_log`.

    ``completion_percent`` is based on pages for records where both a target
    and a reading position exist.  It is ``0.0`` for an empty log or when no
    record contains usable progress data.  Progress is clamped to [0, 100],
    while page totals remain the supplied non-negative values.
    """

    total_entries: int
    status_counts: dict[str, int]
    completed_count: int
    in_progress_count: int
    pages_total: int
    pages_read: int
    pages_remaining: int
    completion_rate: float
    completion_percent: float
    average_progress_percent: float
    entries_with_progress: int
    invalid_entries: int

    def as_dict(self) -> dict[str, Any]:
        """Return a JSON-friendly copy of the summary."""

        return {
            "total_entries": self.total_entries,
            "status_counts": dict(self.status_counts),
            "completed_count": self.completed_count,
            "in_progress_count": self.in_progress_count,
            "pages_total": self.pages_total,
            "pages_read": self.pages_read,
            "pages_remaining": self.pages_remaining,
            "completion_rate": self.completion_rate,
            "completion_percent": self.completion_percent,
            "average_progress_percent": self.average_progress_percent,
            "entries_with_progress": self.entries_with_progress,
            "invalid_entries": self.invalid_entries,
        }


def _value(record: Any, *names: str) -> Any:
    if isinstance(record, Mapping):
        for name in names:
            if name in record:
                return record[name]
        return None
    for name in names:
        try:
            return getattr(record, name)
        except AttributeError:
            continue
    return None


def _number(value: Any) -> float | None:
    if isinstance(value, bool) or not isinstance(value, Real):
        return None
    number = float(value)
    return number if isfinite(number) else None


def _integer(value: Any) -> int | None:
    number = _number(value)
    if number is None or number < 0 or not number.is_integer():
        return None
    return int(number)


def _status(record: Any) -> str:
    value = _value(record, "status")
    if value is None:
        return "unknown"
    text = str(value).strip().lower().replace("-", "_").replace(" ", "_")
    return text or "unknown"


def summarize_reading_log(records: Iterable[Any]) -> ReadingSummary:
    """Calculate deterministic totals and progress metrics for ``records``.

    The iterable is consumed once.  ``ValueError`` is raised when ``records``
    itself is not iterable; individual incomplete records are handled as
    described in the module documentation.  Status keys are alphabetically
    ordered, making output stable regardless of input ordering.
    """

    counts: dict[str, int] = {}
    total_entries = completed = in_progress = 0
    pages_total = pages_read = invalid_entries = entries_with_progress = 0
    progress_values: list[float] = []

    for record in records:
        total_entries += 1
        status = _status(record)
        counts[status] = counts.get(status, 0) + 1
        if status == "completed":
            completed += 1
        elif status in {"in_progress", "reading", "started"}:
            in_progress += 1

        target_raw = _value(record, "total_pages", "pages")
        read_raw = _value(record, "pages_read", "current_page")
        if target_raw is None and read_raw is None:
            continue
        target = _integer(target_raw)
        read = _integer(read_raw)
        if target is None or read is None or target <= 0 or read > target:
            invalid_entries += 1
            continue

        pages_total += target
        pages_read += read
        entries_with_progress += 1
        progress_values.append(min(100.0, (read / target) * 100.0))

    completion = (pages_read / pages_total * 100.0) if pages_total else 0.0
    completion_rate = (completed / total_entries * 100.0) if total_entries else 0.0
    average = sum(progress_values) / len(progress_values) if progress_values else 0.0
    return ReadingSummary(
        total_entries=total_entries,
        status_counts={key: counts[key] for key in sorted(counts)},
        completed_count=completed,
        in_progress_count=in_progress,
        pages_total=pages_total,
        pages_read=pages_read,
        pages_remaining=max(0, pages_total - pages_read),
        completion_rate=round(completion_rate, 2),
        completion_percent=round(completion, 2),
        average_progress_percent=round(average, 2),
        entries_with_progress=entries_with_progress,
        invalid_entries=invalid_entries,
    )


def summarize(records: Iterable[Any]) -> dict[str, Any]:
    """Convenience wrapper returning the summary as a JSON-friendly dict."""

    return summarize_reading_log(records).as_dict()
