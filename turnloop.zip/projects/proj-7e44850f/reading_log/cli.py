"""Command-line interface for the dependency-free reading log."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Sequence

from reading_log.analytics import summarize_reading_log
from reading_log.domain import Book, ReadingEntry, ReadingStatus
from reading_log.presentation import format_summary, render_entries
from reading_log.storage import JsonStorageFormatError, ReadingLogRepository


def _normalise_entry(raw: dict[str, Any], books: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """Adapt the human-friendly sample shape to the canonical entry shape."""
    value = dict(raw)
    value["entry_id"] = value.pop("entry_id", value.pop("id", ""))
    book_id = value.get("book_id", "")
    book = books.get(str(book_id), {})
    value.setdefault("title", book.get("title"))
    value.setdefault("author", book.get("author"))
    aliases = {"to_read": "planned", "reading": "in_progress", "finished": "completed"}
    value["status"] = aliases.get(str(value.get("status", "")), value.get("status"))
    return value


def load_log(path: str | Path) -> list[dict[str, Any]]:
    """Load canonical records, or import the bundled books/entries fixture shape."""
    repository = ReadingLogRepository(path)
    try:
        return repository.load()
    except JsonStorageFormatError:
        try:
            document = json.loads(Path(path).read_text(encoding="utf-8"))
        except (OSError, UnicodeError, json.JSONDecodeError) as exc:
            raise JsonStorageFormatError(f"could not load reading log {path}: {exc}") from exc
        if not isinstance(document, dict) or not isinstance(document.get("entries"), list):
            raise
        books = {
            str(book.get("id")): book
            for book in document.get("books", [])
            if isinstance(book, dict) and book.get("id") is not None
        }
        return [_normalise_entry(entry, books) for entry in document["entries"] if isinstance(entry, dict)]


def save_log(path: str | Path, records: Sequence[dict[str, Any]]) -> None:
    ReadingLogRepository(path).save(records)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Manage an offline reading log.")
    parser.add_argument("--file", default="reading-log.json", help="JSON log path (default: reading-log.json)")
    commands = parser.add_subparsers(dest="command", required=True)

    commands.add_parser("list", help="list reading entries")
    commands.add_parser("summary", help="show reading progress summary")
    add = commands.add_parser("add", help="add a reading entry")
    add.add_argument("title")
    add.add_argument("--id", dest="entry_id", required=True)
    add.add_argument("--book-id", default=None)
    add.add_argument("--author")
    add.add_argument("--status", default="planned", choices=[status.value for status in ReadingStatus])
    add.add_argument("--total-pages", type=int)
    add.add_argument("--pages-read", type=int, default=0)
    add.add_argument("--rating", type=int)
    add.add_argument("--notes")
    commands.add_parser("init", help="create an empty log if it does not exist")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    path = Path(args.file)
    try:
        records = load_log(path)
        if args.command == "init":
            if not path.exists():
                save_log(path, [])
            print(f"Reading log: {path}")
        elif args.command == "list":
            books = {
                str(record["book_id"]): record
                for record in records
                if record.get("book_id") and record.get("title")
            }
            print(render_entries(records, books))
        elif args.command == "summary":
            print(format_summary(summarize_reading_log(records)))
        elif args.command == "add":
            book_id = args.book_id or f"book-{args.entry_id}"
            Book(book_id, args.title, args.author)
            entry = ReadingEntry(args.entry_id, book_id, args.status, rating=args.rating, notes=args.notes)
            record = entry.to_dict()
            record.update({"title": args.title, "author": args.author})
            if args.total_pages is not None:
                if args.total_pages <= 0 or args.pages_read < 0 or args.pages_read > args.total_pages:
                    raise ValueError("pages must satisfy 0 <= pages_read <= total_pages and total_pages > 0")
                record.update(total_pages=args.total_pages, pages_read=args.pages_read)
            save_log(path, [*records, record])
            print(f"Added {args.title} ({args.entry_id})")
    except (ValueError, JsonStorageFormatError) as exc:
        print(f"reading-log: error: {exc}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
