from reading_log.cli import main

raise SystemExit(main())
