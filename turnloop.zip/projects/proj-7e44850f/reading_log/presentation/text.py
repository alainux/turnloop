"""Stable terminal text formatters for reading-log records and summaries."""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from typing import Any

from reading_log.analytics import ReadingSummary


def _value(value: Any, *names: str, default: Any = None) -> Any:
    """Read a field from either a mapping or an attribute-based value."""

    if isinstance(value, Mapping):
        for name in names:
            if name in value:
                return value[name]
        return default
    for name in names:
        try:
            return getattr(value, name)
        except AttributeError:
            pass
    return default


def _text(value: Any, default: str = "—") -> str:
    if value is None or not str(value).strip():
        return default
    return str(value).strip()


def _status(value: Any) -> str:
    return _text(value, "unknown").replace("_", " ").replace("-", " ").title()


def _date(value: Any) -> str:
    return _text(value)


def _book_details(book: Any) -> str:
    title = _text(_value(book, "title", default=None))
    author = _value(book, "author", default=None)
    return f"{title} — {author.strip()}" if isinstance(author, str) and author.strip() else title


def format_entry(entry: Any, book: Any | None = None) -> str:
    """Return a compact, multi-line description of one reading entry.

    ``entry`` may be a :class:`ReadingEntry`, a mapping, or another object
    exposing matching attributes.  ``book`` is optional and may provide title
    and author information.  Missing optional values are shown as an em dash.
    """

    title = _book_details(book) if book is not None else _text(_value(entry, "title"))
    entry_id = _text(_value(entry, "entry_id", "id"))
    rating = _value(entry, "rating")
    rating_text = f"{rating}/5" if rating is not None else "—"
    lines = [
        f"{title} [{_status(_value(entry, 'status'))}]",
        f"  ID: {entry_id}",
        f"  Started: {_date(_value(entry, 'started_on'))}    Finished: {_date(_value(entry, 'finished_on'))}",
        f"  Rating: {rating_text}",
    ]
    notes = _value(entry, "notes")
    if notes is not None and str(notes).strip():
        lines.append(f"  Notes: {str(notes).strip()}")
    return "\n".join(lines)


def render_entries(entries: Iterable[Any], books: Mapping[str, Any] | None = None) -> str:
    """Render entries in input order, returning a useful empty-state message."""

    rendered: list[str] = []
    for entry in entries:
        book = None
        book_id = _value(entry, "book_id")
        if books is not None and book_id is not None:
            book = books.get(str(book_id))
        rendered.append(format_entry(entry, book))
    return "\n\n".join(rendered) if rendered else "No reading entries."


def _summary_value(summary: ReadingSummary | Mapping[str, Any], name: str, default: Any = 0) -> Any:
    return _value(summary, name, default=default)


def format_summary(summary: ReadingSummary | Mapping[str, Any]) -> str:
    """Format an analytics result without recalculating or mutating it."""

    counts = _summary_value(summary, "status_counts", {}) or {}
    status_lines = [f"  {_status(status)}: {counts[status]}" for status in sorted(counts)]
    if not status_lines:
        status_lines = ["  None"]
    return "\n".join(
        [
            "Reading summary",
            f"Entries: {_summary_value(summary, 'total_entries')}",
            f"Completed: {_summary_value(summary, 'completed_count')}",
            f"In progress: {_summary_value(summary, 'in_progress_count')}",
            f"Pages: {_summary_value(summary, 'pages_read')} / {_summary_value(summary, 'pages_total')} (remaining: {_summary_value(summary, 'pages_remaining')})",
            f"Page completion: {_summary_value(summary, 'completion_percent'):.2f}%",
            f"Average progress: {_summary_value(summary, 'average_progress_percent'):.2f}%",
            "Statuses:",
            *status_lines,
        ]
    )


def render_summary(summary: ReadingSummary | Mapping[str, Any] | None) -> str:
    """Render a summary, including a stable empty-state for ``None``."""

    if summary is None:
        return "No reading summary available."
    return format_summary(summary)
