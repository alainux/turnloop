"""Human-readable, terminal-oriented presentation for reading-log data.

The functions in this package only transform values into strings.  They do
not load files, print to stdout, or parse command-line arguments.
"""

from .text import (
    format_entry,
    format_summary,
    render_entries,
    render_summary,
)

__all__ = ["format_entry", "format_summary", "render_entries", "render_summary"]
