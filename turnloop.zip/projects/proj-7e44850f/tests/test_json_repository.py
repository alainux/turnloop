import json

import pytest

from reading_log.storage import JsonStorageFormatError, ReadingLogRepository, load_records, save_records


def test_missing_file_is_an_empty_log(tmp_path):
    assert load_records(tmp_path / "reading-log.json") == []


def test_round_trip_is_utf8_and_deterministic(tmp_path):
    path = tmp_path / "nested" / "reading-log.json"
    records = [{"title": "Café au lait", "status": "finished", "rating": 5}, {"title": "Z"}]

    save_records(path, records)
    assert load_records(path) == records
    assert path.read_text(encoding="utf-8") == (
        '{\n  "entries": [\n    {\n      "rating": 5,\n      "status": "finished",\n      "title": "Café au lait"\n    },\n    {\n      "title": "Z"\n    }\n  ],\n  "version": 1\n}\n'
    )


def test_repository_preserves_data_across_instances(tmp_path):
    path = tmp_path / "log.json"
    first = ReadingLogRepository(path)
    first.save([{"id": "book-1", "title": "The Hobbit"}])
    assert ReadingLogRepository(path).load() == [{"id": "book-1", "title": "The Hobbit"}]


@pytest.mark.parametrize("contents", ["", "[]", '{"version": 1}', '{"version": 2, "entries": []}'])
def test_malformed_documents_raise_clear_errors(tmp_path, contents):
    path = tmp_path / "log.json"
    path.write_text(contents, encoding="utf-8")
    with pytest.raises(JsonStorageFormatError):
        load_records(path)


def test_record_must_be_json_compatible(tmp_path):
    with pytest.raises(JsonStorageFormatError, match="non-JSON"):
        save_records(tmp_path / "log.json", [{"when": object()}])


def test_to_dict_records_are_supported(tmp_path):
    class Entry:
        def to_dict(self):
            return {"title": "東京物語"}

    path = tmp_path / "log.json"
    save_records(path, [Entry()])
    assert load_records(path) == [{"title": "東京物語"}]

