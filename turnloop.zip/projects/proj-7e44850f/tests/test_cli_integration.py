import json

from reading_log.cli import main


def test_cli_add_summary_and_persistence(tmp_path, capsys):
    path = tmp_path / "reading-log.json"

    assert main(["--file", str(path), "init"]) == 0
    assert main([
        "--file", str(path), "add", "The Dispossessed", "--id", "entry-1",
        "--author", "Ursula K. Le Guin", "--status", "in_progress",
        "--total-pages", "300", "--pages-read", "120", "--notes", "Continue soon.",
    ]) == 0
    assert main(["--file", str(path), "summary"]) == 0
    output = capsys.readouterr().out
    assert "The Dispossessed" in output
    assert "Reading summary" in output
    assert "Pages: 120 / 300" in output

    saved = json.loads(path.read_text(encoding="utf-8"))
    assert saved["version"] == 1
    assert saved["entries"][0]["entry_id"] == "entry-1"
    assert main(["--file", str(path), "list"]) == 0
    assert "The Dispossessed — Ursula K. Le Guin [In Progress]" in capsys.readouterr().out


def test_cli_reads_bundled_sample_shape(tmp_path, capsys):
    source = tmp_path / "sample.json"
    source.write_text(
        json.dumps({"books": [{"id": "b1", "title": "A Book", "author": "An Author"}],
                    "entries": [{"id": "e1", "book_id": "b1", "status": "finished", "pages_read": 10}]}),
        encoding="utf-8",
    )
    assert main(["--file", str(source), "list"]) == 0
    assert "A Book — An Author [Completed]" in capsys.readouterr().out
