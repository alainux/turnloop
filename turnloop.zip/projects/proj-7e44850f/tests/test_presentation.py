from reading_log.analytics import summarize_reading_log
from reading_log.presentation import format_entry, format_summary, render_entries


def test_render_entries_is_readable_and_handles_book_lookup():
    text = render_entries(
        [{"id": "entry-1", "book_id": "book-1", "status": "in_progress", "notes": "Keep going."}],
        {"book-1": {"title": "A Book", "author": "An Author"}},
    )

    assert text == (
        "A Book — An Author [In Progress]\n"
        "  ID: entry-1\n"
        "  Started: —    Finished: —\n"
        "  Rating: —\n"
        "  Notes: Keep going."
    )


def test_render_entries_empty_and_summary_is_deterministic():
    assert render_entries([]) == "No reading entries."
    summary = summarize_reading_log([])
    assert format_summary(summary) == (
        "Reading summary\n"
        "Entries: 0\n"
        "Completed: 0\n"
        "In progress: 0\n"
        "Pages: 0 / 0 (remaining: 0)\n"
        "Page completion: 0.00%\n"
        "Average progress: 0.00%\n"
        "Statuses:\n"
        "  None"
    )


def test_format_entry_accepts_domain_objects():
    from reading_log.domain import Book, ReadingEntry

    text = format_entry(
        ReadingEntry("entry-1", "book-1", "completed", started_on="2025-01-01", rating=5),
        Book("book-1", "A Book"),
    )
    assert "A Book [Completed]" in text
    assert "Started: 2025-01-01" in text
