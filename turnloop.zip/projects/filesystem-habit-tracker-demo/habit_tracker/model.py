"""Data model for habits and their completion dates."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, datetime, timezone
from typing import Any
from uuid import UUID, uuid4


def _utc_now() -> str:
    """Return a JSON-friendly, timezone-aware creation timestamp."""

    return datetime.now(timezone.utc).isoformat()


def _new_id() -> str:
    """Generate an ID once; the value remains stable after serialization."""

    return str(uuid4())


def _normalise_date(value: date | datetime | str | None) -> str:
    """Convert a completion date to an ISO ``YYYY-MM-DD`` string."""

    if value is None:
        return date.today().isoformat()
    if isinstance(value, datetime):
        value = value.date()
    if isinstance(value, date):
        return value.isoformat()
    if isinstance(value, str):
        try:
            return date.fromisoformat(value).isoformat()
        except ValueError as exc:
            raise ValueError(f"invalid completion date: {value!r}") from exc
    raise TypeError("completion date must be a date, datetime, ISO string, or None")


def _normalise_id(value: str | UUID | None) -> str:
    if value is None:
        return _new_id()
    if isinstance(value, UUID):
        return str(value)
    if not isinstance(value, str) or not value.strip():
        raise ValueError("habit id must be a non-empty string")
    return value.strip()


@dataclass
class Habit:
    """A habit with a stable ID, creation metadata, and completed dates."""

    name: str
    id: str = field(default_factory=_new_id)
    created_at: str = field(default_factory=_utc_now)
    completion_dates: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        self.name = self.name.strip() if isinstance(self.name, str) else self.name
        if not isinstance(self.name, str) or not self.name:
            raise ValueError("habit name must be a non-empty string")
        self.id = _normalise_id(self.id)
        if not isinstance(self.created_at, str) or not self.created_at.strip():
            raise ValueError("created_at must be a non-empty ISO timestamp string")

        dates = {_normalise_date(completion) for completion in self.completion_dates}
        self.completion_dates = sorted(dates)

    @property
    def completed_dates(self) -> list[str]:
        """Compatibility/readability alias for ``completion_dates``."""

        return self.completion_dates

    @property
    def completions(self) -> list[str]:
        """Short alias useful to CLI callers."""

        return self.completion_dates

    def complete(self, on: date | datetime | str | None = None) -> bool:
        """Mark the habit complete for a date and return whether it was new."""

        completion_date = _normalise_date(on)
        if completion_date in self.completion_dates:
            return False
        self.completion_dates.append(completion_date)
        self.completion_dates.sort()
        return True

    def is_completed_on(self, on: date | datetime | str | None = None) -> bool:
        """Return whether the habit is complete for the given date."""

        return _normalise_date(on) in self.completion_dates

    def to_dict(self) -> dict[str, Any]:
        """Return the JSON-serializable representation of this habit."""

        return {
            "id": self.id,
            "name": self.name,
            "created_at": self.created_at,
            "completion_dates": list(self.completion_dates),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Habit":
        """Build a habit from saved JSON data.

        ``completed_dates`` and ``completions`` are accepted as older or more
        concise spellings, while newly saved data always uses
        ``completion_dates``.
        """

        if not isinstance(data, dict):
            raise ValueError("each habit must be a JSON object")
        try:
            name = data["name"]
        except KeyError as exc:
            raise ValueError("habit data is missing 'name'") from exc

        completions = data.get("completion_dates")
        if completions is None:
            completions = data.get("completed_dates", data.get("completions", []))
        if completions is None:
            completions = []
        if not isinstance(completions, list):
            raise ValueError("habit completion dates must be a JSON array")

        return cls(
            name=name,
            id=data.get("id"),
            created_at=data.get("created_at", _utc_now()),
            completion_dates=completions,
        )
