"""Command-line interface for the JSON-backed habit tracker."""

from __future__ import annotations

import argparse
import sys
from datetime import date
from pathlib import Path
from typing import Sequence

from .storage import HabitStore


DEFAULT_DATA_FILE = Path("habits.json")


def build_parser() -> argparse.ArgumentParser:
    """Build and return the habit tracker argument parser."""

    parser = argparse.ArgumentParser(
        prog="habit-tracker",
        description="Track recurring habits in a small JSON file.",
    )
    parser.set_defaults(data_file=DEFAULT_DATA_FILE)
    _add_data_file_argument(parser)

    commands = parser.add_subparsers(dest="command", required=True)

    add_parser = commands.add_parser("add", help="add a new habit")
    _add_data_file_argument(add_parser)
    add_parser.add_argument("name", help="name of the habit")
    add_parser.set_defaults(handler=_add_habit)

    list_parser = commands.add_parser("list", help="list saved habits")
    _add_data_file_argument(list_parser)
    list_parser.set_defaults(handler=_list_habits)

    complete_parser = commands.add_parser(
        "complete", help="mark a habit complete for a date"
    )
    _add_data_file_argument(complete_parser)
    complete_parser.add_argument("habit_id", help="ID of the habit to complete")
    complete_parser.add_argument(
        "--date",
        "-d",
        "--on",
        dest="completion_date",
        metavar="YYYY-MM-DD",
        help="date to mark complete (defaults to today)",
    )
    complete_parser.set_defaults(handler=_complete_habit)

    return parser


def _add_data_file_argument(parser: argparse.ArgumentParser) -> None:
    """Add the data-file option without overwriting a global value.

    Defining this on both the root parser and subparsers allows either
    ``--data-file PATH add ...`` or ``add --data-file PATH ...``.
    """

    parser.add_argument(
        "--data-file",
        "-f",
        type=Path,
        default=argparse.SUPPRESS,
        metavar="PATH",
        help="JSON file used for storage (default: habits.json)",
    )


def _add_habit(args: argparse.Namespace) -> int:
    store = HabitStore.load(args.data_file)
    habit = store.add(args.name)
    store.save()
    print(f'Added habit "{habit.name}" ({habit.id}).')
    return 0


def _list_habits(args: argparse.Namespace) -> int:
    store = HabitStore.load(args.data_file)
    habits = store.list()
    if not habits:
        print("No habits found.")
        return 0

    print(f"Habits ({len(habits)}):")
    for habit in habits:
        if habit.completion_dates:
            completions = ", ".join(habit.completion_dates)
            completion_text = f"completed: {completions}"
        else:
            completion_text = "not completed yet"
        print(f"- {habit.name} [{habit.id}] ({completion_text})")
    return 0


def _complete_habit(args: argparse.Namespace) -> int:
    completion_date = _parse_completion_date(args.completion_date)
    store = HabitStore.load(args.data_file)
    habit = store.get(args.habit_id)
    already_completed = habit.is_completed_on(completion_date)
    store.complete(habit.id, completion_date)
    store.save()

    if already_completed:
        print(f'"{habit.name}" was already complete for {completion_date}.')
    else:
        print(f'Completed "{habit.name}" for {completion_date}.')
    return 0


def _parse_completion_date(value: str | None) -> str:
    if value is None:
        return date.today().isoformat()
    try:
        return date.fromisoformat(value).isoformat()
    except ValueError as exc:
        raise ValueError(f"invalid date {value!r}; use YYYY-MM-DD") from exc


def main(argv: Sequence[str] | None = None) -> int:
    """Run the CLI and return a process exit status."""

    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return args.handler(args)
    except KeyError as exc:
        message = exc.args[0] if exc.args else str(exc)
        print(f"Error: {message}", file=sys.stderr)
        return 1
    except (OSError, TypeError, ValueError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":  # pragma: no cover - convenient direct execution
    raise SystemExit(main())
