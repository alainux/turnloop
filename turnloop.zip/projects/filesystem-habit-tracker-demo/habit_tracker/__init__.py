"""A small JSON-backed habit tracker core."""

from .model import Habit
from .storage import (
    HabitStorage,
    HabitStore,
    add_habit,
    complete_habit,
    load,
    load_habits,
    save,
    save_habits,
)

__all__ = [
    "Habit",
    "HabitStore",
    "HabitStorage",
    "add_habit",
    "complete_habit",
    "load",
    "load_habits",
    "save",
    "save_habits",
]
