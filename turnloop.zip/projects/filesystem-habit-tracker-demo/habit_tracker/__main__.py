"""Allow ``python -m habit_tracker`` to run the habit tracker CLI."""

from .cli import main


if __name__ == "__main__":
    raise SystemExit(main())
