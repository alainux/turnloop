"""JSON file persistence and operations for the habit tracker."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Iterable

from .model import Habit


class HabitStore:
    """An in-memory collection of habits backed by one JSON file."""

    def __init__(self, path: str | Path, habits: Iterable[Habit] | None = None) -> None:
        self.path = Path(path)
        self.habits: list[Habit] = []
        for habit in habits or ():
            self._add_loaded_habit(habit)

    @classmethod
    def load(cls, path: str | Path) -> "HabitStore":
        """Load a store, treating a missing or empty file as an empty store."""

        file_path = Path(path)
        if not file_path.exists() or file_path.stat().st_size == 0:
            return cls(file_path)

        raw = file_path.read_text(encoding="utf-8").strip()
        if not raw:
            return cls(file_path)

        try:
            payload = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise ValueError(f"invalid habit data in {file_path}: {exc.msg}") from exc

        if payload is None:
            return cls(file_path)
        if isinstance(payload, list):
            habit_data = payload
        elif isinstance(payload, dict):
            habit_data = payload.get("habits", [])
        else:
            raise ValueError("habit data must be a JSON object or array")

        if not isinstance(habit_data, list):
            raise ValueError("'habits' must be a JSON array")
        try:
            habits = [Habit.from_dict(item) for item in habit_data]
        except (TypeError, ValueError) as exc:
            raise ValueError(f"invalid habit data in {file_path}: {exc}") from exc
        return cls(file_path, habits)

    @classmethod
    def from_file(cls, path: str | Path) -> "HabitStore":
        """Alias for :meth:`load` for callers that prefer explicit naming."""

        return cls.load(path)

    def reload(self) -> "HabitStore":
        """Reload this store's path and update the current instance."""

        loaded = type(self).load(self.path)
        self.habits = loaded.habits
        return self

    def save(self, path: str | Path | None = None) -> Path:
        """Write habits as readable JSON and return the file path used."""

        if path is not None:
            self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(
            json.dumps(self.to_dict(), indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )
        return self.path

    def to_dict(self) -> dict[str, list[dict[str, object]]]:
        return {"habits": [habit.to_dict() for habit in self.habits]}

    def add(
        self,
        name: str,
        *,
        habit_id: str | None = None,
        created_at: str | None = None,
    ) -> Habit:
        """Create, retain, and return a habit with a stable ID."""

        habit_kwargs: dict[str, object] = {"name": name}
        if habit_id is not None:
            habit_kwargs["id"] = habit_id
        if created_at is not None:
            habit_kwargs["created_at"] = created_at
        habit = Habit(**habit_kwargs)
        self._add_loaded_habit(habit)
        return habit

    def list(self) -> list[Habit]:
        """Return habits in their stored order."""

        return list(self.habits)

    def list_habits(self) -> list[Habit]:
        """Explicitly named alias for :meth:`list`."""

        return self.list()

    def get(self, habit_id: str) -> Habit:
        """Return a habit by ID or raise ``KeyError`` when it is absent."""

        for habit in self.habits:
            if habit.id == habit_id:
                return habit
        raise KeyError(f"unknown habit id: {habit_id}")

    def complete(self, habit_id: str, on=None) -> Habit:
        """Mark a habit complete for a date and return the updated habit."""

        habit = self.get(habit_id)
        habit.complete(on)
        return habit

    def complete_habit(self, habit_id: str, on=None) -> Habit:
        """Explicitly named alias for :meth:`complete`."""

        return self.complete(habit_id, on)

    def _add_loaded_habit(self, habit: Habit) -> None:
        if not isinstance(habit, Habit):
            raise TypeError("habits must be Habit instances")
        if any(existing.id == habit.id for existing in self.habits):
            raise ValueError(f"duplicate habit id: {habit.id}")
        self.habits.append(habit)


HabitStorage = HabitStore


def load(path: str | Path) -> HabitStore:
    """Load a :class:`HabitStore` from a JSON file."""

    return HabitStore.load(path)


def save(path: str | Path, habits: Iterable[Habit]) -> Path:
    """Save an iterable of habits to a JSON file."""

    return HabitStore(path, habits).save()


def load_habits(path: str | Path) -> list[Habit]:
    """Load and return just the habits from a JSON file."""

    return HabitStore.load(path).list()


def save_habits(path: str | Path, habits: Iterable[Habit]) -> Path:
    """Save an iterable of habits to a JSON file."""

    return save(path, habits)


def add_habit(
    path: str | Path,
    name: str,
    *,
    habit_id: str | None = None,
    created_at: str | None = None,
) -> Habit:
    """Load, add, save, and return a habit in one CLI-friendly operation."""

    store = HabitStore.load(path)
    habit = store.add(name, habit_id=habit_id, created_at=created_at)
    store.save()
    return habit


def complete_habit(path: str | Path, habit_id: str, on=None) -> Habit:
    """Load, complete, save, and return a habit in one operation."""

    store = HabitStore.load(path)
    habit = store.complete(habit_id, on)
    store.save()
    return habit
