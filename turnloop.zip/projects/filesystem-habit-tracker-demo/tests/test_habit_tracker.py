"""Focused tests for the habit tracker core and command-line interface."""

import json
import re

from habit_tracker.cli import main
from habit_tracker.model import Habit
from habit_tracker.storage import HabitStore, load_habits, save_habits


def test_json_persistence_round_trip(tmp_path):
    data_file = tmp_path / "nested" / "habits.json"
    original = Habit("Read", id="read", created_at="2026-08-14T10:00:00+00:00")
    original.complete("2026-08-14")

    saved_path = save_habits(data_file, [original])

    assert saved_path == data_file
    payload = json.loads(data_file.read_text(encoding="utf-8"))
    assert payload == {"habits": [original.to_dict()]}

    loaded = HabitStore.load(data_file).get("read")
    assert loaded.to_dict() == original.to_dict()


def test_adding_and_listing_habits_preserves_order(tmp_path):
    data_file = tmp_path / "habits.json"
    store = HabitStore.load(data_file)

    first = store.add(" Drink water ")
    second = store.add("Stretch")
    store.save()

    assert [habit.name for habit in store.list()] == ["Drink water", "Stretch"]
    assert [habit.name for habit in load_habits(data_file)] == [
        "Drink water",
        "Stretch",
    ]
    assert first.id != second.id


def test_completion_is_idempotent_and_persists(tmp_path):
    data_file = tmp_path / "habits.json"
    store = HabitStore.load(data_file)
    habit = store.add("Walk")

    assert habit.complete("2026-08-14") is True
    assert habit.complete("2026-08-14") is False
    store.save()

    reloaded = HabitStore.load(data_file).get(habit.id)
    assert reloaded.is_completed_on("2026-08-14")
    assert reloaded.completion_dates == ["2026-08-14"]


def test_cli_command_flow_uses_the_same_isolated_data_file(tmp_path, capsys):
    data_file = tmp_path / "cli-habits.json"

    assert main(["--data-file", str(data_file), "add", "Meditate"]) == 0
    added_output = capsys.readouterr().out
    habit_id = re.search(r"\(([0-9a-f-]+)\)", added_output).group(1)

    assert main(["list", "--data-file", str(data_file)]) == 0
    listed_output = capsys.readouterr().out
    assert "Habits (1):" in listed_output
    assert f"- Meditate [{habit_id}] (not completed yet)" in listed_output

    assert (
        main(
            [
                "complete",
                "--data-file",
                str(data_file),
                habit_id,
                "--date",
                "2026-08-14",
            ]
        )
        == 0
    )
    completed_output = capsys.readouterr().out
    assert 'Completed "Meditate" for 2026-08-14.' in completed_output

    assert main(["--data-file", str(data_file), "list"]) == 0
    final_output = capsys.readouterr().out
    assert f"- Meditate [{habit_id}] (completed: 2026-08-14)" in final_output
