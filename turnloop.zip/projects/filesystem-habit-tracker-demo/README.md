# Filesystem Habit Tracker

A small command-line habit tracker that stores habits and completion dates in a
human-readable JSON file.

## Setup

From this directory, use Python 3.11 or newer. Install the test dependency if
needed:

```bash
python -m pip install pytest
```

The application has no runtime dependencies.

## Example

The default data file is `habits.json` in the current directory. Use
`--data-file` (or `-f`) to choose another file:

```bash
python -m habit_tracker --data-file habits.json add "Drink water"
python -m habit_tracker --data-file habits.json list
python -m habit_tracker --data-file habits.json complete HABIT_ID --date 2026-08-14
```

`add` prints the new habit ID. Pass that ID to `complete`; if `--date` is
omitted, the current date is used. The same data-file option may also follow a
command, for example `python -m habit_tracker list -f habits.json`.

Missing or empty data files are treated as an empty tracker. Parent directories
are created when the tracker saves, and saved JSON contains a top-level
`habits` array with stable IDs and ISO completion dates.

## Tests

Run the focused suite with:

```bash
python -m pytest -q tests
```
