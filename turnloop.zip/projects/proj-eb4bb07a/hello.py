#!/usr/bin/env python3
"""Print a friendly greeting."""


def main() -> None:
    print("Hello, world!")


if __name__ == "__main__":
    main()
