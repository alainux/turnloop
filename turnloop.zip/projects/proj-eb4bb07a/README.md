# Hello World CLI

A tiny Python command-line program that prints a greeting.

## Usage

```sh
python hello.py
```

Expected output:

```text
Hello, world!
```

## Tests

Run the smoke test with:

```sh
python -m unittest -v test_hello.py
```
