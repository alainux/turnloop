import subprocess
import sys
import unittest
from pathlib import Path


class HelloCliTest(unittest.TestCase):
    def test_cli_output(self) -> None:
        result = subprocess.run(
            [sys.executable, str(Path(__file__).with_name("hello.py"))],
            capture_output=True,
            text=True,
            check=True,
        )
        self.assertEqual(result.stdout, "Hello, world!\n")


if __name__ == "__main__":
    unittest.main()
