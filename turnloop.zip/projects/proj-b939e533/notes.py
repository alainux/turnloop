#!/usr/bin/env python3
"""A tiny offline command-line notes utility."""

from __future__ import annotations

import argparse
import json
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


DATA_FILE = Path(__file__).with_name("notes.json")


class NotesError(Exception):
    """An expected user-facing notes error."""


def load_notes() -> list[dict[str, Any]]:
    if not DATA_FILE.exists():
        return []
    try:
        with DATA_FILE.open("r", encoding="utf-8") as handle:
            data = json.load(handle)
    except (OSError, json.JSONDecodeError) as exc:
        raise NotesError(f"cannot read {DATA_FILE}: {exc}") from exc
    if not isinstance(data, list) or any(not isinstance(note, dict) for note in data):
        raise NotesError(f"invalid notes data in {DATA_FILE}")
    return data


def save_notes(notes: list[dict[str, Any]]) -> None:
    temporary = DATA_FILE.with_name(f".{DATA_FILE.name}.{uuid.uuid4().hex}.tmp")
    try:
        with temporary.open("w", encoding="utf-8") as handle:
            json.dump(notes, handle, indent=2, ensure_ascii=False)
            handle.write("\n")
        temporary.replace(DATA_FILE)
    except OSError as exc:
        try:
            temporary.unlink(missing_ok=True)
        except OSError:
            pass
        raise NotesError(f"cannot write {DATA_FILE}: {exc}") from exc


def add_note(args: argparse.Namespace) -> int:
    text = args.text
    if text is None:
        if sys.stdin.isatty():
            raise NotesError("provide note text with --text or pipe it on stdin")
        text = sys.stdin.read().strip()
    text = text.strip()
    if not text:
        raise NotesError("note text cannot be empty")

    notes = load_notes()
    note = {
        "id": uuid.uuid4().hex[:8],
        "title": args.title,
        "text": text,
        "created": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }
    notes.append(note)
    save_notes(notes)
    print(f"Created note {note['id']}: {note['title']}")
    return 0


def list_notes(_: argparse.Namespace) -> int:
    notes = load_notes()
    if not notes:
        print("No notes yet.")
        return 0
    for note in notes:
        print(f"{note.get('id', '?')}  {note.get('title', '(untitled)')}")
    return 0


def read_note(args: argparse.Namespace) -> int:
    notes = load_notes()
    matches = [note for note in notes if note.get("id") == args.note_id]
    if not matches:
        raise NotesError(f"note not found: {args.note_id}")
    note = matches[0]
    print(note.get("title", "(untitled)"))
    print(f"[{note.get('id', '?')}] {note.get('created', '')}")
    print()
    print(note.get("text", ""))
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Create, list, and read offline notes.",
        epilog=f"Notes are stored locally in {DATA_FILE} (no network access).",
    )
    commands = parser.add_subparsers(dest="command", required=True)

    add = commands.add_parser("add", help="create a note")
    add.add_argument("title", help="short title for the note")
    add.add_argument("-t", "--text", help="note body; omit to read it from stdin")
    add.set_defaults(handler=add_note)

    listing = commands.add_parser("list", help="list saved notes")
    listing.set_defaults(handler=list_notes)

    read = commands.add_parser("read", help="read one note by its ID")
    read.add_argument("note_id", help="ID printed by the add or list command")
    read.set_defaults(handler=read_note)
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return args.handler(args)
    except NotesError as exc:
        parser.error(str(exc))
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
