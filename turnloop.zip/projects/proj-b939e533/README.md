# Offline Notes

A tiny command-line notes utility. Add short notes, list saved notes, and
read an individual note later. Notes stay on the local machine and survive
separate invocations.

## Requirements

- Python 3
- No installation or third-party packages
- No network connection

## Usage

Run the one script from the project directory:

```sh
python3 notes.py --help
python3 notes.py add "Shopping" --text "Buy coffee"
python3 notes.py list
python3 notes.py read NOTE_ID
```

Commands:

| Command | Arguments | Purpose |
| --- | --- | --- |
| `add` | `TITLE` and optional `-t TEXT` / `--text TEXT` | Save a note. If `--text` is omitted, the body is read from standard input. |
| `list` | none | Show saved notes and their IDs. |
| `read` | `NOTE_ID` | Print the note with the given ID. IDs are printed by `add` and `list`. |

The script also accepts the standard `--help` option, including on each
command (for example, `python3 notes.py add --help`).

## Persistence

The utility stores notes in `notes.json` beside `notes.py`. The file is
created on the first write and is ordinary, human-readable JSON: a list of
objects with `id`, `title`, `text`, and UTC `created` fields. IDs are short
unique strings, not line numbers. Keep or back up this file to preserve your
notes; deleting it starts with an empty store.

## Smoke test

From a clean temporary directory containing `notes.py`, run:

```sh
python3 notes.py add "Smoke test" --text "offline check"
python3 notes.py list
python3 notes.py read NOTE_ID
```

Replace `NOTE_ID` with the ID printed by the first or second command. The
commands should succeed across separate processes, and the final command
should print `offline check`. The only data file created should be the local
`notes.json` store; no network access is required.
