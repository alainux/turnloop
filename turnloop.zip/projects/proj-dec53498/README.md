# Offline Reading List

A tiny, local command-line reading list. It uses only the Python standard library and does not contact a network service.

## Prerequisites

- Python 3.9 or newer
- A shell with the working directory set to the project root

There are no third-party packages to install.

## Run it

The script is `reading_list.py`:

```sh
python3 reading_list.py <command> [arguments]
```

The supported commands are:

| Command | Purpose |
| --- | --- |
| `add <title>` | Add a new reading-list item and print its numeric ID. |
| `list` | Print all items and their completion status. An empty list is valid. |
| `complete <id>` | Mark the item with the given numeric ID as complete. |

Examples:

```sh
python3 reading_list.py add "The Left Hand of Darkness"
python3 reading_list.py list
python3 reading_list.py complete 1
python3 reading_list.py list
```

Use the ID printed by `add` (or shown by `list`) with `complete`.

## Persistence

Items are stored locally in `reading_list.json` in the project directory. The file is created on the first write; a missing file is treated as an empty list. Running the script again reads the same file, so items remain available across invocations.

The data file is ordinary JSON and can be backed up or removed with normal file-management tools. Removing it starts a new empty reading list. No data is uploaded or shared.

## Smoke test

Run the following from the project root. It uses a temporary directory so the test does not change an existing reading list:

```sh
tmpdir="$(mktemp -d)"
trap 'rm -rf "$tmpdir"' EXIT
cp reading_list.py "$tmpdir/"
cd "$tmpdir"

python3 reading_list.py list
python3 reading_list.py add "Smoke-test book"
python3 reading_list.py list
python3 reading_list.py complete 1
python3 reading_list.py list
```

The final listing should show the added item as complete. The temporary directory and its JSON data are removed when the shell exits.
