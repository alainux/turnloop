#!/usr/bin/env python3
"""Small, offline reading-list command-line utility."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any


DEFAULT_STORE = Path(__file__).with_name("reading_list.json")


def load_items(path: Path) -> list[dict[str, Any]]:
    """Load a list from JSON, treating a missing or empty file as empty."""
    if not path.exists() or path.stat().st_size == 0:
        return []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(f"cannot read store {path}: {exc}") from exc
    if not isinstance(data, list) or any(not isinstance(item, dict) for item in data):
        raise ValueError(f"store {path} must contain a JSON array of items")
    return data


def save_items(path: Path, items: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp")
    try:
        temporary.write_text(
            json.dumps(items, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )
        temporary.replace(path)
    except OSError as exc:
        raise ValueError(f"cannot write store {path}: {exc}") from exc


def add_item(path: Path, title: str) -> int:
    title = title.strip()
    if not title:
        raise ValueError("title must not be empty")
    items = load_items(path)
    item_id = max((int(item.get("id", 0)) for item in items), default=0) + 1
    items.append({"id": item_id, "title": title, "completed": False})
    save_items(path, items)
    return item_id


def complete_item(path: Path, item_id: int) -> None:
    items = load_items(path)
    for item in items:
        if item.get("id") == item_id:
            item["completed"] = True
            save_items(path, items)
            return
    raise ValueError(f"no reading-list item with id {item_id}")


def print_items(items: list[dict[str, Any]]) -> None:
    if not items:
        print("Reading list is empty.")
        return
    for item in items:
        marker = "x" if item.get("completed", False) else " "
        print(f"{item.get('id')}. [{marker}] {item.get('title', '')}")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Manage a small offline reading list.")
    parser.add_argument(
        "--store",
        type=Path,
        default=DEFAULT_STORE,
        help=f"JSON store path (default: {DEFAULT_STORE})",
    )
    commands = parser.add_subparsers(dest="command", required=True)

    add = commands.add_parser("add", help="add a reading-list item")
    add.add_argument("title", help="item title")
    commands.add_parser("list", help="list reading-list items")

    complete = commands.add_parser("complete", help="mark an item complete")
    complete.add_argument("id", type=int, help="numeric item id")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        if args.command == "add":
            print(f"Added item {add_item(args.store, args.title)}.")
        elif args.command == "list":
            print_items(load_items(args.store))
        else:
            complete_item(args.store, args.id)
            print(f"Completed item {args.id}.")
    except ValueError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
