#!/usr/bin/env python3
"""Tiny offline reading-list utility backed by a local JSON file."""

import argparse
import json
import sys
from pathlib import Path

STORE_PATH = Path(__file__).with_name("reading_list.json")


def load_items():
    """Load items from the JSON store, returning an empty list if absent."""
    if not STORE_PATH.exists():
        return []
    try:
        with STORE_PATH.open(encoding="utf-8") as fh:
            return json.load(fh)
    except (json.JSONDecodeError, OSError):
        return []


def save_items(items):
    """Persist items to the JSON store."""
    with STORE_PATH.open("w", encoding="utf-8") as fh:
        json.dump(items, fh, indent=2)
        fh.write("\n")


def next_id(items):
    """Return the next unused item id."""
    return max((item["id"] for item in items), default=0) + 1


def cmd_add(title):
    """Add a book/article to the list."""
    items = load_items()
    items.append({"id": next_id(items), "title": title, "done": False})
    save_items(items)
    print(f"Added: {title}")


def cmd_list():
    """Show all items with their status."""
    items = load_items()
    if not items:
        print("Your reading list is empty.")
        return
    for item in items:
        status = "[x]" if item["done"] else "[ ]"
        print(f"{item['id']:>3} {status} {item['title']}")


def cmd_done(item_id):
    """Mark an item as finished."""
    items = load_items()
    for item in items:
        if item["id"] == item_id:
            item["done"] = True
            save_items(items)
            print(f"Marked done: {item['title']}")
            return
    print(f"No item with id {item_id}.", file=sys.stderr)
    sys.exit(1)


def main(argv=None):
    """Parse arguments and dispatch to the matching subcommand."""
    parser = argparse.ArgumentParser(description="Offline reading-list utility")
    subparsers = parser.add_subparsers(dest="command", required=True)

    subparsers.add_parser("list", help="show all items with status")

    parser_add = subparsers.add_parser("add", help="add a book/article")
    parser_add.add_argument("title", help="title of the book/article")

    parser_done = subparsers.add_parser("done", help="mark an item as finished")
    parser_done.add_argument("id", type=int, help="item id to mark as done")

    args = parser.parse_args(argv)
    if args.command == "add":
        cmd_add(args.title)
    elif args.command == "list":
        cmd_list()
    elif args.command == "done":
        cmd_done(args.id)


if __name__ == "__main__":
    main()
