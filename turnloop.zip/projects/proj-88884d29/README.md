# Reading List

A tiny offline reading-list utility written in Python. It lets you keep track
of books and articles you want to read — add them, list them with their status,
and mark them as done when you finish. Items persist to a local JSON file next
to the script, so nothing is lost between runs.

## Usage

```
python3 reading_list.py add <title>
python3 reading_list.py list
python3 reading_list.py done <id>
```

Examples:

```
$ python3 reading_list.py add The Odyssey
Added: The Odyssey

$ python3 reading_list.py add Atlas Shrugged
Added: Atlas Shrugged

$ python3 reading_list.py list
  1 [ ] The Odyssey
  2 [ ] Atlas Shrugged

$ python3 reading_list.py done 1
Marked done: The Odyssey

$ python3 reading_list.py list
  1 [x] The Odyssey
  2 [ ] Atlas Shrugged
```

## Requirements

- Python 3 (standard library only — no third-party packages)
- Runs fully offline

## Project structure

```
reading_list.py      the utility script
reading_list.json    data store (created automatically on first use)
```