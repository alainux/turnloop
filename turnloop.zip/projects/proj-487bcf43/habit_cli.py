#!/usr/bin/env python3
"""Command-line interface for the small JSON-backed habit tracker."""

from __future__ import annotations

import argparse
import os
from pathlib import Path
import sys
from datetime import date

from habit_tracker import (
    HabitError,
    HabitStorageError,
    HabitStore,
)


DEFAULT_PATH = Path.home() / ".habit_tracker.json"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="habit",
        description="Track habits and their completion dates.",
    )
    parser.add_argument(
        "--file",
        default=None,
        metavar="PATH",
        help="JSON storage file (default: HABIT_TRACKER_FILE or ~/.habit_tracker.json)",
    )
    commands = parser.add_subparsers(dest="command", required=True)

    add = commands.add_parser("add", help="add a habit")
    add.add_argument("name", help="habit name")
    add.add_argument("--id", help="use a specific habit ID")

    commands.add_parser("list", help="list habits and completion dates")

    complete = commands.add_parser("complete", help="mark a habit complete")
    complete.add_argument("id", help="habit ID")
    complete.add_argument(
        "--date", default=date.today().isoformat(), metavar="YYYY-MM-DD",
        help="completion date (default: today)",
    )

    clear = commands.add_parser("clear", help="clear completion dates")
    clear.add_argument("id", nargs="?", help="habit ID (default: all habits)")
    clear.add_argument(
        "--date", metavar="YYYY-MM-DD",
        help="clear only this date (default: all completion dates)",
    )
    return parser


def storage_path(argument: str | None) -> Path:
    value = argument or os.environ.get("HABIT_TRACKER_FILE")
    return Path(value).expanduser() if value else DEFAULT_PATH


def print_habits(store: HabitStore) -> None:
    habits = store.list_habits()
    if not habits:
        print("No habits tracked.")
        return
    for habit in habits:
        completions = ", ".join(sorted(habit.completions)) or "never"
        print(f"{habit.id}: {habit.name} (completed: {completions})")


def run(args: argparse.Namespace) -> int:
    path = storage_path(args.file)
    store = HabitStore.load(path)

    if args.command == "add":
        habit = store.add_habit(args.name, args.id)
        store.save()
        print(f"Added habit {habit.id}: {habit.name}")
    elif args.command == "list":
        print_habits(store)
    elif args.command == "complete":
        habit = store.complete_habit(args.id, args.date)
        store.save()
        print(f"Completed {habit.id}: {habit.name} on {args.date}")
    elif args.command == "clear":
        store.clear_completion_data(args.id, args.date)
        store.save()
        target = f"habit {args.id}" if args.id else "all habits"
        suffix = f" for {args.date}" if args.date else ""
        print(f"Cleared completions for {target}{suffix}.")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return run(args)
    except (HabitError, HabitStorageError, OSError) as exc:
        print(f"habit: error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
