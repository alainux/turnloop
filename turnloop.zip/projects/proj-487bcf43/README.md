# Habit Tracker CLI

A small habit tracker using only the Python standard library. Habits and their completion dates are stored in a JSON file.

## Setup

Python 3.10 or newer is recommended. There are no third-party dependencies.

The CLI can be run directly from this directory:

```sh
python3 habit_cli.py --help
```

## Usage

Choose a storage file with `--file`, or set `HABIT_TRACKER_FILE`. If neither is supplied, the default is `~/.habit_tracker.json`.

Add a habit:

```sh
python3 habit_cli.py --file habits.json add "Drink water"
```

List habits and their completion dates:

```sh
python3 habit_cli.py --file habits.json list
```

Mark a habit complete. The ID is shown by `list`; without `--date`, today's local date is used:

```sh
python3 habit_cli.py --file habits.json complete 1 --date 2026-08-14
```

Clear one completion date, all completion dates for one habit, or all habits' completion data:

```sh
python3 habit_cli.py --file habits.json clear 1 --date 2026-08-14
python3 habit_cli.py --file habits.json clear 1
python3 habit_cli.py --file habits.json clear
```

## Storage and validation

The storage file is JSON with a top-level `habits` list. Each habit contains a stable string `id`, a trimmed non-empty `name`, and a list of completion dates. The file is created, including its parent directories, when a mutating command saves data. Loading a missing file starts with an empty store.

Completion dates must be real calendar dates in strict `YYYY-MM-DD` form, such as `2026-08-14`. Invalid dates and unknown habit IDs produce an error and a non-zero exit status. Habit names must be non-empty after trimming.

## Tests

Run the complete unittest suite with:

```sh
python3 -m unittest discover -s . -p 'test_*.py' -v
```
