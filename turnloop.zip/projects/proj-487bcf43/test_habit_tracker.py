import json
from datetime import date
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from habit_tracker import (
    HabitNotFoundError,
    HabitStore,
    InvalidDateError,
)


ROOT = Path(__file__).parent
CLI = ROOT / "habit_cli.py"


class HabitStoreTests(unittest.TestCase):
    def test_json_persistence_round_trip(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "habits.json"
            store = HabitStore(path)
            habit = store.add_habit("  Drink water  ")
            habit.complete(date(2026, 8, 14))
            store.save()

            self.assertEqual(
                json.loads(path.read_text(encoding="utf-8")),
                {
                    "habits": [
                        {"id": "1", "name": "Drink water", "completions": ["2026-08-14"]}
                    ]
                },
            )
            loaded = HabitStore.load(path)
            self.assertEqual(loaded.list_habits()[0].name, "Drink water")
            self.assertEqual(loaded.list_habits()[0].completions, {"2026-08-14"})

    def test_add_and_list_preserve_order_and_generate_ids(self):
        store = HabitStore()
        first = store.add_habit("Read")
        second = store.add_habit("Exercise")

        self.assertEqual([habit.id for habit in store.list_habits()], ["1", "2"])
        self.assertEqual([habit.name for habit in store.list_habits()], ["Read", "Exercise"])
        self.assertEqual((first.id, second.id), ("1", "2"))

    def test_complete_and_clear_behaviors(self):
        store = HabitStore()
        first = store.add_habit("Read")
        second = store.add_habit("Exercise")
        store.complete_habit(first.id, "2026-08-14")
        store.complete_habit(first.id, "2026-08-15")
        store.complete_habit(second.id, "2026-08-14")

        store.clear_completion_data(first.id, "2026-08-14")
        self.assertEqual(first.completions, {"2026-08-15"})
        self.assertEqual(second.completions, {"2026-08-14"})
        store.clear_completion_data(completed_on="2026-08-14")
        self.assertEqual(first.completions, {"2026-08-15"})
        self.assertEqual(second.completions, set())
        store.clear_completion_data(first.id)
        self.assertEqual(first.completions, set())

    def test_invalid_date_is_rejected(self):
        store = HabitStore()
        habit = store.add_habit("Read")

        for invalid in ("2026-02-30", "14-08-2026", "2026-8-14", "not-a-date"):
            with self.subTest(invalid=invalid):
                with self.assertRaises(InvalidDateError):
                    habit.complete(invalid)

    def test_missing_ids_raise_habit_not_found(self):
        store = HabitStore()
        with self.assertRaises(HabitNotFoundError):
            store.get_habit("missing")
        with self.assertRaises(HabitNotFoundError):
            store.complete_habit("missing", "2026-08-14")
        with self.assertRaises(HabitNotFoundError):
            store.clear_completion_data("missing")


class HabitCliTests(unittest.TestCase):
    def run_cli(self, storage: Path, *arguments: str) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            [sys.executable, str(CLI), "--file", str(storage), *arguments],
            cwd=ROOT,
            text=True,
            capture_output=True,
            check=False,
        )

    def test_cli_add_list_complete_and_clear(self):
        with tempfile.TemporaryDirectory() as directory:
            storage = Path(directory) / "habits.json"
            result = self.run_cli(storage, "add", "Read books")
            self.assertEqual(result.returncode, 0)
            self.assertIn("Added habit 1: Read books", result.stdout)

            result = self.run_cli(storage, "list")
            self.assertEqual(result.returncode, 0)
            self.assertIn("1: Read books (completed: never)", result.stdout)

            result = self.run_cli(storage, "complete", "1", "--date", "2026-08-14")
            self.assertEqual(result.returncode, 0)
            self.assertIn("Completed 1: Read books on 2026-08-14", result.stdout)

            result = self.run_cli(storage, "clear", "1", "--date", "2026-08-14")
            self.assertEqual(result.returncode, 0)
            self.assertIn("Cleared completions for habit 1 for 2026-08-14.", result.stdout)

            result = self.run_cli(storage, "list")
            self.assertIn("1: Read books (completed: never)", result.stdout)

    def test_cli_reports_invalid_date_and_missing_id(self):
        with tempfile.TemporaryDirectory() as directory:
            storage = Path(directory) / "habits.json"
            self.assertEqual(self.run_cli(storage, "add", "Read").returncode, 0)

            invalid = self.run_cli(storage, "complete", "1", "--date", "2026-02-30")
            self.assertEqual(invalid.returncode, 1)
            self.assertIn("habit: error:", invalid.stderr)
            self.assertIn("invalid date", invalid.stderr)

            missing = self.run_cli(storage, "complete", "99", "--date", "2026-08-14")
            self.assertEqual(missing.returncode, 1)
            self.assertIn("habit: error:", missing.stderr)
            self.assertIn("habit not found", missing.stderr)


if __name__ == "__main__":
    unittest.main()
