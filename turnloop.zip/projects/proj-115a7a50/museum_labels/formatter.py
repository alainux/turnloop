"""Plain-text museum label formatter using only the standard library."""

import json


def format_labels(artifacts):
    """Format a list of artifact dicts as deterministic plain-text labels.

    Each label is separated by a line of dashes. Field order is fixed:
    title, artist, date, description, room.
    """
    if not artifacts:
        return ""

    blocks = []
    for artifact in artifacts:
        lines = [
            artifact["title"],
            artifact["artist"],
            artifact["date"],
            artifact["description"],
            artifact["room"],
        ]
        blocks.append("\n".join(lines))

    return "\n\n" + "\n\n-- -- -- -- -- -- -- --\n\n".join(blocks) + "\n\n"


def load_fixture(path):
    """Load the label fixture JSON and return the list of artifacts."""
    with open(path, "r", encoding="utf-8") as fh:
        return json.load(fh)