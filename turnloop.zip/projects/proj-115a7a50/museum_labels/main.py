"""CLI entry point: load the fixture, format labels, write labels.txt."""

import os

from formatter import format_labels, load_fixture

FIXTURE_PATH = os.path.join(os.path.dirname(__file__), "fixtures", "labels.json")
OUTPUT_PATH = os.path.join(os.path.dirname(__file__), "labels.txt")


def main():
    artifacts = load_fixture(FIXTURE_PATH)
    labels = format_labels(artifacts)
    with open(OUTPUT_PATH, "w", encoding="utf-8") as fh:
        fh.write(labels)


if __name__ == "__main__":
    main()