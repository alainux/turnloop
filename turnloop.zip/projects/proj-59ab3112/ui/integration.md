# Adventure HUD integration contract

`<adventure-hud>` is a presentation boundary. The adventure/3D runtime owns
movement, proximity checks, story rules, persistence, and deciding which state
is true. The HUD only renders a snapshot and emits player intent.

## Mounting

```html
<canvas id="world" aria-label="Adventure world"></canvas>
<adventure-hud></adventure-hud>
<script type="module" src="./adventure-hud.js"></script>
```

The component has no runtime dependencies. Set `hud.state = snapshot` after
mounting, or dispatch the same snapshot as `adventure:state` on `window`.

```js
window.dispatchEvent(new CustomEvent("adventure:state", { detail: {
  phase: "playing", // loading | playing | decision | won | lost | error
  title: "The Lantern Path",
  location: "Mossglass Crossing",
  objective: "Find the lantern keeper",
  objectiveDetail: "The bell is ringing beyond the old bridge.",
  interaction: { key: "E", label: "Speak with the keeper" },
  prompt: "The bridge is out. Which way?",
  choices: [
    { id: "ravine", key: "1", label: "Take the ravine path", hint: "Faster, but unlit" },
    { id: "wait", key: "2", label: "Wait for the ferry", hint: "Safer, if it comes" },
  ],
  message: "A cold wind moves through the reeds.",
  messageTone: "info", // info | success | error
  paused: false,
  canReset: true,
} }));
```

Listen on the element (events bubble and are composed through Shadow DOM):

- `adventure:choose` → `{ choiceId }`
- `adventure:pause` → `{ paused }`
- `adventure:reset` → `{}`

The host should validate `choiceId`, apply the story transition, and publish a
new snapshot. Keyboard/controller mapping stays with the game input layer; the
HUD exposes E/1/2 as readable hints and accepts clicks, Enter, and normal
browser focus navigation. Pause also closes with Escape when already paused.
