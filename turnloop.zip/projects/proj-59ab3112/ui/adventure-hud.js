/**
 * Player-facing adventure UI. The game owns state and rules; this element only
 * renders state and emits user intent as CustomEvents.
 *
 * Usage: <adventure-hud></adventure-hud>
 * State is supplied with hud.state = { ...AdventureHudState } or by dispatching
 * `adventure:state` on the element/window. See integration.md for the contract.
 */
const DEFAULT_STATE = {
  phase: "loading",
  title: "The Lantern Path",
  location: "Finding the trail…",
  objective: "Loading your next step",
  objectiveDetail: "The world is preparing.",
  interaction: null,
  choices: [],
  message: null,
  messageTone: "info",
  paused: false,
  canReset: true,
};

const esc = (value) => String(value ?? "")
  .replaceAll("&", "&amp;")
  .replaceAll("<", "&lt;")
  .replaceAll(">", "&gt;")
  .replaceAll('"', "&quot;")
  .replaceAll("'", "&#039;");

const icon = (name) => {
  const paths = {
    compass: '<circle cx="12" cy="12" r="9"/><path d="m15.5 8.5-2.1 4.9-4.9 2.1 2.1-4.9 4.9-2.1Z"/>',
    pause: '<rect x="6" y="5" width="3" height="14" rx="1"/><rect x="15" y="5" width="3" height="14" rx="1"/>',
    play: '<path d="m8 5 11 7-11 7V5Z"/>',
    rotate: '<path d="M4 12a8 8 0 0 1 13.7-5.6L20 9"/><path d="M20 4v5h-5"/><path d="M20 12a8 8 0 0 1-13.7 5.6L4 15"/><path d="M4 20v-5h5"/>',
    arrow: '<path d="M5 12h14"/><path d="m13 6 6 6-6 6"/>',
    check: '<path d="m5 12 4 4L19 6"/>',
    spark: '<path d="m12 3-1.3 5.7L5 10l5.7 1.3L12 17l1.3-5.7L19 10l-5.7-1.3L12 3Z"/>',
  };
  return `<svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${paths[name] || ""}</svg>`;
};

export class AdventureHud extends HTMLElement {
  constructor() {
    super();
    this._state = { ...DEFAULT_STATE };
    this.attachShadow({ mode: "open" });
    this.shadowRoot.innerHTML = `<style>${CSS_TEXT}</style><div class="hud" aria-live="polite"></div>`;
    this.shadowRoot.addEventListener("click", (event) => this._click(event));
    this.shadowRoot.addEventListener("keydown", (event) => {
      if (event.key === "Escape" && this._state.paused) this._emit("pause", { paused: false });
      if (this._state.paused || !this._state.choices?.length) return;
      const choice = this._state.choices.find((item, index) => String(item.key || index + 1) === event.key);
      if (choice && !choice.disabled) {
        event.preventDefault();
        this._emit("choose", { choiceId: choice.id });
      }
    });
    this._render();
  }

  set state(value) {
    this._state = { ...DEFAULT_STATE, ...(value || {}) };
    this._render();
  }
  get state() { return this._state; }

  connectedCallback() {
    this.addEventListener("adventure:state", (event) => { this.state = event.detail; });
    window.addEventListener("adventure:state", this._onWindowState = (event) => { this.state = event.detail; });
  }
  disconnectedCallback() { window.removeEventListener("adventure:state", this._onWindowState); }

  _emit(type, detail = {}) {
    this.dispatchEvent(new CustomEvent(`adventure:${type}`, { bubbles: true, composed: true, detail }));
  }
  _click(event) {
    const button = event.target.closest("button");
    if (!button) return;
    if (button.dataset.choice) this._emit("choose", { choiceId: button.dataset.choice });
    if (button.dataset.action === "pause") this._emit("pause", { paused: !this._state.paused });
    if (button.dataset.action === "reset") this._emit("reset");
  }
  _render() {
    const s = this._state;
    const phase = s.phase === "playing" ? "LIVE" : s.phase === "won" ? "COMPLETE" : s.phase === "lost" ? "ENDED" : String(s.phase || "READY").toUpperCase();
    const choices = (s.choices || []).map((choice, index) => `<button class="choice" data-choice="${esc(choice.id)}" ${choice.disabled ? "disabled" : ""}>
      <span class="choice-key">${esc(choice.key || String(index + 1))}</span><span class="choice-copy"><strong>${esc(choice.label)}</strong>${choice.hint ? `<small>${esc(choice.hint)}</small>` : ""}</span><span class="choice-arrow">${icon("arrow")}</span>
    </button>`).join("");
    const interaction = s.interaction ? `<div class="interaction"><span class="keycap">${esc(s.interaction.key || "E")}</span><span>${esc(s.interaction.label || "Interact")}</span></div>` : "";
    const end = ["won", "lost"].includes(s.phase) ? `<section class="end-state" aria-labelledby="end-title"><div class="end-mark">${icon(s.phase === "won" ? "check" : "spark")}</div><p class="eyebrow">${phase}</p><h2 id="end-title">${esc(s.endTitle || (s.phase === "won" ? "The path remembers you." : "The trail goes quiet."))}</h2><p>${esc(s.endMessage || "Your choices have shaped this chapter.")}</p><button class="primary" data-action="reset">${icon("rotate")} Begin again</button></section>` : "";
    const error = s.phase === "error" ? `<div class="state-card error"><strong>Something interrupted the journey.</strong><span>${esc(s.error || "Try again when the world is ready.")}</span><button class="text-button" data-action="reset">Reset adventure</button></div>` : "";
    this.shadowRoot.querySelector(".hud").innerHTML = `<header class="topbar"><div class="brand"><span class="brand-mark">${icon("compass")}</span><span>${esc(s.title)}</span></div><div class="top-actions"><span class="status status-${esc(s.phase)}"><i></i>${phase}</span><button class="icon-button" data-action="pause" aria-label="${s.paused ? "Resume" : "Pause"} adventure" title="${s.paused ? "Resume" : "Pause"} (P)">${icon(s.paused ? "play" : "pause")}</button></div></header>
      <main class="content"><div class="location"><span class="eyebrow">CURRENT LOCATION</span><strong>${esc(s.location || "Unknown")}</strong></div><section class="objective" aria-label="Current objective"><div class="objective-icon">${icon("spark")}</div><div><span class="eyebrow">NEXT OBJECTIVE</span><h1>${esc(s.objective || "Explore freely")}</h1><p>${esc(s.objectiveDetail || "")}</p></div></section>${s.message ? `<div class="message message-${esc(s.messageTone)}">${esc(s.message)}</div>` : ""}${interaction}${s.choices?.length ? `<section class="decision" aria-labelledby="decision-title"><div class="eyebrow">A DECISION AWAITS</div><h2 id="decision-title">${esc(s.prompt || "What will you do?")}</h2><div class="choices">${choices}</div></section>` : ""}${s.phase === "loading" ? `<div class="state-card"><span class="spinner"></span><span>Preparing the world…</span></div>` : ""}${error}${end}</main><footer class="footer"><span>Move <kbd>W A S D</kbd><span class="dot">·</span> interact <kbd>E</kbd></span><button class="reset-link" data-action="reset" ${s.canReset === false ? "hidden" : ""}>Reset story</button></footer>${s.paused ? `<div class="pause-scrim"><section class="pause-card" role="dialog" aria-modal="true" aria-labelledby="pause-title"><span class="eyebrow">ADVENTURE PAUSED</span><h2 id="pause-title">Take a breath.</h2><p>The world is waiting for your next move.</p><button class="primary" data-action="pause">${icon("play")} Resume</button><button class="text-button" data-action="reset">Reset story</button></section></div>` : ""}`;
  }
}

if (!customElements.get("adventure-hud")) customElements.define("adventure-hud", AdventureHud);

const CSS_TEXT = `
:host { --bg:#101319; --surface:#171c24; --surface-hi:#202733; --line:#303947; --text:#edf1f7; --muted:#a2adbc; --faint:#697587; --accent:#f0b866; --accent-soft:#3b2e1d; --green:#7bce9b; --red:#f18181; display:block; width:100%; height:100%; color:var(--text); font:14px/1.45 Inter,ui-sans-serif,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; }
* { box-sizing:border-box; } button { font:inherit; color:inherit; } button:focus-visible { outline:2px solid var(--accent); outline-offset:3px; } .hud { position:relative; min-height:100%; overflow:hidden; background:radial-gradient(circle at 72% 12%,rgba(99,125,154,.1),transparent 32%),linear-gradient(135deg,#10141a,#0d1015 70%); }
.topbar,.footer { position:absolute; left:0; right:0; display:flex; align-items:center; justify-content:space-between; padding:18px 24px; z-index:2; } .topbar { top:0; border-bottom:1px solid rgba(255,255,255,.07); } .footer { bottom:0; color:var(--muted); font-size:12px; border-top:1px solid rgba(255,255,255,.07); } .brand,.top-actions,.interaction,.message,.choice,.primary,.text-button { display:flex; align-items:center; } .brand { gap:10px; font-weight:700; letter-spacing:.02em; } .brand-mark,.objective-icon,.end-mark { display:grid; place-items:center; color:var(--accent); } .brand-mark svg { width:20px; height:20px; } .top-actions { gap:14px; } .status { display:flex; align-items:center; gap:7px; color:var(--muted); font:10px/1 ui-monospace,SFMono-Regular,Menlo,monospace; letter-spacing:.12em; } .status i { width:6px; height:6px; border-radius:50%; background:var(--faint); } .status-playing i { background:var(--green); box-shadow:0 0 0 3px rgba(123,206,155,.12); } .status-won i { background:var(--accent); } .status-error i,.status-lost i { background:var(--red); }
.icon-button,.reset-link { border:0; background:transparent; cursor:pointer; } .icon-button { width:32px; height:32px; display:grid; place-items:center; border:1px solid var(--line); border-radius:7px; background:rgba(255,255,255,.03); } .icon-button svg { width:15px; height:15px; } .content { width:min(100% - 48px,520px); min-height:100%; margin:auto; padding:112px 0 92px; } .location { display:flex; flex-direction:column; gap:3px; margin-bottom:32px; } .eyebrow { display:block; color:var(--faint); font:10px/1.2 ui-monospace,SFMono-Regular,Menlo,monospace; letter-spacing:.16em; } .location strong { font-size:13px; font-weight:500; color:var(--muted); } .objective { display:flex; gap:15px; padding:20px 0 22px; border-top:1px solid var(--line); border-bottom:1px solid var(--line); } .objective-icon { width:30px; height:30px; flex:0 0 auto; border:1px solid #634e2e; border-radius:50%; background:var(--accent-soft); } .objective-icon svg { width:15px; height:15px; } h1,h2,p { margin:0; } h1 { margin-top:8px; font-size:22px; line-height:1.15; letter-spacing:-.02em; } .objective p { margin-top:7px; color:var(--muted); } .interaction { width:max-content; gap:9px; margin:26px auto 0; padding:8px 12px; color:var(--text); background:rgba(255,255,255,.07); border:1px solid var(--line); border-radius:7px; } .keycap,kbd { padding:2px 6px; border:1px solid #657183; border-bottom-width:2px; border-radius:4px; color:var(--text); background:var(--surface-hi); font:11px ui-monospace,SFMono-Regular,Menlo,monospace; } .message { margin-top:22px; padding:10px 12px; border-left:2px solid var(--accent); color:var(--muted); background:rgba(240,184,102,.07); } .message-success { border-color:var(--green); background:rgba(123,206,155,.07); } .message-error { border-color:var(--red); background:rgba(241,129,129,.07); }
.decision { margin-top:40px; } .decision h2 { margin:9px 0 14px; font-size:17px; font-weight:600; } .choices { display:grid; gap:8px; } .choice { width:100%; gap:12px; padding:12px 13px; text-align:left; border:1px solid var(--line); border-radius:7px; background:rgba(23,28,36,.86); cursor:pointer; transition:background .15s,border-color .15s,transform .15s; } .choice:hover { border-color:#677487; background:var(--surface-hi); transform:translateY(-1px); } .choice:disabled { opacity:.45; cursor:not-allowed; transform:none; } .choice-key { display:grid; place-items:center; width:22px; height:22px; flex:0 0 auto; border:1px solid #647082; border-radius:4px; color:var(--muted); font:11px ui-monospace,SFMono-Regular,Menlo,monospace; } .choice-copy { display:flex; flex:1; flex-direction:column; gap:2px; } .choice-copy strong { font-size:13px; font-weight:600; } .choice-copy small { color:var(--muted); } .choice-arrow { color:var(--faint); } .choice-arrow svg { width:15px; height:15px; } .state-card { display:flex; align-items:center; gap:10px; margin-top:28px; padding:13px; border:1px dashed var(--line); border-radius:7px; color:var(--muted); } .spinner { width:14px; height:14px; border:2px solid var(--line); border-top-color:var(--accent); border-radius:50%; animation:spin .8s linear infinite; } .state-card.error { flex-wrap:wrap; border-color:rgba(241,129,129,.45); color:var(--red); } .state-card.error span { color:var(--muted); } .text-button,.reset-link { border:0; padding:0; color:var(--accent); background:transparent; cursor:pointer; font-size:12px; } .state-card .text-button { margin-left:auto; } .primary { justify-content:center; gap:8px; width:100%; min-height:38px; margin-top:20px; border:1px solid #d59c4d; border-radius:6px; color:#21180c; background:var(--accent); font-weight:700; cursor:pointer; } .primary svg { width:15px; height:15px; } .end-state { margin:36px auto 0; max-width:390px; padding:28px; text-align:center; border:1px solid #4c3d29; border-radius:10px; background:rgba(26,25,22,.85); } .end-mark { width:40px; height:40px; margin:0 auto 18px; border:1px solid #725a35; border-radius:50%; background:var(--accent-soft); } .end-mark svg { width:20px; height:20px; } .end-state h2 { margin-top:10px; font-size:21px; } .end-state p:not(.eyebrow) { margin-top:8px; color:var(--muted); } .pause-scrim { position:absolute; inset:0; z-index:5; display:grid; place-items:center; background:rgba(7,9,12,.74); backdrop-filter:blur(5px); } .pause-card { width:min(calc(100% - 40px),360px); padding:30px; text-align:center; border:1px solid var(--line); border-radius:10px; background:var(--surface); box-shadow:0 20px 60px rgba(0,0,0,.45); } .pause-card h2 { margin-top:10px; font-size:24px; } .pause-card p { margin-top:8px; color:var(--muted); } .pause-card .text-button { margin-top:16px; } .dot { padding:0 8px; color:var(--faint); } @keyframes spin { to { transform:rotate(360deg); } } @media (max-width:560px) { .topbar,.footer { padding:14px 16px; } .content { width:min(100% - 32px,520px); padding-top:92px; } h1 { font-size:19px; } .footer span { display:flex; align-items:center; } .footer .dot,.footer kbd:first-of-type { display:none; } }
@media (prefers-reduced-motion:reduce) { *,*::before,*::after { animation-duration:.01ms !important; transition-duration:.01ms !important; } }
`;
