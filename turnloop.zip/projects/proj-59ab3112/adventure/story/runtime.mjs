/**
 * Deterministic, data-driven adventure runtime.
 *
 * The runtime owns story state only. A host supplies an interactable id and
 * consumes returned events/state; it does not need to know how locations are
 * rendered or how the player reached them.
 */
export class AdventureRuntime {
  constructor(config, { onEvent } = {}) {
    validateConfig(config);
    this.config = structuredClone(config);
    this.listeners = new Set();
    if (onEvent) this.listeners.add(onEvent);
    this.reset();
  }

  subscribe(listener) {
    if (typeof listener !== "function") throw new TypeError("listener must be a function");
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  reset() {
    this.state = {
      status: "playing",
      locationId: this.config.startLocation,
      flags: [],
      completedObjectives: [],
      visitedLocations: [this.config.startLocation],
      endingId: null,
    };
    return this._result([{ type: "story.reset", locationId: this.state.locationId }, {
      type: "story.location_entered",
      locationId: this.state.locationId,
      location: this.location(),
    }]);
  }

  snapshot() {
    return structuredClone(this.state);
  }

  location() {
    return structuredClone(this.config.locations[this.state.locationId]);
  }

  availableChoices() {
    if (this.state.status !== "playing") return [];
    return this.location().interactables.filter((choice) => this._meets(choice.requires));
  }

  objectiveList() {
    return this.config.objectives.map((objective) => ({
      ...structuredClone(objective),
      complete: this.state.completedObjectives.includes(objective.id),
    }));
  }

  /**
   * Input contract: { interactableId: string } (or a string id).
   * Output contract: { ok, state, location, choices, objectives, events }.
   */
  interact(input) {
    const interactableId = typeof input === "string" ? input : input?.interactableId;
    const events = [];
    if (this.state.status !== "playing") {
      events.push({ type: "story.action_rejected", reason: "adventure_finished", interactableId });
      return this._result(events, false);
    }

    const choice = this.location().interactables.find((item) => item.id === interactableId);
    if (!choice) {
      events.push({ type: "story.action_rejected", reason: "unknown_interactable", interactableId });
      return this._result(events, false);
    }
    if (!this._meets(choice.requires)) {
      events.push({ type: "story.action_rejected", reason: "requirements_not_met", interactableId });
      return this._result(events, false);
    }

    events.push({ type: "story.choice_selected", locationId: this.state.locationId, choice: structuredClone(choice) });
    this._applyEffects(choice.effects, events);

    if (choice.ending) {
      const ending = this.config.endings[choice.ending];
      this.state.status = "ended";
      this.state.endingId = choice.ending;
      events.push({ type: "story.ending_reached", endingId: choice.ending, ending: structuredClone(ending) });
    } else if (choice.nextLocation) {
      this._enter(choice.nextLocation, events);
    }
    return this._result(events, true);
  }

  _meets(requires = {}) {
    const flags = new Set(this.state.flags);
    const objectives = new Set(this.state.completedObjectives);
    return (requires.flags ?? []).every((flag) => flags.has(flag))
      && (requires.objectives ?? []).every((id) => objectives.has(id))
      && (requires.notFlags ?? []).every((flag) => !flags.has(flag));
  }

  _applyEffects(effects = {}, events) {
    const flags = new Set(this.state.flags);
    for (const flag of effects.setFlags ?? []) {
      if (!flags.has(flag)) {
        flags.add(flag);
        events.push({ type: "story.flag_changed", flag, value: true });
      }
    }
    this.state.flags = [...flags].sort();

    const completed = new Set(this.state.completedObjectives);
    for (const id of effects.completeObjectives ?? []) {
      if (!completed.has(id)) {
        completed.add(id);
        events.push({ type: "story.objective_updated", objectiveId: id, complete: true });
      }
    }
    this.state.completedObjectives = [...completed];
  }

  _enter(locationId, events) {
    if (!this.config.locations[locationId]) throw new Error(`Unknown next location: ${locationId}`);
    this.state.locationId = locationId;
    if (!this.state.visitedLocations.includes(locationId)) this.state.visitedLocations.push(locationId);
    events.push({ type: "story.location_entered", locationId, location: this.location() });
  }

  _result(events, ok = true) {
    const result = {
      ok,
      state: this.snapshot(),
      location: this.location(),
      choices: this.availableChoices(),
      objectives: this.objectiveList(),
      events: structuredClone(events),
    };
    for (const event of events) for (const listener of this.listeners) listener(structuredClone(event), result);
    return result;
  }
}

function validateConfig(config) {
  if (!config || typeof config !== "object") throw new TypeError("Adventure config must be an object");
  if (!config.startLocation || !config.locations?.[config.startLocation]) throw new Error("Config startLocation must name a location");
  if (!Array.isArray(config.objectives)) throw new Error("Config objectives must be an array");
  if (!config.endings || typeof config.endings !== "object") throw new Error("Config endings must be an object");
  for (const [id, location] of Object.entries(config.locations)) {
    if (!Array.isArray(location.interactables)) throw new Error(`Location ${id} needs interactables[]`);
    for (const choice of location.interactables) {
      if (!choice.id || (!choice.nextLocation && !choice.ending)) throw new Error(`Choice ${id}/${choice.id} needs nextLocation or ending`);
    }
  }
}

