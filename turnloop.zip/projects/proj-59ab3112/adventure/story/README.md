# Adventure story contract

`runtime.mjs` is the deterministic progression layer for the game. It owns no movement, rendering, input mapping, audio, or UI styling. `demo.json` is a small playable configuration that can be replaced with another config using the same shape.

## Host contract

```js
import config from "./demo.json" with { type: "json" };
import { AdventureRuntime } from "./runtime.mjs";

const story = new AdventureRuntime(config);
story.subscribe((event, output) => renderStory(output, event));
const output = story.interact({ interactableId: "take-lantern" });
```

The host presents `output.location`, `output.choices`, and `output.objectives`. It sends only `{ interactableId }` to `interact`; it may also pass a string id. `output.ok` is false for an unavailable/unknown action. Every output includes a complete immutable-by-convention `state` snapshot and ordered `events`.

State is resettable with `reset()`. There is no clock, random number, network call, or hidden mutation, so the same config and action sequence always produce the same result.

## Data model

- `locations[id]`: presentation text plus `interactables[]`.
- Interactable: `id`, `label`, optional `description`, `requires` (`flags`, `notFlags`, `objectives`), `effects` (`setFlags`, `completeObjectives`), and exactly one `nextLocation` or `ending`.
- `objectives[]`: stable `id`, title, and description.
- `endings[id]`: terminal title and description.

## Events

`story.reset`, `story.location_entered`, `story.choice_selected`, `story.flag_changed`, `story.objective_updated`, `story.ending_reached`, and `story.action_rejected`. Event payloads contain stable ids and the relevant data for a HUD, dialogue panel, or world presentation adapter.

## Smoke test

With Node 18+:

```sh
node adventure/story/smoke.test.mjs
```
