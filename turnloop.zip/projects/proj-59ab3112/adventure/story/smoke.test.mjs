import assert from "node:assert/strict";
import config from "./demo.json" with { type: "json" };
import { AdventureRuntime } from "./runtime.mjs";

const events = [];
const game = new AdventureRuntime(config, { onEvent: (event) => events.push(event.type) });
assert.equal(game.snapshot().locationId, "village");
game.interact("take-lantern");
game.interact("climb-hill");
game.interact("speak-truth");
const ending = game.interact("plant-starseed");
assert.equal(ending.ok, true);
assert.equal(ending.state.endingId, "shared-light");
assert.equal(ending.state.status, "ended");
assert.ok(ending.objectives.every((objective) => objective.complete));
assert.equal(game.interact("take-lantern").ok, false);

game.reset();
assert.deepEqual(game.snapshot(), {
  status: "playing",
  locationId: "village",
  flags: [],
  completedObjectives: [],
  visitedLocations: ["village"],
  endingId: null,
});
assert.ok(events.includes("story.ending_reached"));
console.log("adventure story smoke test passed");
