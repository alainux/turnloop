import test from "node:test";
import assert from "node:assert/strict";
import { WORLD_OBJECTS, nearestInteractable } from "./world.js";

test("world exposes stable tagged story bindings", () => {
  const ids = WORLD_OBJECTS.filter((object) => object.binding).map((object) => object.binding);
  assert.deepEqual(ids, ["take-lantern", "climb-hill", "follow-river", "plant-starseed", "claim-starseed"]);
  assert.ok(WORLD_OBJECTS.every((object) => object.id && object.tags.length));
});

test("nearest marker respects the interaction radius", () => {
  assert.equal(nearestInteractable({ x: -1.35, z: 1.6 }, 2.5).binding, "take-lantern");
  assert.equal(nearestInteractable({ x: 50, z: 50 }, 2.5), null);
});
