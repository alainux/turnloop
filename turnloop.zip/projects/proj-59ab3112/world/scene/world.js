/**
 * Lantern Path world presentation.
 *
 * This module deliberately owns only world geometry, presentation, collision
 * rectangles, and the bridge from a nearby world marker to an external
 * interactable id. Story rules remain in adventure/story/runtime.mjs.
 */

export const WORLD_ID = "lantern-path-village";

export const WORLD_OBJECTS = Object.freeze([
  { id: "landmark-village-square", kind: "landmark", label: "Bramblewick Square", tags: ["village", "start"], position: { x: 0, y: 0, z: 2 }, size: { x: 2.8, y: 1.7, z: 2.4 }, color: "#b97855" },
  { id: "marker-keeper-lantern", kind: "interactable", label: "Keeper's lantern", binding: "take-lantern", tags: ["village", "lantern", "story-interactable"], position: { x: -1.35, y: 0, z: 1.6 }, size: { x: 0.42, y: 0.9, z: 0.42 }, color: "#ffd36b", interactionRadius: 1.8 },
  { id: "landmark-path-fork", kind: "landmark", label: "The split path", tags: ["fork", "navigation"], position: { x: 0, y: 0, z: -4 }, size: { x: 1.8, y: 0.05, z: 1.8 }, color: "#c3a575" },
  { id: "marker-guardian-hill", kind: "interactable", label: "Guardian's hill", binding: "climb-hill", tags: ["guardian", "hill", "story-interactable"], position: { x: 5.7, y: 0, z: -7.2 }, size: { x: 2.3, y: 2.2, z: 2.3 }, color: "#647d68", interactionRadius: 2.2 },
  { id: "marker-river-crossing", kind: "interactable", label: "Broken river crossing", binding: "follow-river", tags: ["river", "bridge", "story-interactable"], position: { x: -5.4, y: 0, z: -7 }, size: { x: 2.5, y: 0.12, z: 1.5 }, color: "#5592a3", interactionRadius: 2.2 },
  { id: "marker-starseed-grove", kind: "interactable", label: "Starfall Grove", binding: "plant-starseed", tags: ["grove", "starseed", "story-interactable"], position: { x: 0, y: 0, z: -12 }, size: { x: 2.5, y: 2.6, z: 2.5 }, color: "#4c7d70", interactionRadius: 2.4 },
  { id: "marker-shadowed-ravine", kind: "interactable", label: "Shadowed ravine", binding: "claim-starseed", tags: ["ravine", "ending", "story-interactable"], position: { x: 7.4, y: 0, z: -12 }, size: { x: 2.4, y: 1.4, z: 2.4 }, color: "#4b536a", interactionRadius: 2.3 },
  { id: "landmark-river", kind: "landmark", label: "Moonlit river", tags: ["river", "navigation"], position: { x: -5.4, y: 0, z: -10 }, size: { x: 1.2, y: 0.04, z: 9 }, color: "#477f91" },
]);

export const WORLD_COLLIDERS = Object.freeze(WORLD_OBJECTS
  .filter((object) => object.kind === "landmark" && object.id !== "landmark-path-fork" && object.id !== "landmark-river")
  .map(({ position, size }) => ({ x: position.x, z: position.z, width: size.x, depth: size.z })));

export function getWorldObject(id) { return WORLD_OBJECTS.find((object) => object.id === id) ?? null; }

export function nearestInteractable(position, maxDistance = Infinity) {
  return WORLD_OBJECTS
    .filter((object) => object.kind === "interactable")
    .map((object) => ({ object, distance: Math.hypot(position.x - object.position.x, position.z - object.position.z) }))
    .filter(({ distance }) => distance <= maxDistance)
    .sort((a, b) => a.distance - b.distance)[0]?.object ?? null;
}

export function createWorldScene({ canvas, runtime, onInteract = () => {} } = {}) {
  if (!canvas) throw new TypeError("createWorldScene requires a canvas");
  if (!runtime) throw new TypeError("createWorldScene requires a runtime");
  runtime.player.bounds ??= { minX: -10, maxX: 10, minZ: -15, maxZ: 5 };
  runtime.player.setColliders(WORLD_COLLIDERS);
  let hoveredId = null;
  const interactionListener = ({ position }) => {
    const object = nearestInteractable(position, 2.5);
    if (object) onInteract({ objectId: object.id, interactableId: object.binding, distance: Math.hypot(position.x - object.position.x, position.z - object.position.z) });
  };
  const unsubscribe = runtime.events.on("interact", interactionListener);
  return {
    worldId: WORLD_ID,
    objects: WORLD_OBJECTS,
    get hoveredObjectId() { return hoveredId; },
    render(time = 0) { hoveredId = nearestInteractable(runtime.player.position, 2.5)?.id ?? null; renderWorld(canvas, runtime, hoveredId, time); },
    dispose() { unsubscribe(); },
  };
}

function renderWorld(canvas, runtime, hoveredId, time) {
  const context = canvas.getContext("2d");
  if (!context) return;
  const ratio = Math.max(1, globalThis.devicePixelRatio || 1);
  const width = canvas.clientWidth || 960, height = canvas.clientHeight || 540;
  if (canvas.width !== width * ratio || canvas.height !== height * ratio) { canvas.width = width * ratio; canvas.height = height * ratio; }
  context.setTransform(ratio, 0, 0, ratio, 0, 0);
  context.clearRect(0, 0, width, height);
  const gradient = context.createLinearGradient(0, 0, 0, height);
  gradient.addColorStop(0, "#162b3b"); gradient.addColorStop(0.62, "#5c8790"); gradient.addColorStop(1, "#1e3838");
  context.fillStyle = gradient; context.fillRect(0, 0, width, height);
  const camera = { x: runtime.player.position.x + 7, y: 6.5, z: runtime.player.position.z + 8 };
  const projection = makeProjection(camera, runtime.player.position, width, height);
  drawGround(context, projection, width, height);
  drawPaths(context, projection);
  const objects = [...WORLD_OBJECTS].sort((a, b) => depthOf(a.position, camera) - depthOf(b.position, camera));
  for (const object of objects) drawObject(context, projection, object, object.id === hoveredId, time);
  drawPlayer(context, projection, runtime.player.position);
  context.fillStyle = "rgba(8, 16, 24, .68)"; context.fillRect(18, 18, 246, 54);
  context.fillStyle = "#f6e6bd"; context.font = "600 15px system-ui"; context.fillText("THE LANTERN PATH", 32, 40);
  context.fillStyle = "#b8d6cf"; context.font = "13px system-ui"; context.fillText(hoveredId ? "E  interact with nearby marker" : "WASD  explore   E  interact", 32, 60);
}

function makeProjection(camera, target, width, height) {
  const forward = normalize({ x: target.x - camera.x, y: 0, z: target.z - camera.z });
  const right = { x: -forward.z, z: forward.x };
  const focal = Math.min(width, height) * 0.9;
  return (point) => {
    const dx = point.x - camera.x, dz = point.z - camera.z;
    const depth = Math.max(1, dx * forward.x + dz * forward.z);
    const horizontal = dx * right.x + dz * right.z;
    return { x: width / 2 + horizontal * focal / depth, y: height * 0.56 - (point.y - camera.y) * focal / depth, depth, scale: focal / depth };
  };
}
function drawGround(context, project, width, height) { context.fillStyle = "#294c43"; context.beginPath(); context.moveTo(0, height * .55); context.lineTo(width, height * .55); context.lineTo(width, height); context.lineTo(0, height); context.fill(); const p = project({ x: 0, y: 0, z: 0 }); context.fillStyle = "rgba(215, 189, 126, .12)"; context.beginPath(); context.ellipse(p.x, p.y + 100, 350, 130, 0, 0, Math.PI * 2); context.fill(); }
function drawPaths(context, project) { for (const points of [[[-.8, 3], [0, -13], [.8, -13], [.8, 3]], [[-.8, -4], [-6, -12], [-5, -12], [.1, -4]], [[.2, -4], [6.8, -12], [8, -12], [.8, -4]]]) { context.fillStyle = "#b79a6c"; context.beginPath(); points.forEach(([x, z], i) => { const p = project({ x, y: .01, z }); i ? context.lineTo(p.x, p.y) : context.moveTo(p.x, p.y); }); context.fill(); } }
function drawObject(context, project, object, hovered, time) { const top = project({ x: object.position.x, y: object.position.y + object.size.y, z: object.position.z }); const base = project(object.position); const sx = object.size.x * top.scale * .55, sz = object.size.z * top.scale * .55; const color = hovered ? "#ffe59a" : object.color; context.fillStyle = color; context.beginPath(); context.ellipse(base.x, base.y, sx, sz * .58, 0, 0, Math.PI * 2); context.fill(); if (object.size.y > .2) { context.fillStyle = shade(color, -.24); context.fillRect(base.x - sx, top.y, sx * 2, base.y - top.y); context.fillStyle = shade(color, .14); context.beginPath(); context.ellipse(top.x, top.y, sx, sz * .58, 0, 0, Math.PI * 2); context.fill(); } if (object.kind === "interactable") { const pulse = 1 + Math.sin(time / 280) * .08; context.strokeStyle = hovered ? "#fff1bd" : "rgba(255, 220, 130, .75)"; context.lineWidth = hovered ? 3 : 1.5; context.beginPath(); context.arc(top.x, top.y - 15, 10 * pulse, 0, Math.PI * 2); context.stroke(); } }
function drawPlayer(context, project, position) { const p = project({ ...position, y: .65 }); context.fillStyle = "#edf0db"; context.beginPath(); context.arc(p.x, p.y, 8, 0, Math.PI * 2); context.fill(); context.fillStyle = "#cf765b"; context.beginPath(); context.arc(p.x, p.y - 9, 6, 0, Math.PI * 2); context.fill(); }
function depthOf(point, camera) { return Math.hypot(point.x - camera.x, point.z - camera.z); }
function normalize(vector) { const length = Math.hypot(vector.x, vector.z) || 1; return { x: vector.x / length, z: vector.z / length }; }
function shade(hex, amount) { const value = Number.parseInt(hex.slice(1), 16); const channels = [value >> 16, value >> 8 & 255, value & 255].map((channel) => Math.max(0, Math.min(255, Math.round(channel * (1 + amount))))); return `rgb(${channels.join(",")})`; }
