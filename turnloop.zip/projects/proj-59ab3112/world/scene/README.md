# Lantern Path world scene

This is the explorable 3D presentation layer for the small adventure. It is a
dependency-free, procedural scene rendered with a perspective software
projection onto a canvas. The compact layout is camera-readable: Bramblewick
Square is the spawn landmark, the split path is centered ahead, and the three
routes visibly separate toward the guardian hill, river crossing, and grove.

## Stable world contract

`WORLD_OBJECTS` is the source of truth for presentation objects. Every object
has a stable `id`, `tags`, and world `position`; interactable objects also have
`kind: "interactable"`, a `binding` (the external story interactable id), and
an `interactionRadius`. The current story bindings are:

| World marker | Story binding | Intended location |
| --- | --- | --- |
| `marker-keeper-lantern` | `take-lantern` | village square |
| `marker-guardian-hill` | `climb-hill` | east hill |
| `marker-river-crossing` | `follow-river` | west river |
| `marker-starseed-grove` | `plant-starseed` | north grove |
| `marker-shadowed-ravine` | `claim-starseed` | northeast ravine |

The world never decides whether a story action is available or what it does.
When the foundation emits `interact`, `createWorldScene` finds the nearest
marker within 2.5 world units and calls `onInteract({ objectId,
interactableId, distance })`. The host may pass only `interactableId` to the
adventure runtime, then use its returned story state to update any UI or marker
state. A missing nearby marker produces no callback.

`WORLD_COLLIDERS` contains solid landmarks suitable for
`runtime.player.setColliders`; paths, water, and marker-only objects remain
passable so the host can choose whether to add domain-specific blockers.

## Preview

Open `world/scene/index.html` from a static server. The scene has no build step
or external asset download. `WASD`/arrow keys move, `E` interacts, and `R`
resets the foundation runtime. Interaction payloads are logged in the browser
console in the preview.
