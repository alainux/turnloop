import test from 'node:test';
import assert from 'node:assert/strict';
import { createGameRuntime } from '../src/foundation/core/runtime.js';

test('runtime moves, collides, and exposes interaction/lifecycle events', () => {
  const runtime = createGameRuntime({ playerOptions: { speed: 2, bounds: { minX: -2, maxX: 2, minZ: -2, maxZ: 2 } } });
  const fired = []; runtime.events.on('interact', () => fired.push('interact')); runtime.events.on('pause', () => fired.push('pause')); runtime.events.on('reset', () => fired.push('reset'));
  runtime.input.down.add('KeyW'); runtime.frame(1000); runtime.frame(1500);
  assert.ok(runtime.player.position.z < 0);
  runtime.input.down.delete('KeyW'); runtime.input.pressed.add('KeyE'); runtime.frame(1600);
  assert.deepEqual(fired, ['interact']);
  runtime.input.pressed.add('Escape'); runtime.frame(1700); assert.equal(runtime.state.paused, true);
  runtime.reset(); assert.equal(runtime.player.position.z, 0); assert.equal(runtime.state.paused, false);
});

test('solid colliders stop the player', () => {
  const runtime = createGameRuntime({ playerOptions: { speed: 10 } });
  runtime.player.setColliders([{ x: 0, z: -1, width: 3, depth: 0.2 }]);
  runtime.input.down.add('KeyW'); runtime.frame(1000); runtime.frame(1200);
  assert.ok(runtime.player.position.z > -0.7);
});
