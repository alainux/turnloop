const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
const overlaps = (a, b) => a.x - a.radius < b.x + b.width / 2 && a.x + a.radius > b.x - b.width / 2 && a.z - a.radius < b.z + b.depth / 2 && a.z + a.radius > b.z - b.depth / 2;

export class PlayerController {
  constructor({ position = { x: 0, y: 0, z: 0 }, speed = 4, radius = 0.35, bounds = null } = {}) {
    this.position = { ...position }; this.spawn = { ...position }; this.speed = speed; this.radius = radius; this.bounds = bounds; this.colliders = [];
  }
  setColliders(colliders = []) { this.colliders = colliders; }
  reset() { this.position = { ...this.spawn }; }
  update(input, dt) {
    const axis = { x: Number(input.isDown('right')) - Number(input.isDown('left')), z: Number(input.isDown('backward')) - Number(input.isDown('forward')) };
    const length = Math.hypot(axis.x, axis.z) || 1;
    const delta = { x: axis.x / length * this.speed * dt, z: axis.z / length * this.speed * dt };
    this.#tryMove(delta.x, 0); this.#tryMove(0, delta.z);
    return this.position;
  }
  #tryMove(dx, dz) {
    const candidate = { x: this.position.x + dx, z: this.position.z + dz, radius: this.radius };
    if (this.bounds) { candidate.x = clamp(candidate.x, this.bounds.minX + this.radius, this.bounds.maxX - this.radius); candidate.z = clamp(candidate.z, this.bounds.minZ + this.radius, this.bounds.maxZ - this.radius); }
    if (!this.colliders.some((collider) => overlaps(candidate, collider))) { this.position.x = candidate.x; this.position.z = candidate.z; }
  }
}
