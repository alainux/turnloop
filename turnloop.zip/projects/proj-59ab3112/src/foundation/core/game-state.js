import { EventBus } from './events.js';

export class GameState {
  constructor({ scene = 'start', paused = false } = {}) { this.events = new EventBus(); this.initial = { scene, paused }; this.scene = scene; this.paused = paused; }
  loadScene(scene, meta = {}) { if (!scene || scene === this.scene) return; this.scene = scene; this.events.emit('scene-load', { scene, meta }); }
  setPaused(paused) { if (this.paused === paused) return; this.paused = paused; this.events.emit(paused ? 'pause' : 'resume', { paused }); }
  togglePause() { this.setPaused(!this.paused); }
  reset() { this.scene = this.initial.scene; this.paused = this.initial.paused; this.events.emit('reset', this.snapshot()); }
  snapshot() { return { scene: this.scene, paused: this.paused }; }
}
