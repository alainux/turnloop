/** Tiny dependency-free event bus used at domain boundaries. */
export class EventBus {
  #listeners = new Map();

  on(event, listener) {
    if (!this.#listeners.has(event)) this.#listeners.set(event, new Set());
    this.#listeners.get(event).add(listener);
    return () => this.off(event, listener);
  }

  off(event, listener) {
    this.#listeners.get(event)?.delete(listener);
  }

  emit(event, payload) {
    for (const listener of this.#listeners.get(event) ?? []) listener(payload);
  }

  clear() { this.#listeners.clear(); }
}
