export class FollowCamera {
  constructor({ distance = 6, height = 4, smoothing = 12 } = {}) { this.distance = distance; this.height = height; this.smoothing = smoothing; this.position = { x: 0, y: height, z: distance }; }
  update(target, dt) {
    const factor = 1 - Math.exp(-this.smoothing * dt);
    this.position.x += (target.x - this.position.x) * factor;
    this.position.y += (target.y + this.height - this.position.y) * factor;
    this.position.z += (target.z + this.distance - this.position.z) * factor;
    return this.position;
  }
}
