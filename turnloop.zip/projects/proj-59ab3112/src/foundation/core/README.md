# Runtime foundation

`bootstrapScene()` creates a dependency-free playable runtime. It owns input, a kinematic X/Z player, follow camera, scene lifecycle, pause/reset state, and event boundaries. Rendering is intentionally adapter-owned: a renderer can read `runtime.player.position` and `runtime.camera.position` each frame.

## Public contract

- `runtime.frame(timeMs)` advances movement and emits `player-moved`.
- `runtime.events.on('interact', handler)` receives `{ position, scene }` when E, Enter, or Space is pressed.
- `runtime.events.on('scene-load', handler)` receives `{ scene, meta }`; call `runtime.loadScene(id, meta)` to request one.
- `runtime.events.on('pause'|'resume'|'reset', handler)` exposes lifecycle changes. Escape/P toggle pause; R resets.
- `runtime.player.position` is `{ x, y, z }`; set `runtime.player.setColliders([{ x, z, width, depth }])` for solid world objects.
- `runtime.input` supports W/A/S/D and arrow movement by default and can be replaced with `new InputMap(customMap)`.

Call `runtime.stop()` to detach keyboard listeners. The core has no DOM or rendering dependency and can be used by story logic, world presentation, and UI adapters independently.

For a browser scene, `startPlayableScene({ render })` starts the input and requestAnimationFrame loop; `render(runtime)` is called after each simulation step. The renderer may be Three.js, WebGL, or another engine without changing the contract.
