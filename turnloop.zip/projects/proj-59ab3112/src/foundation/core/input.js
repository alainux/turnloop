import { EventBus } from './events.js';

export const DEFAULT_INPUT_MAP = Object.freeze({
  forward: ['KeyW', 'ArrowUp'], backward: ['KeyS', 'ArrowDown'],
  left: ['KeyA', 'ArrowLeft'], right: ['KeyD', 'ArrowRight'],
  interact: ['KeyE', 'Enter', 'Space'], pause: ['Escape', 'KeyP'], reset: ['KeyR']
});

export class InputMap {
  #keydown;
  #keyup;

  constructor(map = DEFAULT_INPUT_MAP) {
    this.events = new EventBus();
    this.map = Object.freeze(Object.fromEntries(Object.entries(map).map(([action, codes]) => [action, [...codes]])));
    this.down = new Set();
    this.pressed = new Set();
  }

  attach(target = globalThis) {
    if (!target?.addEventListener) return () => {};
    this.#keydown = (event) => {
      if (!this.down.has(event.code)) this.pressed.add(event.code);
      this.down.add(event.code);
      const action = this.actionFor(event.code);
      if (action) this.events.emit('action', { action, code: event.code, originalEvent: event });
    };
    this.#keyup = (event) => this.down.delete(event.code);
    target.addEventListener('keydown', this.#keydown);
    target.addEventListener('keyup', this.#keyup);
    return () => { target.removeEventListener('keydown', this.#keydown); target.removeEventListener('keyup', this.#keyup); };
  }

  actionFor(code) { return Object.entries(this.map).find(([, codes]) => codes.includes(code))?.[0] ?? null; }
  isDown(action) { return (this.map[action] ?? []).some((code) => this.down.has(code)); }
  wasPressed(action) { return (this.map[action] ?? []).some((code) => this.pressed.has(code)); }
  endFrame() { this.pressed.clear(); }
}
