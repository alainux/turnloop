import { EventBus } from './events.js';
import { InputMap } from './input.js';
import { PlayerController } from './player.js';
import { FollowCamera } from './camera.js';
import { GameState } from './game-state.js';

export function createGameRuntime(options = {}) {
  const events = new EventBus();
  const input = options.input ?? new InputMap(options.inputMap);
  const player = options.player ?? new PlayerController(options.playerOptions);
  const camera = options.camera ?? new FollowCamera(options.cameraOptions);
  const state = options.state ?? new GameState(options.stateOptions);
  const runtime = {
    events, input, player, camera, state, started: false, lastTime: 0,
    start(target = globalThis) { if (this.started) return; this.started = true; this.detachInput = input.attach(target); events.emit('ready', { runtime: this }); },
    stop() { this.detachInput?.(); this.started = false; },
    frame(time = 0) {
      const dt = Math.min(Math.max((time - this.lastTime) / 1000 || 0, 0), 0.1); this.lastTime = time;
      if (input.wasPressed('pause')) state.togglePause();
      if (input.wasPressed('reset')) { player.reset(); state.reset(); }
      if (!state.paused) { player.update(input, dt); camera.update(player.position, dt); events.emit('player-moved', { position: { ...player.position } }); }
      if (input.wasPressed('interact')) events.emit('interact', { position: { ...player.position }, scene: state.scene });
      input.endFrame();
    },
    loadScene(scene, meta) { state.loadScene(scene, meta); },
    pause() { state.setPaused(true); }, resume() { state.setPaused(false); }, reset() { player.reset(); state.reset(); }
  };
  for (const event of ['scene-load', 'pause', 'resume', 'reset']) state.events.on(event, (payload) => events.emit(event, payload));
  return runtime;
}

export function bootstrapScene(options = {}) {
  const runtime = createGameRuntime(options);
  runtime.start(options.eventTarget ?? globalThis);
  return runtime;
}
