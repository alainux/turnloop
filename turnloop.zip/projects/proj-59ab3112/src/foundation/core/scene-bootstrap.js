import { createGameRuntime } from './runtime.js';

/**
 * Starts the runtime and an optional render adapter. The adapter receives the
 * runtime after simulation, so world presentation can own its own renderer.
 */
export function startPlayableScene({ render = () => {}, eventTarget = globalThis, scheduler = globalThis, ...options } = {}) {
  const runtime = createGameRuntime(options);
  let animationFrame;
  const tick = (time) => {
    runtime.frame(time);
    render(runtime);
    if (runtime.started) animationFrame = scheduler.requestAnimationFrame?.(tick);
  };
  runtime.start(eventTarget);
  if (scheduler.requestAnimationFrame) animationFrame = scheduler.requestAnimationFrame(tick);
  const stop = runtime.stop.bind(runtime);
  runtime.stop = () => { if (animationFrame != null) scheduler.cancelAnimationFrame?.(animationFrame); stop(); };
  return runtime;
}
