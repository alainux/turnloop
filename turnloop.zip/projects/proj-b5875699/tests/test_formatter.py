import pathlib
import re

from museum_labels.formatter import format_labels, load_labels


def test_format_labels_renders_fixture():
    path = pathlib.Path(__file__).resolve().parents[1] / "museum_labels" / "labels.json"
    labels = load_labels(path)
    rendered = format_labels(labels)

    assert re.search(r"\[\d{4}-\d{3}\]", rendered), "no [<id>] block rendered"
    assert re.search(
        r"Starry Night Over the Rhone by Vincent van Gogh \(1888\)", rendered
    ), "title/artist/year line missing"
    assert re.search(r"Room: Gallery 12", rendered), "Room line missing"
    assert re.search(r"[^\s]\n", rendered), "no non-empty description line"
    assert "melting clocks" in rendered, "description content missing"

    partial = format_labels([{"id": "X-1"}])
    assert "[X-1]" in partial and "Room: " in partial
