import pathlib
import sys

from .formatter import format_labels, load_labels


def main() -> int:
    default = pathlib.Path(__file__).with_name("labels.json")
    path = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else default
    labels = load_labels(path)
    print(format_labels(labels))
    return 0


if __name__ == "__main__":
    sys.exit(main())