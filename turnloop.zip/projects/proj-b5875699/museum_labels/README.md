# museum_labels

A tiny offline plain-text museum label formatter.

## Fixture schema

Labels live in `museum_labels/labels.json`, a top-level array of objects with exactly these keys:

- `id` (string)
- `title` (string)
- `artist` (string)
- `year` (string)
- `room` (string)
- `description` (string)

Example label:

```json
{
  "id": "p-001",
  "title": "The Persistence of Memory",
  "artist": "Salvador Dalí",
  "year": "1931",
  "room": "Modern Art",
  "description": "The surrealist landscape of soft melting clocks."
}
```

## Usage

Run from anywhere, defaulting to the `labels.json` next to the package:

```
python -m museum_labels
```

Or point it at any JSON file:

```
python -m museum_labels <path-to.json>
```

## Output format

Each label is rendered as a block, blocks separated by a blank line:

```
[<id>]
<TITLE> by <ARTIST> (<YEAR>)
Room: <ROOM>
<DESCRIPTION>
```

## Test

```
python3.12 -m pytest tests/test_formatter.py -q
```
