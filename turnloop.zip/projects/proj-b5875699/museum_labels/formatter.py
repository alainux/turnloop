import json


def load_labels(path: str) -> list[dict]:
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def format_labels(labels: list[dict]) -> str:
    blocks = []
    for label in labels:
        block = "[{id}]\n{title} by {artist} ({year})\nRoom: {room}\n{description}".format(
            id=label.get("id", ""),
            title=label.get("title", ""),
            artist=label.get("artist", ""),
            year=label.get("year", ""),
            room=label.get("room", ""),
            description=label.get("description", ""),
        )
        blocks.append(block)
    return "\n\n".join(blocks)