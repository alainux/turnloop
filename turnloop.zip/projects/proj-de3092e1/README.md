# Native PTY Hello Demo

A tiny terminal demo that prints a greeting from `hello.txt`.

Display it:

```sh
cat hello.txt
```

Verify the file and its exact contents:

```sh
test -f hello.txt && printf '%s\n' 'Hello from the native PTY demo!' | cmp -s - hello.txt && echo 'verified'
```
